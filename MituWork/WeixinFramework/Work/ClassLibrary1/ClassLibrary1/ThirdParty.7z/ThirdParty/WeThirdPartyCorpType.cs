﻿namespace YJC.Toolkit.Weixin.ThirdParty
{
    public enum WeThirdPartyCorpType
    {
        Verified,
        Unverified,
        Test
    }
}
