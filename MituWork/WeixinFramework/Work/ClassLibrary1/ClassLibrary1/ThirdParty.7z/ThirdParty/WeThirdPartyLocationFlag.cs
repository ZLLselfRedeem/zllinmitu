﻿namespace YJC.Toolkit.Weixin.ThirdParty
{
    public enum WeThirdPartyLocationFlag
    {
        Noreported,
        ConversationReported,
        Reported
    }
}
