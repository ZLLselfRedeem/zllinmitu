﻿using System;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;

namespace $rootnamespace$
{
    internal class $fileinputname$Page : WebBasePage
    {
        public $fileinputname$Page()
        {
        }

        protected override IPostObjectCreator PostObjectCreator
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public override ISource Source
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        protected override void DoGet()
        {
            throw new NotImplementedException();
        }

        protected override void DoPost()
        {
            throw new NotImplementedException();
        }
    }
}
