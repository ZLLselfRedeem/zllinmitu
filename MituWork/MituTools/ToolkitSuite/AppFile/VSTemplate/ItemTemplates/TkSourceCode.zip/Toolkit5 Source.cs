﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Data;

namespace $rootnamespace$
{
    [Source(Author = "$username$", CreateDate = "$time$",
        Description = "数据源")]
    internal class $fileinputname$Source : BaseDbSource
    {
        public $fileinputname$Source()
        {
        }

        public override OutputData DoAction(IInputData input)
        {
            return OutputData.Create(DataSet);
        }
    }
}
