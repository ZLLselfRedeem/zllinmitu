﻿using System;
using YJC.Toolkit.Sys;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            ToolApp.Initialize(false);

            // Input code.
            Console.ReadKey();
        }
    }
}
