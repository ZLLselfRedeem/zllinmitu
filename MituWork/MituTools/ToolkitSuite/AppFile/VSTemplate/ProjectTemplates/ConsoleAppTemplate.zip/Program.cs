﻿using System;
using System.Linq;
using YJC.Toolkit.Sys;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            if (!ConsoleApp.Initialize())
                return;

            // Input code.
            Console.ReadKey();
        }
    }
}
