﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using YJC.Toolkit.Sys;

namespace $safeprojectname$
{
    [TestClass]
    public class Program
    {
        [AssemblyInitialize]
        public static void Initialize(TestContext context)
        {
            TestApp.Initialize(@"");
        }
    }
}
