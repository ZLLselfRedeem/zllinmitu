﻿if exists (select 1
            from  sysobjects
           where  id = object_id('V_USER_ORG')
            and   type = 'V')
   drop view V_USER_ORG
;

