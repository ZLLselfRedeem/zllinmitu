using System;
using System.Data;
using YJC.Toolkit.DataAccess;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// PartFuncResolver ��ժҪ˵����
	/// </summary>
	public class PartFuncResolver : TableResolver
	{
		public PartFuncResolver(DataSet hostDataSet) : base(hostDataSet)
		{
            Fields = "PF_PART_ID, PF_FN_ID, PF_IS_FUNC";
            KeyFields = "PF_PART_ID, PF_FN_ID";
            TableName = "SYS_PART_FUNC";
		}
	}
}
