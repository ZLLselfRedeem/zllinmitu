using System;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// SimpleDataRight2 ��ժҪ˵����
	/// </summary>
	public class SimpleDataRight2 : ClassicDataRight2
	{
		public SimpleDataRight2() : base()
		{
            Add(new OwnerDataRight2Unit());
            Add(new OwnerComDataRightUnit());
            Add(new ComDataRightUnit());
            Add(new UserDataRightUnit());
		}
	}
}
