using System;
using System.Reflection;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Data;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// SmsSend ��ժҪ˵����
	/// </summary>
	public abstract class SmsSend : UpdateDataSet
	{
		public SmsSend()
		{
			ConnectionStr = AppSettings.Current.ConnectionString;
		}

		public abstract void Send(string body, params string[] mobiles);
	}
}