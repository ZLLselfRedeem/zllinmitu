using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// ConnectionFailedException ��ժҪ˵����
	/// </summary>
    public class ConnectionFailedException : LoginException
    {
        private class ConnectionFailedErrorObject : BaseErrorObject
        {
            public ConnectionFailedErrorObject() : base("ORG_CODE", 
                LoginResUtil.GetResourceString("ConnectionFailed"), 0)
            {
            }
        }

        public ConnectionFailedException() : base()
        {
            ErrorObject = new ConnectionFailedErrorObject();
        }
    }
}
