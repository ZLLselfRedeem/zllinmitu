using System;
using System.Collections.Specialized;
using System.Data;
using System.Web;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Data;
using YJC.Toolkit.Exception;
using YJC.Toolkit.Sys;
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Right.Data
{
	public class LoginBaseDataSet: BaseDataSet, IXml2Page, IXmlHttpPost2Page
	{
		private LoginMode fMode;
		private DataTable fLoginTable;
		private DataRow fLoginRow;
		private ErrorObjectCollection fErrorObjects;

		public LoginBaseDataSet(LoginMode mode)
		{
			fMode = mode;
			fErrorObjects = new ErrorObjectCollection("Login");
		}

		public string LoginName
		{
			get
			{
				return fLoginRow["LOGIN_NAME"].ToString();
			}
			set
			{
				fLoginRow["LOGIN_NAME"] = value;
			}
		}

		public string Password
		{
			get
			{
				return fLoginRow["LOGIN_PASS"].ToString();
			}
			set
			{
				fLoginRow["LOGIN_PASS"] = value;
			}
		}

		public int LoginAttempts
		{
			get
			{
				return int.Parse(fLoginRow["LOGIN_ATTEMPTS"].ToString());
			}
			set
			{
				fLoginRow["LOGIN_ATTEMPTS"] = value;
			}
		}

		public DataRow LoginRow
		{
			get
			{
				return fLoginRow;
			}
		}

		protected virtual string[] LoginTableFields
		{
			get
			{
				return new string[] { "LOGIN_MODE", "LOGIN_NAME", "LOGIN_PASS", "LOGIN_ATTEMPTS" };
			}
		}

		internal void CreateLoginTable()
		{
			fLoginTable = DataSetUtil.CreateDataTable("LOGIN", LoginTableFields); 
			Tables.Add(fLoginTable);
			fLoginRow = fLoginTable.NewRow();
			fLoginRow["LOGIN_MODE"] = fMode.ToString();
			fLoginRow["LOGIN_ATTEMPTS"] = 0;
			fLoginTable.Rows.Add(fLoginRow);
		}

		protected virtual void CheckLogin(DataRow row, IUserInfo info)
		{
		}

		public virtual void SetDefaultValue(HttpRequest request) 
		{
		}

        #region IXml2Page ��Ա

        public string GetDefaultPage(bool isPost, PageStyle style, string operation, PageX pageX, string retURL)
        {
            return null;
        }

        public string GetXsltFile(bool isIe, PageStyle style, string operation)
        {
            return null;
        }

        #endregion

        #region IHttpGet2Page ��Ա

        public virtual void SetData(bool isPost, PageStyle style, string operation, NameValueCollection queryString)
        {
            this.CreateLoginTable();
            this.SetDefaultValue(GlobalVariable.Request);
        }

        #endregion

        #region IXmlHttpPost2Page ��Ա

        public string GetAlertString(PageStyle style, string operation, NameValueCollection queryString, DataSet postDataSet)
        {
            return null;
        }

        public string GetJScript(PageStyle style, string operation)
        {
            return null;
        }

        public string Post(PageStyle style, string operation, NameValueCollection queryString, DataSet postDataSet)
        {
            this.CreateLoginTable();

            DataRow row = postDataSet.Tables["LOGIN"].Rows[0];
            try
            {
                CheckLogin(row, GlobalVariable.Info);
            }
            catch (LoginException ex)
            {
                DataSetCopyUtil.CopyRow(row, fLoginRow, LoginTableFields, LoginTableFields);
                ++LoginAttempts;
                if (ex is UserLockedException && LoginAttempts >= LoginUtil.GetPasswdLengthConfig())
                    LoginAttempts = 0;
                fErrorObjects.Add(ex.ErrorObject);
            }
            try
            {
                fErrorObjects.CheckError();
            }
            catch (InformationException ex)
            {
                Tables.Add(fErrorObjects.ErrorTable);
                throw ex;
            }
            return string.Empty;
        }

        #endregion
    }
}
