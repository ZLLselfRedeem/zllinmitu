using System;
using System.Configuration;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// WebLogoutPage ��ժҪ˵����
	/// </summary>
    [WebPage(WebLogoutPage.ALIAS_NAME, Description = "�˳�����", Author = "YJC", CreateDate = "2004-10-03")]
    public class WebLogoutPage : WebBaseLogoutPage
	{
        internal const string ALIAS_NAME = "LogoutPage";
        public WebLogoutPage() : base()
		{
            LoginPage = LoginUtil.GetDefaultPageConfig();
		}
	}
}
