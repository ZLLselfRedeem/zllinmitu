using System;
using System.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// UserRightInitialization ��ժҪ˵����
	/// </summary>
	public class UserRightInitialization : IInitialization
	{
		public UserRightInitialization()
		{
		}
		#region IInitialization ��Ա

		public void ApplicationEnd(HttpApplication application)
		{
		}

		public void ApplicationStart(HttpApplication application, IAppGlobal global)
		{
			global.RegsCollection.Add(new SmsSendRegCategory());
		}

		public void SessionStart(HttpApplication application, ISessionGlobal global)
		{
			ILoginRight loginRight = new SimpleLoginRight(global.Info);
			global.Rights.LoginRight = loginRight;
			global.Rights.DataRight = new SimpleDataRight(AppSettings.Current.ConnectionString);
            global.Rights.DataRight2 = new SimpleDataRight2();
			global.Rights.FunctionRight = new SimpleFunctionRight(AppSettings.Current.ConnectionString);
		}

		public void SessionEnd(HttpApplication application)
		{
		}

		#endregion
	}
}
