using System;
using YJC.Toolkit.Exception;
using YJC.Toolkit.Data;

namespace YJC.Toolkit.Right
{
	public abstract class SimpleAbstractLoginRight : EmptyLoginRight
	{
        private IUserInfo fInfo;
        private string fLoginPage;

        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="info">�û���Ϣ</param>
        public SimpleAbstractLoginRight(IUserInfo info)
		{
            fInfo = info;
		}

        /// <summary>
        /// ��¼ҳ���URL����Ҫ�̳е��ඨ��
        /// </summary>
        public string LoginPage
        {
            get
            {
                return fLoginPage;
            }
            set
            {
                fLoginPage = value;
            }
        }

        /// <summary>
        /// ����û��Ƿ��¼�����û�е�¼����λ����¼ҳ�����û����µ�¼
        /// </summary>
        /// <param name="userId">�û�ID</param>
        /// <param name="url">�ض����URL</param>
        public override void CheckLogin(object userId, string url)
        {
            if (fLoginPage == null || fLoginPage == string.Empty)
                return;
            if (!fInfo.IsLogin)
            {
                string totalURL = fLoginPage;
                string conj = (totalURL.IndexOf("?") == -1) ? "?" : "&";
                if (url != null || url != string.Empty)
                    totalURL += conj + string.Format("RetURL={0}", url);
                throw new RedirectException(totalURL);
            }
        }
	}
}
