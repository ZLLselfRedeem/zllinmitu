using System;
using System.Collections.Specialized;
using System.Data;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Provider;
using YJC.Toolkit.SysUtil;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
	[Resolver(UsersResolver.REG_NAME, Description = "��UR_USERS(UR_USERS)�����ݷ��ʲ���", 
		Author = "wuhj", CreateDate = "2004-07-07")]
	public class UsersResolver : Xml2TableResolver
	{
		internal const string REG_NAME = "Users";
		
		public UsersResolver(DataSet hostDataSet) : base(hostDataSet)
		{
			XmlFile = "Users/Users.xml";
            AutoUpdating = false;
		}
		
        private DataRow CheckUserLogin(string pwd, int loginAttempts, IUserInfo info, ref bool isNewUser) 
        {
            isNewUser = false;

            if (HostTable.Rows.Count == 0)
                throw new NoLoginNameException();

            DataRow rowUser = HostTable.Rows[0];

            //�û�����ְ
            if (rowUser["USER_OUT"].ToString() == "1")
                throw new UserFiredException();

            //��¼��������3�Σ��������ʺ�
            if (loginAttempts >= LoginUtil.GetPasswdLengthConfig())
            {
                ChangeUserState(rowUser, false, info);
                throw new UserLockedException();
            }

            switch (rowUser["USER_ACTIVE"].ToString())
            {
                case ""  :
                case "0" :
                    if (rowUser["USER_UNLOCK_DATE"].ToString() == "")
                        throw new UserLockedException();

                    try
                    {
                        if (DateTime.Parse(rowUser["USER_UNLOCK_DATE"].ToString()) >= DateTime.Now)
                            throw new UserLockedException();
                    }
                    catch (UserLockedException ex)
                    {
                        throw ex;
                    }
                    catch
                    {
                        throw new UserInfoException();
                    }

                    //�û���ʱ������ʱ���Ѿ�С�ڵ�ǰʱ�䣬�����û���Active״̬������������֤��
                    goto case "1";					
                case "1" :
                    //��һ�ε�¼�û�
                    if (rowUser["USER_LOGIN_DATE"].ToString() == "")
                        isNewUser = true;

                    if (PasswdUtil.Decrypt(rowUser["USER_LOGIN_PASSWD"].ToString(), rowUser["USER_LOGIN_NAME"].ToString()) == pwd)
                    {
                        ChangeUserState(rowUser, true, info);
                        return rowUser;
                    }
                    else
                        throw new PasswordInvalidException();						
            }
            return rowUser;
        }

        public DataRow CheckUserLogin(string loginName, string pwd, int loginAttempts, 
            IUserInfo info, ref bool isNewUser)
        {
            SelectWithParam("USER_LOGIN_NAME", loginName);

            return CheckUserLogin(pwd, loginAttempts, info, ref isNewUser);
        }

		public DataRow CheckUserLogin(string orgId, string loginName, string pwd, int loginAttempts, 
            IUserInfo info, ref bool isNewUser)
		{
            SelectWithParams(new string[] {"USER_ORG_ID", "USER_LOGIN_NAME"}, 
                new object[] {orgId, loginName});

            return CheckUserLogin(pwd, loginAttempts, info, ref isNewUser);
        }

		public void ChangeUserState(DataRow rowUser, bool isValid, IUserInfo info)
		{
			string strSQL = "";						
            if (!isValid)
                strSQL = string.Format("UPDATE UR_USERS SET USER_ACTIVE = 0, USER_UNLOCK_DATE = '{0}' "
                    + "WHERE USER_ID = '{1}'", DateTime.Now.AddDays(1).ToString("yyyy-MM-dd HH:mm:ss"), 
                    rowUser["USER_ID"]);
            else 
            {
                strSQL = string.Format("UPDATE UR_USERS SET USER_ACTIVE = 1, USER_LOGIN_DATE = '{0}', "
                    + "USER_UNLOCK_DATE = NULL WHERE USER_ID = '{1}'", 
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), rowUser["USER_ID"]);

                info.IsLogin = true;
                info.UserID = rowUser["USER_ID"];
                info.RoleID = rowUser["USER_ORG_ID"];
                info.UserName = rowUser["USER_NAME"].ToString();
                info.UserLoginName = rowUser["USER_LOGIN_NAME"].ToString();
                info.Encoding = "gb2312";
            }
            DataSetUtil.ExecuteScalar(strSQL, DbConnection);
		}

        /// <summary>
        /// �ڱ������½����޸ĺ�ɾ����ʱ�򴥶���ע�⣬ǧ��Ҫɾ��base.OnUpdatingRow(e);
        /// UpdatingRow�¼������ڻ���ú����С�
        /// </summary>
        /// <param name="e">�¼�����</param>
        protected override void OnUpdatingRow(UpdatingEventArgs e)
        {
            base.OnUpdatingRow(e);
			
            switch (e.Status)
            {
                case UpdateKind.Insert :
                    e.Row["USER_ID"] = GlobalProvider.GetUniID(TableName, DbConnection);
                    e.Row["USER_CREATE_ID"] = e.Row["USER_UPDATE_ID"] = GlobalVariable.UserID;
					e.Row["USER_CREATE_DATE"] = e.Row["USER_UPDATE_DATE"] = DateTime.Now;
					break;
                case UpdateKind.Update :
                    e.Row["USER_UPDATE_ID"] = GlobalVariable.UserID;
                    e.Row["USER_UPDATE_DATE"] = DateTime.Now;
					break;
            }
			
        }
		
        /// <summary>
        /// �����Զ����Լ����ע�⣬ǧ��Ҫɾ��base.AddConstraints(status);
        /// �������Xml����Ϣ���Ѿ��Զ������˷ǿա���ֵ���͡��������͡��ַ��������Լ�EasySearch��Լ��
        /// </summary>
        /// <param name="status">������½�/�޸ĵ�״̬</param>
        protected override void AddConstraints(UpdateKind status)
        {
            base.AddConstraints(status);
            this.Constraints.Add(new SingleValueConstraint("USER_LOGIN_NAME", this.GetDisplayName("USER_LOGIN_NAME")));
            this.Constraints.Add(new MobileConstraint("USER_MOBILE", this.GetDisplayName("USER_MOBILE")));
            this.Constraints.Add(new EMailConstraint("USER_EMAIL", this.GetDisplayName("USER_EMAIL")));
            this.Constraints.Add(new SFZConstraint("USER_IDENT_NO", this.GetDisplayName("USER_IDENT_NO")));
            this.Constraints.Add(new PostCodeConstraint("USER_POSTAL", this.GetDisplayName("USER_POSTAL")));
        }
	}
}
