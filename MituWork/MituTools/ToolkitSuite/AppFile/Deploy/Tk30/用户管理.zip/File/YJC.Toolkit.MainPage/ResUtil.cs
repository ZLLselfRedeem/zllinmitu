using System;
using System.Globalization;
using System.Reflection;
using System.Resources;

using YJC.Toolkit.Sys;
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Web
{
	/// <summary>
	/// �����Դ�ļ�������
	/// </summary>
	internal sealed class ResUtil
	{
		private static Assembly fAssembly = null;
		private static ResourceManager fRm = null;

		private ResUtil()
		{
		}

		private static void GetResourceManager()
		{
			fRm = ResourceUtil.GetResourceManager(PageAssembly, "ToolkitRes");
		}

		/// <summary>
		/// Toolkit�Լ���Assembly����
		/// </summary>
		public static Assembly PageAssembly
		{
			get
			{
				if (fAssembly == null)
					fAssembly = Assembly.GetExecutingAssembly();
				return fAssembly;
			}
		}

		/// <summary>
		/// �����Դ�ļ�������
		/// </summary>
		/// <param name="resName">��Դ�ļ�����</param>
		/// <returns>��Դ�ļ�������</returns>
		public static string GetResourceString(string resName)
		{
			if (fRm == null)
				GetResourceManager();
			return fRm.GetString(resName);
		}
	}
}
