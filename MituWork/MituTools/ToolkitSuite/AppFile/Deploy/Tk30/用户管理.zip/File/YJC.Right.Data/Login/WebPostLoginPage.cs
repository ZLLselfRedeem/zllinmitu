using System;
using System.Configuration;
using System.Web;
using System.Data;
using System.Collections.Specialized;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;
using YJC.Toolkit.Xml;
using YJC.Toolkit.Exception;
using YJC.Toolkit.SysUtil;
using YJC.Toolkit.Constraint;


namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// WebPostLogin ��ժҪ˵����../Library2/WebInitPage.tkx?Source=WebPostLoginPage
	/// </summary>
	[WebPage("WebPostLoginPage", Description = "�޽����û���½", Author = "LouYan", CreateDate = "2007-10-16")]
	public class WebPostLoginPage : WebHttpPost2Page
	{
		public WebPostLoginPage() : base()
		{
			Source = new PostLoginDataSet();
		}
		public PostLoginDataSet Generator
		{
			get
			{
				return Source as PostLoginDataSet;
			}
		}

		protected override void DoPost()
		{
			string flag = (Source as IHttpPost2Page).Post(PageStyle.Custom, "", Request.QueryString, Request.Form);
			SucceedCommit(flag);
		}

		protected void SucceedCommit(string flag)
		{
			if (flag == "0")
			{
				try
				{
					SessionGbl.Rights.DataRight2.Initialize(SessionGbl.Info);
					SessionGbl.Rights.FunctionRight.Initialize(SessionGbl.Info);
					SessionGbl.Rights.DataRight.Initialize(SessionGbl.Info);
					SessionGbl.Rights.LoginRight.OnLogin(new LoginEventArgs(SessionGbl.Info));
				}
				catch
				{
					flag = "1";
				}
			}

			Response.Write(flag);
		}

		protected override void HandleInformation(InformationException ex)
		{
			Response.Write("0");
		}
	}
}
