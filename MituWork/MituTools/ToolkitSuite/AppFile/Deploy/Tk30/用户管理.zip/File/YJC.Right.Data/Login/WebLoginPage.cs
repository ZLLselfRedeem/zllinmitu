using System;
using System.Configuration;
using System.Web;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;
using YJC.Toolkit.Xml;

namespace YJC.Toolkit.Right.Data
{
    /// <summary>
	/// WebLoginPage ��ժҪ˵����
	/// </summary>
    [WebPage(WebLoginPage.ALIAS_NAME, Description = "��¼����", Author = "YJC", CreateDate = "2004-10-03")]
    public class WebLoginPage : WebBaseLoginPage
	{
        internal const string ALIAS_NAME = "LoginPage";
        private LoginMode fMode;
        
        public WebLoginPage() : base()
		{
            fMode = LoginUtil.GetLoginModeConfig();
            switch (fMode)
            {
                case LoginMode.User :
					Source = new UserLoginDataSet(fMode);
                    break;
				case LoginMode.UserOrg :
					Source = new UserOrgLoginDataSet(fMode);
					break;
				case LoginMode.UserWithVerify :
					Source = new UserWithVerifyLoginDataSet(fMode);
					break;
				case LoginMode.UserOrgWithVerify :
					Source = new UserOrgWithVerifyLoginDataSet(fMode);
					break;
            }
			IeXslFile = "../Bin/Login.xslt";
        }

        protected override void InitPageData()
        {
            base.InitPageData();
            Transform = TransformAllUtil.NewTransformAll("Login");
		}

        protected override void WritePage()
        {
            Response.Write(Transform.TransformAll(IsIe, TransformPos.None));
        }

        protected override void SucceedCommit()
        {
            SessionGbl.Rights.DataRight2.Initialize(SessionGbl.Info);
            SessionGbl.Rights.FunctionRight.Initialize(SessionGbl.Info);
            SessionGbl.Rights.DataRight.Initialize(SessionGbl.Info);
            SessionGbl.Rights.LoginRight.OnLogin(new LoginEventArgs(SessionGbl.Info));

            DefaultPage = (Source as UserLoginDataSet).IsNewUser ?
                string.Format("../Library/WebMainPage.{0}?Source=../Library2/WebUpdateXmlPage.{0}?Source=Users/UserChgPasswd&ID=-1", PageX.ToString()) :
                string.Format("../Library/WebMainPage.{0}?Source=WebInitPage.{0}?Source=HomePage", PageX.ToString());
            Response.Write("OK" + RedirectPath());
        }
	}
}
