﻿using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(UserInfoPasswdResolver.__REG_NAME, Description = "表UR_USERS(UR_USERS)的数据访问层类，只能对登录者个人维护Password",
        Author = "YJC", CreateDate = "2007-06-20")]
    public class UserInfoPasswdResolver : UserInfoResolver
    {
        internal const string __REG_NAME = "UserInfoPasswd";
        /// <summary>
        /// Initializes a new instance of the UserInfoPasswdResolver class.
        /// </summary>
        public UserInfoPasswdResolver(DataSet hostDataSet) : base(hostDataSet)
        {
        }

        protected override void AddConstraints(UpdateKind status)
        {
            base.AddConstraints(status);

            string passwd = HostTable.Rows[0]["USER_LOGIN_PASSWD"].ToString();
            Constraints.Add(new PasswordConstraint("USER_LOGIN_PASSWD", passwd));
        }
    }
}
