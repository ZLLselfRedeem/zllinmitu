using System;
using System.Data;
using YJC.Toolkit.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.Exception;
using YJC.Toolkit.Sys;
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Right.Data
{
    /// <summary>
	/// GetPasswdPage ��ժҪ˵����
	/// </summary>
    [WebPage(GetPasswdPage.ALIAS_NAME, Description = "ȡ������", Author = "ShiXin", CreateDate = "2007-09-18")]
    public class GetPasswdPage : WebDataSet2Page
	{
        internal const string ALIAS_NAME = "GetPasswdPage";
		private DataSet fPostDataSet;
		private IXmlHttpPost2Page fHttpPostPage;
        public GetPasswdPage() : base()
		{
			SupportLogin = false;

			try
			{
				if (IsPost) 
				{
					fPostDataSet = new DataSet();
					fPostDataSet.ReadXml(Request.InputStream);
					if (AppSettings.Current.Debug)
					{
						string fileName = AppSettings.Current.XmlPath + "Post.xml";
						string content = "<?xml version=\"1.0\" encoding=\"gb2312\"?>\r\n" + fPostDataSet.GetXml();
						FileUtil.SaveFile(fileName, content);
					}
				}
			}
			catch
			{
			}

			Source = new GetPasswdDataSet();
		}

		public DataSet PostDataSet
		{
			get
			{
				return fPostDataSet;
			}
		}

		public override BaseDataSet Source
		{
			get
			{
				return base.Source;
			}
			set
			{
				base.Source = value;
				if (value != null)
				{
					fHttpPostPage = Source as IXmlHttpPost2Page;
					if (fHttpPostPage == null) 
						throw new ToolkitException("DataSet����֧��IXmlHttpPost2Page�ӿڣ���֧��Ҳ��֧�֡�");
				}
			}
		}

		public IXmlHttpPost2Page HttpPostPage
		{
			get
			{
				if (fHttpPostPage == null)
					throw new ToolkitException("IXmlHttpPost2Page�ӿڶ���null���㻹�ҵ��ã�����Source��û�и�ֵ");
				return fHttpPostPage;
			}
		}

		protected override void DoGet()
		{
		}

		private void WriteRedirectURL(string url)
		{
			string alert = HttpPostPage.GetAlertString(Style, Operation, 
				Request.QueryString, PostDataSet);
			Response.ContentEncoding = System.Text.Encoding.UTF8;
			if (alert == string.Empty)
				Response.Write("OK" + url);
			else
				Response.Write(string.Format("OK;Alert;{0};Alert;{1}", alert, url));
		}

		protected virtual void SucceedCommit()
		{
			if (HttpPostPage != null)
			{
				string s = HttpPostPage.GetDefaultPage(true, Style, Operation, PageX, RetURL);
				WriteRedirectURL(s);
			}
		}

		protected override void DoPost()
		{
			HttpPostPage.Post(Style, Operation, Request.QueryString, PostDataSet);
			SucceedCommit();
		}
	}
}
