using System;
using System.Data;
using System.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// UserOrgLoginDataSet ��ժҪ˵����
	/// </summary>
	public class UserOrgLoginDataSet : UserLoginDataSet
	{
		private TableSelector fOrgInfo;
        public UserOrgLoginDataSet(LoginMode mode) : base(mode)
		{
			fOrgInfo = new TableSelector(this);
			fOrgInfo.Fields = "ORG_ID, ORG_CODE, ORG_NAME, ORG_ACTIVE";
			fOrgInfo.TableName = "SYS_ORGANIZATION";
		}

		public string OrgCode
		{
			get
			{
				return LoginRow["ORG_CODE"].ToString();
			}
			set
			{
				LoginRow["ORG_CODE"] = value;
			}
		}

		protected override string[] LoginTableFields
		{
			get
			{
				return new string[] { "LOGIN_MODE", "LOGIN_NAME", "LOGIN_PASS", "LOGIN_ATTEMPTS", "ORG_CODE" };
			}
		}

        protected override void CheckLogin(DataRow row, IUserInfo info)
		{
			try
			{
				fOrgInfo.SelectWithParam("ORG_CODE", row["ORG_CODE"]);
			}
			catch
			{
				throw new ConnectionFailedException();
			}

			if(fOrgInfo.HostTable.Rows.Count == 0)
				throw new NoOrganizationException();

			DataRow orgRow = Tables["SYS_ORGANIZATION"].Rows[0];
				
			if(orgRow["ORG_ACTIVE"].ToString() == string.Empty || orgRow["ORG_ACTIVE"].ToString() == "0")
				throw new OrganizationInactiveException();

            if(row["LAST_LOGIN_NAME"].ToString() != row["LOGIN_NAME"].ToString())
                row["LOGIN_ATTEMPTS"] = 0;

			bool newUser = false;
			UserResolverInst.CheckUserLogin(orgRow["ORG_ID"].ToString(), row["LOGIN_NAME"].ToString(),
				row["LOGIN_PASS"].ToString(), int.Parse(row["LOGIN_ATTEMPTS"].ToString()), info, ref newUser);
			IsNewUser = newUser;

			HttpResponse response = GlobalVariable.Response;
			DateTime expires = DateTime.Now + new TimeSpan(30, 0, 0, 0);
			HttpCookie cookie = new HttpCookie("LoginName", row["LOGIN_NAME"].ToString());
			cookie.Expires = expires;
			response.Cookies.Set(cookie);
			cookie = new HttpCookie("OrgCode", row["ORG_CODE"].ToString());
			cookie.Expires = expires;
			response.Cookies.Set(cookie);
		}

		public override void SetDefaultValue(HttpRequest request) 
		{
			base.SetDefaultValue(request);
			HttpCookie cookie = request.Cookies["OrgCode"];
			if (cookie != null)
				OrgCode = cookie.Value;
		}
	}
}
