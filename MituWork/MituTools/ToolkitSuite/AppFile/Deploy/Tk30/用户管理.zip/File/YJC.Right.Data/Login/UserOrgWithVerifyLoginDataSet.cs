using System;
using System.Data;
using System.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// UserOrgWithVerifyLoginDataSet ��ժҪ˵����
	/// </summary>
	public class UserOrgWithVerifyLoginDataSet : UserOrgLoginDataSet
	{
		public UserOrgWithVerifyLoginDataSet(LoginMode mode) : base(mode)
		{
		}

		protected override string[] LoginTableFields
		{
			get
			{
				return new string[] { "LOGIN_MODE", "LOGIN_NAME", "LOGIN_PASS", "LOGIN_ATTEMPTS", "ORG_CODE", "LOGIN_VERIFY" };
			}
		}

        protected override void CheckLogin(DataRow row, IUserInfo info)
        {
			//��֤��
			if(row["LOGIN_VERIFY"].ToString() != GlobalVariable.Session["VerifyKey"].ToString())
				throw new VerifyException();

            base.CheckLogin(row, info);
        }
	}
}
