using System;
using System.Data;

using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Exception;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// SimpleDataRight ��ժҪ˵����
	/// </summary>
	public class SimpleDataRight : EmptyDataRight
	{
        private UserList fComUserList;
        private UserList fUsersUserList;
        private UserList fOwnerList;
        private UserCollection fUserCollection;
        private string fConnStr;
        
        private class NoDataRightException : ErrorPageException
        {
            public NoDataRightException() : base()
            {
                PageTitle  = ErrorTitle = "Ȩ�޴���";
                ErrorBody  = "��û��Ȩ�޷�����������";
            }
        }

        public SimpleDataRight(string connStr) : base()
		{
            fComUserList = new UserList();
            fUsersUserList = new UserList();
            fOwnerList = new UserList();
            fUserCollection = new UserCollection();
            fUserCollection.Add("user", fUsersUserList);
            fUserCollection.Add("com", fComUserList);
            fUserCollection.Add("owner", fOwnerList);

            fConnStr = connStr;		
        }

        private UserList GetUserList(object type)
        {
            string result = "user";
            if (type != null) 
            {
                switch (type.ToString()) 
                {
                    case "com" :
                        result = "com";
                        break;
                    case "owner" :
                        result = "owner";
                        break;
                    default :
                        result = "user";
                        break;
                }
            }
            return fUserCollection[result];
        }
        
        public override void CheckReadWrite(object type, object ownerId)
        {
            UserList list = GetUserList(type);
            if (list.ROUserList.Count == 0)
                return;
            if (!list.RWUserList.Contains(ownerId.ToString()))
                throw new NoDataRightException();
        }

        public override void CheckDelete(object type, object ownerId)
        {
            CheckReadWrite(type, ownerId);
        }

        public override void CheckPublic(object type, object ownerId)
        {
            UserList list = GetUserList(type);
            if (list.ROUserList.Count == 0)
                return;
            if (!(list.RWUserList.Contains(ownerId.ToString()) || list.ROUserList.Contains(ownerId.ToString())))
                throw new NoDataRightException();
        }

        public override string GetPublicSql(object type, string fieldName, object userID, object data)
        {
            UserList list = GetUserList(type);
            return string.Format("{0} IN ({1})", fieldName, list.PublicList);
        }

        private const string DataSQL = "SELECT ORG_ID, ORG_LAYER, ORG_PARENT_ID FROM SYS_ORGANIZATION "
            + ",UR_USERS WHERE USER_ORG_ID = ORG_ID AND USER_ID = '{0}'";
        private const string SubComSQL = "SELECT ORG_ID FROM SYS_ORGANIZATION WHERE ORG_LAYER LIKE '{0}%'";
        private const string SubUserSQL = "SELECT USER_ID FROM UR_USERS WHERE USER_ORG_ID IN "
            + "(SELECT ORG_ID FROM SYS_ORGANIZATION WHERE ORG_LAYER LIKE '{0}%' AND ORG_LAYER <> '{0}')";

        public override void Initialize(object data)
        {
            BaseDataSet dataSet = new BaseDataSet();
            fUserCollection.Clear();

            dataSet.ConnectionStr = fConnStr;
            TableSelector selector = new TableSelector(dataSet);
            object userID = ((IUserInfo)data).UserID;
            string sql = string.Format(DataSQL, userID);

            using (dataSet)
            {
                selector.SelectSql("SYS_ORGANIZATION", sql);
                DataTable table = dataSet.Tables["SYS_ORGANIZATION"];
                if (table.Rows.Count == 0)
                {
                }
                DataRow row = table.Rows[0];

                sql = string.Format(SubComSQL, row["ORG_LAYER"]);
                selector.SelectSql("SubCom", sql);
//                dataSet.ChangeSql(sql, "SubCom");
                table = dataSet.Tables["SubCom"];
                foreach (DataRow comRow in table.Rows)
                {
                    string comID = comRow["ORG_ID"].ToString();
                    fComUserList.ROUserList.Add(comID);
                    fComUserList.RWUserList.Add(comID);
                }
                fComUserList.InitializePublicList();

                sql = string.Format(SubUserSQL, row["ORG_LAYER"]);
                selector.SelectSql("SubUser", sql);
//                dataSet.ChangeSql(sql, "SubUser");
                table = dataSet.Tables["SubUser"];
                fUsersUserList.ROUserList.Add(userID.ToString());
                fUsersUserList.RWUserList.Add(userID.ToString());
                foreach (DataRow userRow in table.Rows)
                {
                    string subUserID = userRow["USER_ID"].ToString();
                    fUsersUserList.ROUserList.Add(subUserID);
                    fUsersUserList.RWUserList.Add(subUserID);
                }
                fUsersUserList.InitializePublicList();

                fOwnerList.ROUserList.Add(userID.ToString());
                fOwnerList.RWUserList.Add(userID.ToString());
                fOwnerList.InitializePublicList();
            }       
        }
	}
}
