using System;
using System.Configuration;
using System.Web;
using System.Data;
using System.Collections.Specialized;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;
using YJC.Toolkit.Xml;
using YJC.Toolkit.Exception;
using YJC.Toolkit.SysUtil;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// PostLoginDataSet ��ժҪ˵����
	/// </summary>
	public class PostLoginDataSet: BaseDataSet, IHttpPost2Page
	{
		public PostLoginDataSet():base()
		{
			
		}

		public string Post(YJC.Toolkit.Sys.PageStyle style, string operation, NameValueCollection queryString, NameValueCollection form)
		{
			try
			{
				bool fNewUser = false;
				UsersResolver fUserResolver = new UsersResolver(this);
				string name = form["username"];
				string password = form["password"];
				DataRow row = fUserResolver.CheckUserLogin(name, password, 1, GlobalVariable.Info, ref fNewUser);
				return "0";
			}
			catch
			{
				return "1";
			}
		}

		public string GetJScript(YJC.Toolkit.Sys.PageStyle style, string operation)
		{
			return null;
		}

		#region IXml2Page ��Ա

		public string GetDefaultPage(bool isPost, YJC.Toolkit.Sys.PageStyle style, string operation, YJC.Toolkit.Sys.PageX pageX, string retURL)
		{
			// TODO:  ���� PostLoginDataSet.GetDefaultPage ʵ��
			return null;
		}

		public string GetXsltFile(bool isIe, YJC.Toolkit.Sys.PageStyle style, string operation)
		{
			// TODO:  ���� PostLoginDataSet.GetXsltFile ʵ��
			return null;
		}

		#endregion

		#region IHttpGet2Page ��Ա

		public void SetData(bool isPost, YJC.Toolkit.Sys.PageStyle style, string operation, NameValueCollection queryString)
		{
			// TODO:  ���� PostLoginDataSet.SetData ʵ��
		}

		#endregion
	}
}