using System;
using System.Data;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// PasswordConstraint ��ժҪ˵����
	/// </summary>
    public class PasswordConstraint : BaseConstraint
    {	
        //������Ϣ
        private string fErrorMsg;
        //�û���ʵ����
        private string fRealPwd;

        public PasswordConstraint(string fieldValue, string realPwd) : 
            base(fieldValue, string.Empty)
        {
			IsFirstCheck = true;
            fRealPwd = realPwd;
        }

        public override BaseErrorObject NewErrorObject(int position)
        {	
            return new BaseErrorObject(FieldName, fErrorMsg, position);
        }

        public override bool CheckError(string value, int position)
        {
            DataTable postTable = PostDataSet.Tables["UR_USERS"];
            DataRow row = postTable.Rows[0];
			string loginName = row["USER_LOGIN_NAME"].ToString();

            if (postTable.Columns.Contains("USER_OLD_PASSWD"))
                if (row["USER_OLD_PASSWD"].ToString() != PasswdUtil.Decrypt(fRealPwd, loginName))
                {
                    fErrorMsg = "�û��������������";
                    return false;
                }

            if (row["USER_LOGIN_PASSWD"].ToString() != row["USER_CONFIRM_PASSWD"].ToString())
            {
                fErrorMsg = "�������벻һ�£�";
                return false;
            }

			int len = PasswdUtil.GetPasswdLengthConfig();
			if (row["USER_LOGIN_PASSWD"].ToString().Length < len)
			{
				fErrorMsg = string.Format("�û����������{0}λ���ϵ����֡���ĸ�������ַ�����ĸ���ִ�Сд��", len);
				return false;
			}

			row["USER_LOGIN_PASSWD"] = PasswdUtil.Encrypt(row["USER_LOGIN_PASSWD"].ToString(), loginName);

            return true;
        }
	
        public override string GetJavaScript()
        {
            return string.Empty;
        }
    }
}
