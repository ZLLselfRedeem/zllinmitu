using System;
using YJC.Toolkit.Data;
using YJC.Toolkit.Web;
using YJC.Toolkit.Xml;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// WebInstallIE6Page ��ժҪ˵����
	/// </summary>
    [WebPage(WebInstallIE6Page.ALIAS_NAME, Description = "�ṩ����΢��IE6���ص�ҳ��", 
         Author = "YJC", CreateDate = "2004-10-03")]
    public class WebInstallIE6Page : WebXml2Page
	{
        internal const string ALIAS_NAME = "InstallIE6Page";

		public WebInstallIE6Page() : base()
		{
            Source = new Empty2DataSet();
            IeXslFile = "../Bin/InstallIE6.xslt";
        }

        protected override void SetData()
        {
        }

        protected override void WritePage()
        {
            Response.Write(Transform.TransformAll(IsIe, TransformPos.None));
        }
	}
}
