using System;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
	public abstract class WebBaseLogoutPage : WebBasePage
	{
		private string fLoginPage;

		public WebBaseLogoutPage() : base()
		{
		}

		protected string LoginPage
		{
			get
			{
				return fLoginPage;
			}
			set
			{
				fLoginPage = value;
			}
		}
		
		protected override void DoGet()
		{
			Session.Abandon();
			Response.Redirect(fLoginPage);
		}
	}
}
