using System;
using System.Collections;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// UserCollection ��ժҪ˵����
	/// </summary>
	internal class UserCollection : Hashtable
	{
		public UserCollection() : base()
		{
		}

        public UserList this[string type] 
        {
            get
            {
                return (UserList)base[type];
            }
        }

        public void Add(object type, UserList users) 
        {
            base.Add(type, users);
        }

        public new void Clear()
        {
            foreach (object userList in this.Values)
                ((UserList)userList).Clear();
        }
	}
}
