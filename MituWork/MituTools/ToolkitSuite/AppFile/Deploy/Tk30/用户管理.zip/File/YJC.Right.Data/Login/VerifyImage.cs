using System;
using System.Web;
using System.Configuration;
using YJC.Toolkit.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using System.Drawing; 
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// ����ͼƬ��֤��
	/// </summary>
	[WebPage(VerifyImage.REG_NAME ,Description = "����ͼƬ��֤��", Author = "ShiXin", CreateDate = "2006-2-6")]
	public class VerifyImage : WebDataSet2Page
	{
		internal const	string REG_NAME = "VerifyImage" ;
		public VerifyImage() :base()
		{
			SupportLogin = false ;
			Source = new Empty2DataSet();
		}

		protected override void DoGet()
		{		
			Response.ClearContent();
			Response.ContentType = "image/jpeg";
			string verifyKey = "";
			Response.BinaryWrite(GenerateVerifyImage(5, Request.QueryString["Rgb"], Request.QueryString["FontColor"], ref verifyKey));
			string key = Request.QueryString["Key"];
			if (key != null && key != "")
			{
				string config = LoginUtil.GetConfig("VerifyKeys", "");
				if (config.IndexOf("," + key + ",") < 0)
					key = "VerifyKey";
			}
			else
				key = "VerifyKey";
			GlobalVariable.Session[key] = verifyKey;
			Response.End();
		}
 
		/// <summary>
		/// ���ɿ�ͨͼƬ��֤��
		/// </summary>
		/// <param name="nLen">��֤��ĳ���</param>
		/// <param name="strKey">�����������֤�������</param>
		/// <returns>ͼƬ�ֽ���</returns>
		public byte[] GenerateVerifyImage(int nLen, string rgb, string fontColor, ref string strKey)
		{
			System.Random rd = new Random((int)System.DateTime.Now.Ticks);
			int nBmpWidth = 13 * nLen + 5;
			int nBmpHeight = 20;
			System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(nBmpWidth, nBmpHeight);
			
			// 1. �������������ɫ
			int nRed, nGreen, nBlue;  // ��������Ԫɫ
			nRed = rd.Next(255) % 128 + 128;
			nGreen = rd.Next(255) % 128 + 128;
			nBlue = rd.Next(255) % 128 + 128;
			GetRGB(rd, rgb, ref nRed, ref nGreen, ref nBlue);

			System.Drawing.Graphics graph = System.Drawing.Graphics.FromImage(bmp);
			// 2. ���λͼ����
			graph.FillRectangle(new SolidBrush(System.Drawing.Color.FromArgb(nRed, nGreen, nBlue)), 0, 0, nBmpWidth, nBmpHeight);

			// 3. ���Ƹ������������ñȱ�������һЩ����ɫ
			int nLines = 3;
			System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(nRed - 17, nGreen - 17, nBlue - 17), 2);
			for (int i = 0; i < nLines; i++)
			{
				int x1 = rd.Next() % nBmpWidth;
				int y1 = rd.Next() % nBmpHeight;
				int x2 = rd.Next() % nBmpWidth;
				int y2 = rd.Next() % nBmpHeight;
				graph.DrawLine(pen, x1, y1, x2, y2);
			}
		
			// ���õ��ַ����������漴��չ�������Կ����ַ����ֵļ���
			string strCode = "0123456789";//"ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			// 4. ѭ��ȡ���ַ���������
			int fontRed, fontGreen, fontBlue;//�ַ�����Ԫɫ
			string strResult = "";
			for(int i = 0; i < nLen; i++)
			{
				int x = (i * 13 + rd.Next(3));
				int y = rd.Next(4) + 1;

				// ȷ������
				System.Drawing.Font font = new System.Drawing.Font("Courier New", 11 + rd.Next() % 4, System.Drawing.FontStyle.Bold);
				char c = strCode[rd.Next(strCode.Length)];  // �����ȡ�ַ�
				strResult += c.ToString();

				// �����ַ�
				fontRed = nRed - 60 + y * 3;
				fontGreen = nGreen - 60 + y * 3;
				fontBlue = nBlue - 40 + y * 3;
				GetRGB(rd, fontColor, ref fontRed, ref fontGreen, ref fontBlue);
				graph.DrawString(c.ToString(), font, new SolidBrush(System.Drawing.Color.FromArgb(fontRed, fontGreen, fontBlue)), x, y);
			}

			// 5. ����ֽ���
			System.IO.MemoryStream bstream = new System.IO.MemoryStream();
			bmp.Save(bstream,System.Drawing.Imaging.ImageFormat.Jpeg);
			bmp.Dispose();
			graph.Dispose();

			strKey = strResult;
			byte[] byteReturn = bstream.ToArray();
			bstream.Close();

			return byteReturn;
		}

		private void GetRGB(System.Random rd, string color, ref int nRed, ref int nGreen, ref int nBlue)
		{
			if (color == null || color == "" || color == "-1")
				return;
			if (color.IndexOf(",") < 0)
			{
				try
				{
					long lgColor = Convert.ToInt64(color.Substring(1), 16);
					long lgBlue = lgColor / 65536;
					long lgGreen = (lgColor - nBlue * 65536) / 256;
					long lgRed = lgColor - nGreen * 256 - nBlue * 65536;
					nBlue = int.Parse(lgBlue.ToString());
					nGreen = int.Parse(lgGreen.ToString());
					nRed = int.Parse(lgRed.ToString());
				}
				catch
				{
				}
			}
			else
			{
				string[] rgbArray = color.Split(',');
				try
				{
					nRed = int.Parse(rgbArray[0]);
				}
				catch
				{
					nRed = 0;
				}
				try
				{
					nGreen = int.Parse(rgbArray[1]);
				}
				catch
				{
					nGreen = 0;
				}
				try
				{
					nBlue = int.Parse(rgbArray[2]);
				}
				catch
				{
					nBlue = 0;
				}
			}
		}
	}
}
