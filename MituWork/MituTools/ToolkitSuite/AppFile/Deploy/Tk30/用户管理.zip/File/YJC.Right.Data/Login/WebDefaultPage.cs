using System;
using System.Configuration;
using YJC.Toolkit.Web;
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// WebDefaultPage ��ժҪ˵����
	/// </summary>
    [WebPage(WebDefaultPage.ALIAS_NAME, Description = "ȱʡҳ�棬����Ƿ�װIE6", 
         Author = "YJC", CreateDate = "2004-10-03")]
    public class WebDefaultPage : WebBasePage
	{
        internal const string ALIAS_NAME = "DefaultPage";
        
        public WebDefaultPage() : base()
		{
		}

        protected override void DoGet()
        {
			if (Request.Browser.MajorVersion >= 6)
			{
				Response.Redirect(LoginUtil.GetDefaultPageConfig());
			}
			else
				Response.Redirect(string.Format("../Library/WebInitPage.{0}?Source=InstallIE6Page", PageX.ToString()));
        }
	}
}
