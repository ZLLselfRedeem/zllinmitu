using System;
using YJC.Toolkit.ConfigXml;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// SmsSendAttribute ��ժҪ˵����
	/// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public sealed class SmsSendAttribute : BaseAttribute
	{
        public SmsSendAttribute(string regName) : base(regName)
		{
        }
	}
}