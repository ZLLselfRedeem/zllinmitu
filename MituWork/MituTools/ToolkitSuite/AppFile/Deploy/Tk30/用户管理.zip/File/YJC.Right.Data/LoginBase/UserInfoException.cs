using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// UserInfoException ��ժҪ˵����
	/// </summary>
    public class UserInfoException : LoginException
    {
        private class UserInfoErrorObject : BaseErrorObject
        {
            public UserInfoErrorObject() : base("LOGIN_NAME", 
                LoginResUtil.GetResourceString("UserInfo"), 0)
            {
            }
        }

        public UserInfoException() : base()
        {
            ErrorObject = new UserInfoErrorObject();
        }
    }
}
