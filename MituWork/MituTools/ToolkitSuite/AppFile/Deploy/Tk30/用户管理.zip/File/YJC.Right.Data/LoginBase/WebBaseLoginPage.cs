using System;
using YJC.Toolkit.Exception;
using YJC.Toolkit.Sys;
using YJC.Toolkit.SysUtil;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
	public class WebBaseLoginPage : WebXmlHttp2Page
	{
        private string fDefaultPage;

		public WebBaseLoginPage() 
		{
		}

		protected string DefaultPage
		{
			get
			{
				return fDefaultPage;
			}
			set
			{
				fDefaultPage = value;
			}
		}

		public LoginBaseDataSet Generator
		{
			get
			{
				return (LoginBaseDataSet)Source;
			}
		}

		protected override void DoPost()
		{
            base.DoPost();

			SucceedCommit();
		}

		protected override void HandleInformation(InformationException ex)
		{
			string content = GetXmlString();
            Response.ContentEncoding = System.Text.Encoding.UTF8;
			Response.Write(TransformUtil.Transform(content, Transform.IeFiles.Content));
		}

		protected string RedirectPath()
		{
			string retURL = Request.QueryString["RetURL"];
			if (IsPost)
				retURL = PostDataSet.Tables["OtherInfo"].Rows[0]["Save"].ToString();
			return (retURL == string.Empty) ? fDefaultPage : retURL;
		}

	}
}
