using System;
using System.Globalization;
using System.Reflection;
using System.Resources;
using YJC.Toolkit.Sys;
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// LoginResUtil ��ժҪ˵����
	/// </summary>
	internal sealed class LoginResUtil
	{
        private static Assembly fAssembly = null;
        private static ResourceManager fRm = null;
        private static CultureInfo fCulture = null;
        
        private LoginResUtil()
		{
		}

        private static void GetResourceManager()
        {
            fRm = ResourceUtil.GetResourceManager(LoginAssembly, "Login");
        }

        /// <summary>
        /// Toolkit�Լ���Assembly����
        /// </summary>
        public static Assembly LoginAssembly
        {
            get
            {
                if (fAssembly == null)
                    fAssembly = Assembly.GetAssembly(typeof(LoginResUtil));
                return fAssembly;
            }
        }

        /// <summary>
        /// �����Դ�ļ�������
        /// </summary>
        /// <param name="resName">��Դ�ļ�����</param>
        /// <returns>��Դ�ļ�������</returns>
        public static string GetResourceString(string resName)
        {
            if (fRm == null)
                GetResourceManager();
            if (fCulture == null)
                fCulture = AppSettings.Current.Culture;
            return fRm.GetString(resName, fCulture);
        }
	}
}
