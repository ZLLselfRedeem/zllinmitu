using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// UserFiredException ��ժҪ˵����
	/// </summary>
    public class UserFiredException : LoginException
    {
        private class UserFiredErrorObject : BaseErrorObject
        {
            public UserFiredErrorObject() : base("LOGIN_NAME", 
                LoginResUtil.GetResourceString("UserFired"), 0)
            {
            }
        }

        public UserFiredException() : base()
        {
            ErrorObject = new UserFiredErrorObject();
        }
    }
}
