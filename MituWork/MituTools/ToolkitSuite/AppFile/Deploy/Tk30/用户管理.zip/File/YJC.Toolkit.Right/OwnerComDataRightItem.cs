using System;
using System.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// OwnerComDataRightItem ��ժҪ˵����
	/// </summary>
	public class OwnerComDataRightItem : DataRightItem
	{
		public OwnerComDataRightItem() : base("ownercom")
		{
		}

        public override void Initialize(object data)
        {
			Clear();
			BaseDataSet dataSet = new BaseDataSet();
			dataSet.ConnectionStr = AppSettings.Current.ConnectionString;
			TableSelector selector = new TableSelector(dataSet) ;
			object userID = ((IUserInfo)data).UserID ;
 
			using (dataSet)
			{
				selector.SelectSql("SYS_ORGANIZATION", string.Format("SELECT ORG_ID, ORG_LAYER, ORG_PARENT_ID " + 
					"FROM SYS_ORGANIZATION,UR_USERS WHERE USER_ORG_ID = ORG_ID AND USER_ID = '{0}'", userID)) ;
				if (dataSet.Tables.Contains("SYS_ORGANIZATION") && dataSet.Tables["SYS_ORGANIZATION"].Rows.Count > 0)
				{
					string comID = dataSet.Tables["SYS_ORGANIZATION"].Rows[0]["ORG_ID"].ToString();
					ROList.Add(comID);
					RWList.Add(comID);
				}
				InitializePublicString() ;
			}
		}

        public override string GetPublicSql(string fieldName, object userID)
        {
            return string.Format("{0} = {1}", fieldName, PublicString) ;
        }
	}
}
