using System;
using System.Text;
using System.Web.Mail;
using System.Configuration;
using System.Security.Cryptography;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// PasswdUtil ��ժҪ˵����
	/// </summary>
	public sealed class PasswdUtil
	{
		public PasswdUtil()
		{
		}

		public static string GetPasswdBodyConfig()
		{
			return LoginUtil.GetConfig("GetPasswdBody", "����ϵͳ�˺��ǣ�{Name}������{Password}");
		}

		public static string GetSmsSendConfig()
		{
			return LoginUtil.GetConfig("SmsSend", "");
		}

		public static int GetPasswdLengthConfig()
		{
			string len = LoginUtil.GetConfig("PasswdLength", "6");
			return int.Parse(len);
		}

		public static string Encrypt(string toEncrypt, string key)
		{
			if (toEncrypt == "")
				return "";

			byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

			TripleDESCryptoServiceProvider tdes = GetTripleDES(key);
			byte[] resultArray = CryptoTransform(tdes.CreateEncryptor(), toEncryptArray);
			tdes.Clear();

			return Convert.ToBase64String(resultArray, 0, resultArray.Length);
		}

		public static string Decrypt(string cryptString, string key)
		{
			if (cryptString == "")
				return "";

			byte[] toEncryptArray = Convert.FromBase64String(cryptString);

			TripleDESCryptoServiceProvider tdes = GetTripleDES(key);
			byte[] resultArray = CryptoTransform(tdes.CreateDecryptor(), toEncryptArray);
			tdes.Clear();

			return UTF8Encoding.UTF8.GetString(resultArray);
		}

		private static TripleDESCryptoServiceProvider GetTripleDES(string key)
		{
			MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
			byte[] keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
			hashmd5.Clear();

			TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
			tdes.Key = keyArray;
			tdes.Mode = CipherMode.ECB;
			tdes.Padding = PaddingMode.PKCS7;

			return tdes;
		}

		private static byte[] CryptoTransform(ICryptoTransform cTransform, byte[] toEncryptArray)
		{
			return cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
		}
	}
}
