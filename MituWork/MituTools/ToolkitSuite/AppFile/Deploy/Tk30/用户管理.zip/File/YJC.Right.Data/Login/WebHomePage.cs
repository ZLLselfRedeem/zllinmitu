using System;
using YJC.Toolkit.Data;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// WebHomePage ��ժҪ˵����
	/// </summary>
    [WebPage(WebHomePage.ALIAS_NAME, Description = "��ҳ", Author = "YJC", CreateDate = "2004-10-04")]
    public class WebHomePage : WebXml2Page
	{
        internal const string ALIAS_NAME = "HomePage";

        public WebHomePage()
		{
            Source = new WebHomePageDataSet();
            IeXslFile = "../Bin/HomePage.xslt";
            SupportLogin = true;
		}
	}
}
