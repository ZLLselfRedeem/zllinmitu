using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// PasswordInvalidException ��ժҪ˵����
	/// </summary>
    public class PasswordInvalidException : LoginException
    {
        public class PasswordInvalidErrorObject : BaseErrorObject
        {
            public PasswordInvalidErrorObject() : base("LoginPassword", 
                LoginResUtil.GetResourceString("PasswordInvalid"), 0)
            {
            }
        }
        public PasswordInvalidException() : base(new PasswordInvalidErrorObject())
        {
        }
    }
}
