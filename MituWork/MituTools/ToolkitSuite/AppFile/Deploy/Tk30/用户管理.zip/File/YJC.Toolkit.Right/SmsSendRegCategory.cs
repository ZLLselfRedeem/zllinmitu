using System;
using System.Diagnostics;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Data;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// SmsSendRegCategory ��ժҪ˵����
	/// </summary>
	public class SmsSendRegCategory : RegCategory
	{
        public const string REG_NAME = "SmsSend";
 
        public SmsSendRegCategory() : base(REG_NAME, @"Data\", typeof(SmsSendAttribute), typeof(SmsSend))
		{
		}
        
        public SmsSend NewSmsSend(string regName) 
		{
			object item = this[regName];
			if (item == null)
				throw new ArgumentException(string.Format("���ŷ��Ͳ��{0}δע�ᣡ", regName));            
			SmsSend result = ((RegItem)item).NewInstance() as SmsSend;
			result.ClassAssembly = ((RegItem)item).RegAssembly;
			return result;
		}

		public static SmsSendRegCategory GetRegCategory(string regName)
		{
			RegCategory category = (RegCategory)GlobalVariable.RegsCollection[regName];
			Debug.Assert(category != null, string.Format("û�з���ע����Ϊ{0}��ϵͳע�ᡣ", regName));
			return category as SmsSendRegCategory;
		}
	}
}