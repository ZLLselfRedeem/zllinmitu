using System;
using System.Data;
using YJC.Toolkit.DataAccess;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// PartSubFuncResolver ��ժҪ˵����
	/// </summary>
	public class PartSubFuncResolver : TableResolver
	{
		public PartSubFuncResolver(DataSet hostDataSet) : base(hostDataSet)
		{
			Fields = "PSF_PART_ID, PSF_SF_ID, PSF_IS_FUNC";
            KeyFields = "PSF_PART_ID, PSF_SF_ID";
            TableName = "SYS_PART_SUB_FUNC";
		}
	}
}
