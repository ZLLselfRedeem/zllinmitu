using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// UserLockedException ��ժҪ˵����
	/// </summary>
    public class UserLockedException : LoginException
    {
        private class UserLockedErrorObject : BaseErrorObject
        {
            public UserLockedErrorObject() : base("LOGIN_NAME", 
                LoginResUtil.GetResourceString("UserLocked"), 0)
            {
            }
        }
        public UserLockedException() : base()
        {
            ErrorObject = new UserLockedErrorObject();
        }
    }
}
