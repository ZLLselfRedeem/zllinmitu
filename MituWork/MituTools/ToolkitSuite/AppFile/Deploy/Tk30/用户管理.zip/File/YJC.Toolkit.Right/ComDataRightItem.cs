using System;
using System.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// ComDataRightItem ��ժҪ˵����
	/// </summary>
	public class ComDataRightItem : DataRightItem
	{
		public ComDataRightItem() : base("com")
		{
		}

        public override void Initialize(object data)
        {
			Clear();
			BaseDataSet dataSet = new BaseDataSet();
			dataSet.ConnectionStr = AppSettings.Current.ConnectionString;
			TableSelector selector = new TableSelector(dataSet) ;
			object userID = ((IUserInfo)data).UserID ;
 
			using (dataSet)
			{
				selector.SelectSql("SYS_ORGANIZATION", string.Format("SELECT ORG_ID, ORG_LAYER, ORG_PARENT_ID " + 
					"FROM SYS_ORGANIZATION,UR_USERS WHERE USER_ORG_ID = ORG_ID AND USER_ID = '{0}'", userID)) ;
				if (dataSet.Tables.Contains("SYS_ORGANIZATION") && dataSet.Tables["SYS_ORGANIZATION"].Rows.Count > 0)
				{
					DataRow row = dataSet.Tables["SYS_ORGANIZATION"].Rows[0] ;
					selector.SelectSql("SubCom", string.Format("SELECT ORG_ID FROM SYS_ORGANIZATION WHERE ORG_LAYER LIKE '{0}%'", row["ORG_LAYER"])) ;
					foreach (DataRow subRow in dataSet.Tables["SubCom"].Rows)
					{
						string subComID = subRow["ORG_ID"].ToString();
						ROList.Add(subComID);
						RWList.Add(subComID);
					}
				}
				InitializePublicString() ;
			}
		}

        public override string GetPublicSql(string fieldName, object userID)
        {
            return string.Format("{0} IN ({1})", fieldName, PublicString) ;
        }
	}
}
