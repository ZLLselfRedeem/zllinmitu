using System;
using System.Data;
using System.Collections.Specialized;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Provider;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	[Resolver(SubFuncResolver.REG_NAME, Description = "��SYS_SUB_FUNC�����ݷ��ʲ���", Author = "ShiXin", CreateDate = "2007-09-21")]
	public class SubFuncResolver : Xml2TableResolver
    {
		internal const string REG_NAME = "SubFunc";
		public SubFuncResolver(DataSet hostDataSet) : base(hostDataSet)
        {
			XmlFile = "Users/SubFunc.xml";
			AutoUpdating = false;

			if (HostDataSet is WebUpdate2DataSet)
				(HostDataSet as WebUpdate2DataSet).FilledInsertTables += new FilledInsertEventHandler(SubFuncResolver_FilledInsertTables);
        }

		protected override void OnUpdatingRow(UpdatingEventArgs e)
		{
			base.OnUpdatingRow(e);
			
			switch (e.Status)
			{
				case UpdateKind.Insert :
					e.Row["SF_ID"] = GlobalProvider.GetUniID(TableName, DbConnection);
					break;
				case UpdateKind.Update :
					break;
			}
			
		}
		
		protected override void AddConstraints(UpdateKind status)
		{
			base.AddConstraints(status);
			this.Constraints.Add(new UniqueRowConstraint("SF_NAME_ID", GetFieldDisplayName("SF_NAME_ID")));
		}

		private void SubFuncResolver_FilledInsertTables(object sender, FilledInsertEventArgs e)
		{
			if (!e.IsPost && HostTable != null)
			{
				HostTable.Clear();
				string[] nameArray = new string[] { "�½�", "�޸�", "ɾ��", "�б�", "��ϸ" };
				for (int i=0; i<5;)
				{
					DataRow row = HostTable.NewRow();
					HostTable.Rows.Add(row);
					row.BeginEdit();
					row["SF_NAME"] = nameArray[i];
					row["SF_NAME_ID"] = (++i).ToString("00");
					row.EndEdit();
				}
			}
		}
	}
}
