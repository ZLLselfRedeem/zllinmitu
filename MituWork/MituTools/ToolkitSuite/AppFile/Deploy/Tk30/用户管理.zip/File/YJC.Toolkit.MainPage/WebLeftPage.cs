using System;
using System.Diagnostics;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Web
{
	/// <summary>
	/// WebLeft ��ժҪ˵����
	/// </summary>
	public class WebLeftPage : WebBasePage
	{
		public WebLeftPage() : base()
		{
			SupportLogin = true;
		}

        protected override void DoGet()
        {
            OutlookRegCategory outlook = (OutlookRegCategory)AppGbl.RegsCollection[OutlookRegCategory.REG_NAME];
            Debug.Assert(outlook != null, "������û��ע��Outlook������");

            string html = outlook.GetOutlookHtml();
            string fmtStr = ResUtil.GetResourceString("LeftHtml");
            Response.Write(string.Format(fmtStr, html));
        }

	}
}
