using System;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Exception;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// VerifyException ��ժҪ˵����
	/// </summary>
	public class VerifyException : LoginException
	{
		public class VerifydErrorObject : BaseErrorObject
		{
			public VerifydErrorObject() : base("Verify", "��֤�����",0)
			{
			}
		}

		public VerifyException() : base(new VerifydErrorObject())
		{
			ErrorObject = new VerifydErrorObject();
		}
	}
}
