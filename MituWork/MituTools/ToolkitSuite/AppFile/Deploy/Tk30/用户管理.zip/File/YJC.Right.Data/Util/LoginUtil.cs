using System;
using System.Configuration;
using YJC.Toolkit.Provider;

namespace YJC.Toolkit.Right.Data
{
	public enum LoginMode { User, UserWithVerify, UserOrg, UserOrgWithVerify }

	/// <summary>
	/// LoginUtil ��ժҪ˵����
	/// </summary>
	public sealed class LoginUtil
	{
		public LoginUtil()
		{
		}

		public static string GetDefaultPageConfig()
		{
			return GetConfig("DefaultPage", "../Library/WebInitPage.tkx?Source=LoginPage");
		}

		public static string GetHomePageWelcomeConfig()
		{
			return GetConfig("HomePageWelcome", "");
		}

		public static string GetHomePageIframeSrcConfig()
		{
			return GetConfig("HomePageIframeSrc", "");
		}

		public static LoginMode GetLoginModeConfig()
		{
			string mode = GetConfig("LoginMode", "User");
			return (LoginMode)Enum.Parse(typeof(LoginMode), mode, true);
		}

		public static int GetPasswdLengthConfig()
		{
			string attempt = GetConfig("LoginAttemptMax", "3");
			return int.Parse(attempt);
		}

		public static string GetConfig(string name, string defaultValue)
		{
			string value = "";
#if _TOOLKIT3
			value = ConfigurationManager.AppSettings[name];
#else
			value = ConfigurationSettings.AppSettings[name];
#endif
			if (value == null || value == "")
				value = defaultValue;

			return value;
		}
	}
}
