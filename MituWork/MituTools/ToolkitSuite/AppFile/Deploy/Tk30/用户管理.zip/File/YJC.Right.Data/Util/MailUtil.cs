using System;
#if _TOOLKIT3
	using System.Net;
	using System.Net.Mail;
#else
	using System.Web.Mail;
#endif
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// MailUtil ��ժҪ˵����
	/// </summary>
	public sealed class MailUtil
	{
		public MailUtil()
		{
		}

		public static void GaoDuSend(string to, string subject, string body)
		{
			MailConfig config = GetGMailConfig("hzgaodu@gmail.com", "gaodu12345");
			config.To = to;
			config.Subject = subject;
			config.Body = body;
			config.IsHtml = true;
			Send(config);
		}

		public static MailConfig GetGMailConfig(string account, string accountPassword)
		{
			MailConfig config = new MailConfig();
			config.IsSmtpAuthentication = true;
			config.Account = account;
			config.AccountPassword = accountPassword;
			config.SmtpServer = "smtp.gmail.com";
			config.SmtpPort = "465";
			config.SmtpUseSSL = true;

			return config;
		}

		public static MailConfig GetYahooMailConfig(string account, string accountPassword)
		{
			MailConfig config = new MailConfig();
			config.IsSmtpAuthentication = true;
			config.Account = account;
			config.AccountPassword = accountPassword;
			config.SmtpServer = "smtp.mail.yahoo.com.cn";

			return config;
		}

		public static void Send(MailConfig config)
        {
#if _TOOLKIT3
            MailMessage msg = new MailMessage(config.From, config.To, config.Subject, config.Body);
            if (!StringUtil.IsEmpty(config.Cc))
            {
                string[] ccArray = config.Cc.Split(new char[] { ';', ',' });
                foreach (string cc in ccArray)
                    msg.CC.Add(cc);
            }
            msg.IsBodyHtml = config.IsHtml;

            SmtpClient client = new SmtpClient(config.SmtpServer, int.Parse(config.SmtpPort));
            if (config.IsSmtpAuthentication)
                client.Credentials = new NetworkCredential(config.Account, config.AccountPassword);
            client.EnableSsl = config.SmtpUseSSL;
            client.Send(msg);
#else
            MailMessage msg = new MailMessage();
			msg.Subject = config.Subject;
			msg.Body = config.Body;
			msg.From = config.From;
			msg.To = config.To;
			msg.Cc = config.Cc;
            if (config.IsHtml)
				msg.BodyFormat = MailFormat.Html;
            if(config.IsSmtpAuthentication)
			{
				msg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate", "1" ); 
				msg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendusername", config.Account);
				msg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/sendpassword", config.AccountPassword);
			}

			if(config.SmtpPort != "25")
				msg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpserverport", config.SmtpPort);

			if(config.SmtpUseSSL)
				msg.Fields.Add("http://schemas.microsoft.com/cdo/configuration/smtpusessl", "1");

			SmtpMail.SmtpServer = config.SmtpServer;
			SmtpMail.Send(msg);
#endif
        }
	}

	public class MailConfig
	{
		public MailConfig()
		{
		}

		private string fSmtpServer;
		public string SmtpServer
		{
			get
			{
				return fSmtpServer;
			}
			set
			{
				fSmtpServer = value;
			}
		}

		private bool fIsSmtpAuthentication = false;
		public bool IsSmtpAuthentication
		{
			get
			{
				return fIsSmtpAuthentication;
			}
			set
			{
				fIsSmtpAuthentication = value;
			}
		}

		private string fAccount;
		public string Account
		{
			get
			{
				return fAccount;
			}
			set
			{
				fAccount = value;
				fFrom = value;
			}
		}

		private string fAccountPassword;
		public string AccountPassword
		{
			get
			{
				return fAccountPassword;
			}
			set
			{
				fAccountPassword = value;
			}
		}

		private string fFrom;
		public string From
		{
			get
			{
				return fFrom;
			}
			set
			{
				fFrom = value;
			}
		}

		private string fTo;
		public string To
		{
			get
			{
				return fTo;
			}
			set
			{
				fTo = value;
			}
		}

		private string fCc;
		public string Cc
		{
			get
			{
				return fCc;
			}
			set
			{
				fCc = value;
			}
		}

		private string fSmtpPort = "25";
		public string SmtpPort
		{
			get
			{
				return fSmtpPort;
			}
			set
			{
				fSmtpPort = value;
			}
		}

		private bool fSmtpUseSSL = false;
		public bool SmtpUseSSL
		{
			get
			{
				return fSmtpUseSSL;
			}
			set
			{
				fSmtpUseSSL = value;
			}
		}

		private string fSubject;
		public string Subject
		{
			get
			{
				return fSubject;
			}
			set
			{
				fSubject = value;
			}
		}

		private string fBody;
		public string Body
		{
			get
			{
				return fBody;
			}
			set
			{
				fBody = value;
			}
		}

		private bool fIsHtml = false;
		public bool IsHtml
		{
			get
			{
				return fIsHtml;
			}
			set
			{
				fIsHtml = value;
			}
		}
	}
}
