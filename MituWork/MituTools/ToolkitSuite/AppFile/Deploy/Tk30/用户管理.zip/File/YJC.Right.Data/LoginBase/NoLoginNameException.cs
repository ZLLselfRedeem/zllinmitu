using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// NoLoginNameException ��ժҪ˵����
	/// </summary>
    public class NoLoginNameException : LoginException
    {
        public class NoLoginNameErrorObject : BaseErrorObject
        {
            public NoLoginNameErrorObject() : base("LOGIN_NAME", 
                LoginResUtil.GetResourceString("NoLoginName"), 0)
            {
            }
        }

        public NoLoginNameException() : base(new NoLoginNameErrorObject())
        {
        }
    }
}
