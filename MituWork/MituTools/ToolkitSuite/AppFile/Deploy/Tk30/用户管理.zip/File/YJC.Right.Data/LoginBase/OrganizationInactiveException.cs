using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// OrganizationInactiveException ��ժҪ˵����
	/// </summary>
    public class OrganizationInactiveException : LoginException
    {
        private class OrganizationInactiveObject : BaseErrorObject
        {
            public OrganizationInactiveObject() : base("ORG_CODE", 
                LoginResUtil.GetResourceString("OrganizationInactive"), 0)
            {
            }
        }

        public OrganizationInactiveException() : base()
        {
            ErrorObject = new OrganizationInactiveObject();
        }
    }
}
