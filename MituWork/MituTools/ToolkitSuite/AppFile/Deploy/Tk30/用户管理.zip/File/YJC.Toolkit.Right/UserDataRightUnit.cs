using System;
using System.Data;
using System.Text;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// UserDataRightUnit ��ժҪ˵����
	/// </summary>
	public class UserDataRightUnit : EmptyDataRight2Unit
	{
        private string fInString;

        public UserDataRightUnit() : base("user")
		{

        }

        public override void Initialize(object data)
        {
            fInString = string.Empty;
            BaseDataSet dataSet = new BaseDataSet();
            dataSet.ConnectionStr = AppSettings.Current.ConnectionString;
            TableSelector selector = new TableSelector(dataSet);
            object userID = ((IUserInfo)data).UserID;
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat("'{0}'", userID);
 
            using (dataSet)
            {
                selector.SelectSql("SYS_ORGANIZATION", string.Format("SELECT ORG_ID, ORG_LAYER, ORG_PARENT_ID " + 
                    "FROM SYS_ORGANIZATION,UR_USERS WHERE USER_ORG_ID = ORG_ID AND USER_ID = '{0}'", userID)) ;
                if (dataSet.Tables.Contains("SYS_ORGANIZATION") && dataSet.Tables["SYS_ORGANIZATION"].Rows.Count > 0)
                {
                    DataRow row = dataSet.Tables["SYS_ORGANIZATION"].Rows[0] ;
                    selector.SelectSql("SubUser", string.Format("SELECT USER_ID FROM UR_USERS WHERE USER_ORG_ID IN "
                        + "(SELECT ORG_ID FROM SYS_ORGANIZATION WHERE ORG_LAYER LIKE '{0}%' " + 
                        "AND ORG_ID <> '{1}')", row["ORG_LAYER"], row["ORG_ID"])) ;
                    foreach (DataRow subRow in dataSet.Tables["SubUser"].Rows)
                    {
                        string subUserID = subRow["USER_ID"].ToString();
                        builder.AppendFormat(", '{0}'", subUserID);
                    }
                }
                fInString = builder.ToString();
            }        
        }

        public override IParamBuilder GetPublicSql(string fieldName, object userID)
        {
            if (fInString == string.Empty)
                return null;
            return InSQLParamBuilder.CreateSQLParamBuilder(fieldName, fInString);

        }


	}
}
