using System;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Exception;

namespace YJC.Toolkit.Right.Data
{
	public class LoginException : BaseException
	{
        private BaseErrorObject fErrorObject;

		public LoginException() : base(ExceptionType.Information)
		{
		}

		public LoginException(BaseErrorObject errorObject) : this()
		{
			ErrorObject = errorObject;
		}

		public BaseErrorObject ErrorObject
		{
			get
			{
				return fErrorObject;
			}
			set
			{
				fErrorObject = value;
			}
		}
	}
}
