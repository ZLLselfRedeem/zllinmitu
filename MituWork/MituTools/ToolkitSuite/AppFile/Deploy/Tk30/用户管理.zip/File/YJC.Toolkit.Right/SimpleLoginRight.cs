using System;
using YJC.Toolkit.Data;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// SimpleLoginRight ��ժҪ˵����
	/// </summary>
	public class SimpleLoginRight : SimpleAbstractLoginRight
	{
		public SimpleLoginRight(IUserInfo info) : base(info)
		{
            LoginPage = "../Library/WebInitPage.tkx?Source=LoginPage";
		}
	}
}
