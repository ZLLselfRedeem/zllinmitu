using System;
using System.Collections;
using System.Data;
using System.Text;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;

namespace YJC.Toolkit.Right
{
    /// <summary>
    /// StandardFunctionRight ��ժҪ˵����
    /// </summary>
    public class SimpleFunctionRight : EmptyFunctionRight
    {
        private string fConnStr;
        private StringBuilder fScript;
        private string fScriptString;
        private Hashtable fFunction;
		private Hashtable fShortName;
        private bool fAdmin;
        
        private const string FuncSQL = "SELECT DISTINCT FN_ID, FN_SHORT_NAME, FN_NAME, FN_URL, FN_PARENT_ID, FN_TREE_LAYER, FN_IS_LEAF, " + 
			"(LEN(SYS_FUNCTION.FN_TREE_LAYER) / 3 - 1) AS FN_LAYER FROM {1}, {0} WHERE FN_ID = PF_FN_ID AND (PF_PART_ID IN (SELECT UP_PART_ID FROM UR_USERS_PART " + 
			"WHERE UP_USER_ID = '{2}')) ORDER BY FN_LAYER, FN_TREE_LAYER, FN_ID";
        private const string SubFuncSQL = "SELECT DISTINCT SF_ID, SF_FN_ID, SF_NAME, SF_NAME_ID FROM {0}, {1} WHERE SF_ID = PSF_SF_ID " + 
			"AND (PSF_PART_ID IN (SELECT UP_PART_ID FROM UR_USERS_PART WHERE UP_USER_ID = '{2}')) ORDER BY SF_FN_ID, SF_NAME_ID";
        private const string MenuScript = "  mpmenu{0} = new mMenu('{1}','','mFrame');\n";
        private const string SubMenuScript = "  mpmenu{0}.addItem(new mMenuItem('{1}','{2}','mFrame',false,null));\n";
        private const string NSubMenuScript = "  msub{0}.addsubItem(new mMenuItem('{1}','{2}','mFrame',false,null));\n";
        private const string NewSubMenuScript = "  msub{0} = new mMenuItem('{1}','{2}','mFrame',false,'{3}');\n";
        private const string AddSubMenuScript = "  mpmenu{1}.addItem(msub{0});\n";
        private const string NAddSubMenuScript = "  msub{1}.addsubItem(msub{0});\n";
        private const int BLOCK = 16 * 1024;
        
        public SimpleFunctionRight(string connStr)
        {
            fConnStr = connStr;
            fFunction = new Hashtable();
			fShortName = new Hashtable() ;
        }

        public override string GetMenuScript(object userId)
        {
            return fScriptString;
        }

        public override void Initialize(object data)
        {
            BaseDataSet dataSet = new BaseDataSet();
            fFunction.Clear();
			fShortName.Clear() ;
            fScript = new StringBuilder(BLOCK);

            dataSet.ConnectionStr = fConnStr;
            string funcSql = string.Format(FuncSQL, "SYS_FUNCTION", "SYS_PART_FUNC", ((IUserInfo)data).UserID);
            int nMenu = 0;
            int nSub = 0;

            using (dataSet)
            {
                TableSelector selector = new TableSelector(dataSet);

                selector.Fields = "*";
                selector.TableName = "UR_USERS";
                DataRow userRow = selector.SelectRowWithParam("USER_ID", ((IUserInfo)data).UserID);
                fAdmin = userRow["USER_ADMIN"].ToString() == "1";
    
                selector.SelectSql("SYS_FUNCTION", funcSql);
                DataTable table = selector.HostTable;
                if (table == null)
                    return;
                foreach (DataRow row in table.Rows)
                {
                    int layer = int.Parse(row["FN_LAYER"].ToString());
                    string key = row["FN_ID"].ToString();
                    bool isLeaf = (row["FN_IS_LEAF"].ToString() == "1") ? true : false;
                    FunctionRightItem item = new FunctionRightItem(key);
                    item.IsLeaf = isLeaf;
                    fFunction.Add(key, item);
					if (row["FN_SHORT_NAME"].ToString().Length > 0 && !(fShortName.Contains(row["FN_SHORT_NAME"])))
						fShortName.Add(row["FN_SHORT_NAME"], key) ;
                    if (layer == 0)
                    {
                        item.MenuNum = ++nMenu;
                        fScript.AppendFormat(MenuScript, nMenu, row["FN_NAME"]);
                    }
                    else
                    {
                        FunctionRightItem parentItem = (FunctionRightItem)fFunction[row["FN_PARENT_ID"].ToString()];
                        if (isLeaf)
                        {
                            if (layer == 1)
                                fScript.AppendFormat(SubMenuScript, parentItem.MenuNum, row["FN_NAME"], row["FN_URL"]);
                            else
                                fScript.AppendFormat(NSubMenuScript, parentItem.MenuNum, row["FN_NAME"], row["FN_URL"]);
                        }
                        else
                        {
                            item.MenuNum = ++nSub;
                            fScript.AppendFormat(NewSubMenuScript, nSub, row["FN_NAME"], row["FN_URL"], layer);
                            if (layer == 1)
                                fScript.AppendFormat(AddSubMenuScript, nSub, parentItem.MenuNum);
                            else
                                fScript.AppendFormat(NAddSubMenuScript, nSub, parentItem.MenuNum);
                        }
                    }
                }
                string subFuncSql = string.Format(SubFuncSQL, "SYS_SUB_FUNC", "SYS_PART_SUB_FUNC", ((IUserInfo)data).UserID);
                selector.SelectSql("SYS_SUB_FUNC", subFuncSql);
                table = dataSet.Tables["SYS_SUB_FUNC"];
                if (table == null)
                    return;
                foreach (DataRow row in table.Rows)
                {
                    string key = row["SF_FN_ID"].ToString();
                    FunctionRightItem item = (FunctionRightItem)fFunction[key];
                    if (item == null)
                        continue;
                    if (!item.SubFunc.Contains(row["SF_NAME_ID"]))
                        item.SubFunc.Add(row["SF_NAME_ID"], row["SF_NAME"]);
                }
            }
            fScriptString = string.Format("<script language='javascript'>\n{{\n	"
                + "//***** ���Ӳ˵� *****\n{0}}}\n</script>\n", fScript.ToString());
        }

        public override bool IsAdmin()
        {
            return fAdmin;
        }

        public override bool IsFunction(object key)
        {
			object id = fShortName[key] ;
			if (id == null)
				return false ;
            object item = fFunction[id];
            if (item == null)
                return false;
            return ((FunctionRightItem)item).IsLeaf;
        }

        public override bool IsSubFunction(object subKey, object key)
        {
			object id = fShortName[key] ;
			if (id == null)
				return false ;
			object item = fFunction[id];
            if (item == null)
                return false;
            FunctionRightItem fItem = (FunctionRightItem)item;
            if (!fItem.IsLeaf)
                return false;
            return fItem.SubFunc.Contains(subKey.ToString());
        }
    }
}
