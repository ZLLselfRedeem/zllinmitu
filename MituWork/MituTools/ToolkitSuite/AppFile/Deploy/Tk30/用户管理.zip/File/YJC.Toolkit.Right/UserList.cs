using System;
using System.Collections;
using System.Text;

namespace YJC.Toolkit.Right
{
	/// <summary>
	/// UserList ��ժҪ˵����
	/// </summary>
	internal class UserList
	{
        private ArrayList fROUserList;
        private ArrayList fRWUserList;
        private string fPublicList;
        
        public UserList()
		{
            fROUserList = new ArrayList();
            fRWUserList = new ArrayList();
            fPublicList = string.Empty;
        }

        public void InitializePublicList()
        {
            if (fROUserList.Count == 0)
                return;
            StringBuilder builder = new StringBuilder(2048);
            for (int i = 0; i < fROUserList.Count; ++i)
            {
                if (i == 0)
                    builder.Append(string.Format("'{0}'", fROUserList[i]));
                else
                    builder.Append(string.Format(",'{0}'", fROUserList[i]));
            }
            for (int i = 0; i < fRWUserList.Count; ++i)
                builder.Append(string.Format(",'{0}'", fRWUserList[i]));
            fPublicList = builder.ToString();
        }

        public ArrayList ROUserList
        {
            get
            {
                return fROUserList;
            }
        }

        public ArrayList RWUserList
        {
            get
            {
                return fRWUserList;
            }
        }

        public string PublicList
        {
            get
            {
                return fPublicList;
            }
        }

        public void Clear()
        {
            fROUserList.Clear();
            fRWUserList.Clear();
            fPublicList = string.Empty;
        }
	}
}
