using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// NotActiveException ��ժҪ˵����
	/// </summary>
    public class NotActiveException : LoginException
    {
        public class NotActiveErrorObject : BaseErrorObject
        {
            public NotActiveErrorObject() : base("LOGIN_NAME",
                LoginResUtil.GetResourceString("NotActive"), 0)
            {
            }
        }

        public NotActiveException() : base(new NotActiveErrorObject())
        {
        }
    }
}
