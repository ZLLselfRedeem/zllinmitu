using System;
using System.Data;
using System.Collections.Specialized;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Provider;

namespace YJC.Toolkit.Right.Data
{
	[Resolver(FunctionResolver.REG_NAME, Description = "��SYS_FUNCTION�����ݷ��ʲ���", Author = "ShiXin", CreateDate = "2007-09-21")]
	public class FunctionResolver : Tree2XmlTableResolver
	{
		internal const string REG_NAME = "Function";
		public FunctionResolver(DataSet hostDataSet) : base(hostDataSet)
		{
			XmlFile = "Users/Function.xml";
			AutoUpdating = false;
        }

		public override TreeFieldGroup TreeFields
		{
			get
			{
				return new  TreeFieldGroup("FN_ID", "FN_NAME", "FN_PARENT_ID", "FN_TREE_LAYER", "FN_IS_LEAF");
			}
		}

		protected override void OnUpdatingRow(UpdatingEventArgs e)
		{
			base.OnUpdatingRow(e);
			
			switch (e.Status)
			{
				case UpdateKind.Insert :
					e.Row["FN_ID"] = GlobalProvider.GetUniID(TableName, DbConnection);
					break;
				case UpdateKind.Update :
					break;
			}
			
		}
		
		protected override void AddConstraints(UpdateKind status)
		{
			base.AddConstraints(status);
			//this.Constraints.Add(new SingleValueConstraint("FN_SHORT_NAME", GetDisplayName("FN_SHORT_NAME")));
		}
	}
}
