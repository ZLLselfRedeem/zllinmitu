﻿using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(UserInfoResolver._REG_NAME, Description = "表UR_USERS(UR_USERS)的数据访问层类，只能对登录者个人维护和查看",
        Author = "YJC", CreateDate = "2007-06-20")]
    public class UserInfoResolver : UsersResolver
    {
        internal const string _REG_NAME = "UserInfo";
        /// <summary>
        /// Initializes a new instance of the UserInfoResolver class.
        /// </summary>
        public UserInfoResolver(DataSet hostDataSet) : base(hostDataSet)
        {
            if (hostDataSet is IListDetailEvent)
            {
                IListDetailEvent listDetail = (IListDetailEvent)hostDataSet;
                listDetail.FillingUpdateTables += new FillingUpdateEventHandler(listDetail_FillingUpdateTables);
            }
        }

        void listDetail_FillingUpdateTables(object sender, FillingUpdateEventArgs e)
        {
            this.SelectWithKeys(GlobalVariable.Info.UserID);
            if (!e.IsPost)
            {
                this.AddVirtualFields();
                if (e.Style == PageStyle.Update)
                    ResolverUtil.GetConstraints(UpdateKind.Update, this);
            }
            e.Handled[this] = true;
        }
    }
}
