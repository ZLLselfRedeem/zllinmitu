using System;
using System.Collections.Specialized;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// WebHomePageDataSet ��ժҪ˵����
    /// </summary>
    public class WebHomePageDataSet : Empty2DataSet
    {
        private DateTime fCurrentDate;
        private readonly string[] WeekNames = {"������", "����һ", "���ڶ�", "������", "������", "������", "������"};

        public WebHomePageDataSet()
        {
        }

        public DateTime CurrentDate
        {
            get
            {
                return fCurrentDate;
            }
            set
            {
                fCurrentDate = value;
                SetUserInfo();
                SetDateDesc();
                SetMonthDesc();
            }
        }

        private void SetUserInfo() 
        {
            DataTable table = DataSetUtil.CreateDataTable("UserInfo", "UserName", "Welcome", "IframeSrc");
            table.Rows.Add(new object[] { GlobalVariable.Info.UserName, LoginUtil.GetHomePageWelcomeConfig(), LoginUtil.GetHomePageIframeSrcConfig() });
            this.Tables.Add(table);
        }

        private void SetDateDesc() 
        {
            DataTable table = DataSetUtil.CreateDataTable("DateDesc", "Now", "Prev", "Next", 
                "FindDate", "Year", "Month");
            DataRow row = table.NewRow();
            row.BeginEdit();
            row["Now"] = row["FindDate"] = fCurrentDate.ToString("yyyy-MM-dd");
            row["Prev"] = fCurrentDate.AddMonths(-1).ToString("yyyy-MM-dd");
            row["Next"] = fCurrentDate.AddMonths(1).ToString("yyyy-MM-dd");
            row["Year"] = fCurrentDate.Year;
            row["Month"] = fCurrentDate.Month;
            row.EndEdit();
            table.Rows.Add(row);
            this.Tables.Add(table);
        }

        private void SetMonthDesc() 
        {
            DataTable table = DataSetUtil.CreateDataTable("DayDesc", "Month", "Day", "Date", 
                "ChName", "WeekName", "LongDate");
            int monthNow = fCurrentDate.Month;
            DateTime firstDateOfMonth = fCurrentDate.AddDays(-(fCurrentDate.Day - 1)); 
            DateTime firstDateOfWeekMonth = firstDateOfMonth.AddDays(-(int)firstDateOfMonth.DayOfWeek);
            DateTime calcDateOfMonth = firstDateOfMonth;
            int addValue = 0;
            LunarDate firstDayLunar = new LunarDate();
            do
            {
                for (int i = 0; i < 7; ++i)
                {
                    DataRow row = table.NewRow();
                    DateTime calDate = firstDateOfWeekMonth.AddDays(addValue);
                    row.BeginEdit();
                    row["Month"] = calDate.Month;
                    row["Day"] = calDate.Day;
                    row["Date"] = calDate.ToString("yyyy-MM-dd");
                    row["ChName"] = SolarLunarUtil.LunarDayInc(calDate, firstDayLunar, addValue);;
                    row["WeekName"] = WeekNames[(int)calDate.DayOfWeek];
                    row["LongDate"] = calDate.ToLongDateString();
                    row.EndEdit();
                    table.Rows.Add(row);
                    ++addValue;
                }
                calcDateOfMonth = firstDateOfWeekMonth.AddDays(addValue);
            } while (calcDateOfMonth.Month == monthNow);
            Tables.Add(table);
        }

        public override void SetData(bool isPost, PageStyle style, string operation, NameValueCollection queryString)
        {
            string dateStr = queryString["Date"];
            DateTime date;
            try
            {
                date = DateTime.Parse(dateStr);
            }
            catch
            {
                date = DateTime.Now;
            }
            this.CurrentDate = date;
        }
    }
}
