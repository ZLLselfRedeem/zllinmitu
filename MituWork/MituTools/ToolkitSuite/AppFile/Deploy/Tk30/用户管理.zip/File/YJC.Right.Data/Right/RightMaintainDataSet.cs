using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// RightMaintainDataSet ��ժҪ˵����
    /// </summary>
    /// 
    [DataSet(RightMaintainDataSet.REG_NAME, Description = "Ȩ��ά���޸�ҳ��", Author = "YJC", CreateDate = "2004-10-25")]
    public class RightMaintainDataSet : WebSimpleUpdateDataSet, ISupportFunction2
    {
        internal const string REG_NAME = "RightMaintain";

        private PartFuncResolver fPartFunc;
        private PartSubFuncResolver fPartSubFunc;

        public RightMaintainDataSet() : base()
        {
            fPartFunc = new PartFuncResolver(this);
            fPartSubFunc = new PartSubFuncResolver(this);
        }

		protected override void FillCustomTables(bool isPost, string operation, System.Collections.Specialized.NameValueCollection queryString, DataSet postDataSet)
		{
			if (isPost)
			{
				string key = GlobalVariable.Request.QueryString["ID"];

				CopyDelInsTable(fPartFunc, postDataSet.Tables["SYS_FUNCTION"], key, "FN_ID", "PF_FN_ID", "PF_PART_ID");
				CopyDelInsTable(fPartSubFunc, postDataSet.Tables["SYS_SUB_FUNC"], key, "SF_ID", "PSF_SF_ID", "PSF_PART_ID");

				UpdateTableresolvers(fPartFunc, fPartSubFunc);
			}
			else
			{
				fPartFunc.SelectWithParam("PF_PART_ID", queryString["ID"]);
				fPartSubFunc.SelectWithParam("PSF_PART_ID", queryString["ID"]);

				FunctionResolver function = new FunctionResolver(this);
				function.Select("ORDER BY FN_TREE_LAYER");

				SubFuncResolver subFunc = new SubFuncResolver(this);
				subFunc.Select(string.Empty);
			}
        }

		private void CopyDelInsTable(TableResolver resolver, DataTable postTable, string key, string postKeyField, string keyField, string partField)
		{
			resolver.SelectWithParam(partField, key);
			resolver.SetCommands(AdapterCommand.Delete | AdapterCommand.Insert);
			for (int i = resolver.HostTable.Rows.Count - 1; i >= 0 ; i--)
			{
				resolver.HostTable.Rows[i].Delete();
			}
			string id = "";
			foreach (DataRow row in postTable.Rows)
			{
				id = row[postKeyField].ToString();
				if (id.Length > 0 && id != "0")
				{
					DataRow srcRow = resolver.HostTable.NewRow();
					srcRow.BeginEdit();
					srcRow[partField] = key;
					srcRow[keyField] = id;
					srcRow.EndEdit();
					resolver.HostTable.Rows.Add(srcRow);
				}
			}
		}

		public override string GetXsltFile(bool isIe, PageStyle style, string operation)
		{
			 return @"Users\RightMaintainUpdate.xslt";
		}

		public override string GetDefaultPage(bool isPost, PageStyle style, string operation, PageX pageX, string retURL)
		{
			if (isPost)
                return string.Format("../Library2/WebDetailXmlPage.{0}?Source=Users/Part&ID={1}", 
				pageX, GlobalVariable.Request.QueryString["ID"]);
			return retURL;
		}

		#region ISupportFunction2 ��Ա

		public YJC.Toolkit.Right.FunctionRightType FuncType
		{
			get
			{
				return YJC.Toolkit.Right.FunctionRightType.Admin;
			}
		}

		public object FunctionKey
		{
			get
			{
				return "Part";
			}
		}

		public object GetSubFunctionKey(YJC.Toolkit.Sys.PageStyle style, string operation)
		{
			return "21";
		}

		#endregion
	}
}
