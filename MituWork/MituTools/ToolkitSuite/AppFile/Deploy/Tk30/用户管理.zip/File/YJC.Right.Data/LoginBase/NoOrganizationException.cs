using System;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
	/// <summary>
	/// NoOrganizationException ��ժҪ˵����
	/// </summary>
    public class NoOrganizationException : LoginException
    {
        private class NoOrganizationErrorObject : BaseErrorObject
        {
            public NoOrganizationErrorObject() : base("ORG_CODE", 
                LoginResUtil.GetResourceString("NoOrganization"), 0)
            {
            }
        }

        public NoOrganizationException() : base()
        {
            ErrorObject = new NoOrganizationErrorObject();
        }
    }
}
