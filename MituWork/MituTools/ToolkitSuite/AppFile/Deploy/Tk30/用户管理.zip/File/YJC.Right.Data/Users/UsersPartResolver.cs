using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.DataAccess;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
	[Resolver(UsersPartResolver.REG_NAME, Description = "��UR_USERS_PART(UR_USERS_PART)�����ݷ��ʲ���", 
		Author = "Yuanlm", CreateDate = "2004-07-07")]
	public class UsersPartResolver : Xml2TableResolver
	{
		internal const string REG_NAME = "UsersPart";
		
		public UsersPartResolver(DataSet hostDataSet) : base(hostDataSet)
		{
			XmlFile = "Users/UsersPart.xml";
            AutoUpdating = false;
		}
		
		protected override void OnUpdatingRow(UpdatingEventArgs e)
		{
			base.OnUpdatingRow(e);
			
			switch (e.Status)
			{
				case UpdateKind.Insert :
					break;
				case UpdateKind.Update :
					break;
			}
		}
	}
}
