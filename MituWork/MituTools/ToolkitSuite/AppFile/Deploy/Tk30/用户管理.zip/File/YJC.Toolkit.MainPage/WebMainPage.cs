using System;
using System.Data;
using System.Web.UI;
using YJC.Toolkit.SysUtil;

namespace YJC.Toolkit.Web
{
	/// <summary>
	/// WebMainHtml ��ժҪ˵����
	/// </summary>
    public class WebMainPage : WebBasePage
    {
        /// <summary>
        /// ���캯��
        /// </summary>
        public WebMainPage() : base()
        {
            SupportLogin = true;
        }

        /// <summary>
        /// ����ҳ�棬��ʾFrame���
        /// </summary>
        protected override void DoGet()
        {
            //string source = Request.QueryString["Source"];
			string strURL = Request.Url.ToString();
			int queryPos = strURL.IndexOf("Source=");
			string source = string.Empty;
			if (queryPos != -1)
				source = strURL.Substring(queryPos + 7);

            if (StringUtil.IsEmpty(source))
                return;
            string fmtStr = ResUtil.GetResourceString("DefaultHtml");
            string function = SessionGbl.Rights.FunctionRight.GetMenuScript(SessionGbl.Info.UserID);
            Response.Write(string.Format(fmtStr, function, source));
        }
	}
}
