﻿using YJC.Toolkit.Data;

namespace YJC.Toolkit.SysFunction
{
    /// <summary>
    /// SYS_FUNCTION 表的数据访问对象
    /// </summary>
    [Resolver(Author = "YJC", CreateDate = "2014-10-21",
        Description = "SYS_CUSTOM_TABLE 表的数据访问对象")]
    internal class CustomTableResolver : Tk5TableResolver
    {
        public const string DATAXML = "SysFunction/CustomTable.xml";

        public CustomTableResolver(IDbDataSource source)
            : base(DATAXML, source)
        {
        }
    }
}
