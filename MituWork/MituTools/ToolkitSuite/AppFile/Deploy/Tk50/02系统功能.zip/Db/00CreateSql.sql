﻿/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2000                    */
/* Created on:     2014/12/8 10:50:40                           */
/*==============================================================*/


if exists (select 1
            from  sysobjects
           where  id = object_id('SYS_CUSTOM_FIELD')
            and   type = 'U')
   drop table SYS_CUSTOM_FIELD
;

if exists (select 1
            from  sysobjects
           where  id = object_id('SYS_CUSTOM_TABLE')
            and   type = 'U')
   drop table SYS_CUSTOM_TABLE
;

/*==============================================================*/
/* Table: SYS_CUSTOM_FIELD                                      */
/*==============================================================*/
create table SYS_CUSTOM_FIELD (
   CF_TABLE_ID          int                  not null,
   CT_FIELD_NAME        varchar(255)         not null,
   CF_DISPLAY_NAME      varchar(255)         null,
   CF_NICK_NAME         varchar(255)         null,
   CF_DATA_TYPE         varchar(50)          null,
   CF_REAL_LENGTH       int                  null,
   CF_LENGTH            int                  null,
   CF_CONTROL           varchar(50)          null,
   CF_CHARACTER         smallint             null,
   CF_ORDER             int                  null,
   CF_DISPLAY           smallint             null,
   CF_QUERY             smallint             null,
   CF_EXTIONSION1       varchar(255)         null,
   CF_EXTIONSION2       varchar(255)         null,
   CF_EXTIONSION3       varchar(255)         null,
   constraint PK_SYS_CUSTOM_FIELD primary key (CF_TABLE_ID, CT_FIELD_NAME)
)
;

/*==============================================================*/
/* Table: SYS_CUSTOM_TABLE                                      */
/*==============================================================*/
create table SYS_CUSTOM_TABLE (
   CT_TABLE_ID          int                  not null,
   CT_DISPLAY_NAME      varchar(255)         not null,
   CT_TABLE_NAME        varchar(255)         not null,
   CT_NAME_FIELD        varchar(255)         null,
   CT_STATUS            smallint             null,
   CT_EXTENSION1        varchar(255)         null,
   CT_EXTENSION2        varchar(255)         null,
   CT_EXTENSION3        varchar(255)         null,
   constraint PK_SYS_CUSTOM_TABLE primary key (CT_TABLE_ID)
)
;

