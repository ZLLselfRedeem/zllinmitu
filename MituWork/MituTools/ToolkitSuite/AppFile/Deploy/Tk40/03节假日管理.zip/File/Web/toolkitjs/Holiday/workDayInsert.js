﻿var year;
function WorkDayReport() {
   // alert(123); 
    //hdGC_ORG_ID
    //GC_SEASON
    //GC_MONTH
    //alert($("[name='WK_YEAR']").val());
    year = $("[name='WK_YEAR']").val();
    //alert(year);
    if (year == "") {
        alert("年份输入不能为空");
    }
    else {
        $.ajax({
            type: "GET",
            cache: false,
            //dataType:"json",
            url: "../Library/WebContentPage.tkx?Source=WorkDayCreateSource",
            data: "&WK_YEAR=" + year,
            dataType: "text",
            success: _successGetReport,
            error: function (e) { Toolkit.page.hideLoading(); alert(e + " 请求异常"); }
        });
    }
}


function _successGetReport(data) {
    Toolkit.page.hideLoading();
    try {
        var ff = Toolkit.json.parse(data);
        //alert(ff);
        if (ff.WORKDAY_CREATE[0].ISSUCESS == "True") {
            Toolkit.page.showLoading('生成成功');
           // alert("生成成功"); 
            //alert(year);
            // window.location = "../Library/WebUpdateXmlPage.tkx?Source=Holiday/Workday&ID=" + year + "";
            window.location = "../Library/WebInsertXmlPage.tkx?Source=Holiday/WorkDay&year=" + year + ""; 
        }
        else {
            alert(_process(ff.WORKDAY_CREATE[0].PROCESS) + " 导致 生成失败\r\n    " + ff.WORKDAY_CREATE[0].ERROR + "\r\n");
        }
        //debugger;
    }

    catch (ex) {
        alert("脚本异常:" + ex + data);
    }
}

function _process(pSign) {
    pSign = Number(pSign);
    switch (pSign) {
        case 0:
            return "参数验证不通过";
        case 1:
            return "参数验证通过,工作日写入数据库失败";
        case 2:
            return "参数验证通过,工作日写入数据库完成，默认生成节假日完成,节假日写入数据库失败";
        case 3:
            return "参数验证通过,工作日写入数据库完成，默认生成节假日完成,节假日写入数据库成功"; ;
        default:
            return "";
    }
}

