﻿/*==============================================================*/
/* Table: UR_GATHER    账号绑定                                         */
/*==============================================================*/
create table UR_GATHER 
(
   UG_ID                int                            not null,
   UG_COUNT             int,
   UG_NAME              varchar(64),
   UG_OWNER_ID          varchar(64),
   UG_MAX_NUM           int,
   UG_CREATE_DATE       datetime,
   UG_CREATE_ID         varchar(64),
   UG_UPDATE_DATE       datetime,
   UG_UPDATE_ID         varchar(64),
   UG_UNUSER1           int,
   UG_UNUSER2           int,
   UG_UNUSER3           varchar(255),
   UG_UNUSER4           varchar(255),
   constraint PK_UR_GATHER primary key clustered (UG_ID)
);
