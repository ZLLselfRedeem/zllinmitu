﻿using System.Configuration;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right.Data
{
    internal class LogOnParams
    {
        private static LogOnParams fCurrent;

        private LogOnParams()
        {
        }

        private void Initialize()
        {
            this.DefaultPage = GetConfig("DefaultPage", "../Library/WebInitPage.tkx?Source=LoginPage");
            this.HomePageWelcome = GetConfig("HomePageWelcome", string.Empty);
            this.HomePageIFrameSrc = GetConfig("HomePageIframeSrc", string.Empty);
            this.MaxAttemptTimes = XmlUtil.GetDefaultValue(GetConfig("LoginAttemptMax", "3"), 3);
            this.LoginMode = XmlUtil.GetDefaultValue<LogOnMode>(GetConfig("LoginMode", "User"), LogOnMode.User);
        }

        public string DefaultPage { get; private set; }

        public string HomePageWelcome { get; private set; }

        public string HomePageIFrameSrc { get; private set; }

        public int MaxAttemptTimes { get; private set; }

        public LogOnMode LoginMode { get; private set; }

        private static string GetConfig(string name, string defaultValue)
        {
            return XmlUtil.GetDefaultValue<string>(ConfigurationManager.AppSettings[name], defaultValue);
        }

        public static LogOnParams Current
        {
            get
            {
                if (fCurrent == null)
                {
                    fCurrent = new LogOnParams();
                    fCurrent.Initialize();
                }
                return fCurrent;
            }
        }
    }
}
