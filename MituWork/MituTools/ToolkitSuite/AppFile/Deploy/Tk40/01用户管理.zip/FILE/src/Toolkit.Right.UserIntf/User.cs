﻿using System;
using System.Data;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right
{
    internal class User : IUser
    {
        private UserProvider fProvider;
        private string fUserId;
        private string fUserName;
        private string fUserLoginName;
        private DateTime fUserLoginDate;
        private string fUserPhone;
        private string fUserEmail;
        private string fWorkNo;
        private int fUserActive;
        private DateTime fUserPasswdChangeDate;
        private DateTime fUserUnlockDate;
        private DateTime fCreateDate;

        private bool fIsApproved;
        private DateTime fLastActivityDate;
        private string fPasswordQuestion;

        internal User(DataRow row, UserProvider provider)
        {
            fUserId = row["USER_ID"].ToString();
            fUserName = row["USER_NAME"].ToString();
            fUserLoginName = row["USER_LOGIN_NAME"].ToString();
            fUserLoginDate = row["USER_LOGIN_DATE"].Value<DateTime>();
            fUserPhone = row["USER_PHONE"].ToString();
            fUserEmail = row["USER_EMAIL"].ToString();
            fWorkNo = row["USER_WORK_NO"].ToString();
            fCreateDate = row["USER_CREATE_DATE"].Value<DateTime>();
            fUserPasswdChangeDate = row["USER_PASSWD_CHANGE_DATE"].Value<DateTime>();
            fUserActive = row["USER_ACTIVE"].Value<int>();
            fUserUnlockDate = row["USER_UNLOCK_DATE"].Value<DateTime>();

            fProvider = provider;
            //是否启用
            fIsApproved = fUserActive == 1;
            fPasswordQuestion = string.Empty;
        }

        #region IUser 成员

        public string ApplicationName
        {
            get
            {
                return string.Empty;
            }

        }

        public bool ChangePassword(string oldPassword, string newPassword)
        {
            return fProvider.ChangePassword(LogOnName, oldPassword, newPassword);
        }

        public bool ChangePasswordQuestionAndAnswer(string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            return fProvider.ChangePasswordQuestionAndAnswer(LogOnName, password, newPasswordQuestion, newPasswordAnswer);
        }

        public DateTime CreationDate
        {
            get
            {
                return fCreateDate;
            }
        }

        public string Email
        {
            get
            {
                return fUserEmail;
            }
            set
            {
                fUserEmail = value;
            }
        }

        public string GetPassword(string passwordAnswer)
        {
            return fProvider.GetPassword(LogOnName, passwordAnswer);
        }

        public string GetPassword()
        {
            return GetPassword(string.Empty);
        }

        public bool IsApproved
        {
            get
            {
                return fIsApproved;
            }
            set
            {
                fIsApproved = true;
            }
        }

        public bool IsLockedOut
        {
            get
            {
                return fUserActive != 1;
            }
        }

        public bool IsOnline
        {
            get
            {
                return true;
            }
        }

        public DateTime LastActivityDate
        {
            get
            {
                return fLastActivityDate;
            }
            set
            {
                fLastActivityDate = value;
            }
        }

        public DateTime LastLockoutDate
        {
            get
            {
                return fUserUnlockDate;
            }
        }

        public DateTime LastLogOnDate
        {
            get
            {
                return fUserLoginDate;
            }
            set
            {
                fUserLoginDate = value;
            }
        }

        public DateTime LastPasswordChangedDate
        {
            get
            {
                return fUserPasswdChangeDate;
            }
        }

        public string LogOnName
        {
            get
            {
                return fUserLoginName;
            }
            set
            {
                fUserLoginName = value;
            }
        }

        public string Number
        {
            get
            {
                return fWorkNo;
            }
            set
            {
                fWorkNo = value;
            }
        }

        public string PasswordQuestion
        {
            get
            {
                return fPasswordQuestion;
            }
        }

        public string Phone
        {
            get
            {
                return fUserPhone;
            }
            set
            {
                fUserPhone = value;
            }
        }

        public IUserProvider Provider
        {
            get
            {
                return fProvider;
            }
        }

        public string ResetPassword(string passwordAnswer)
        {
            return ResetPassword();
        }

        public string ResetPassword()
        {
            return fProvider.ResetPassword(LogOnName, string.Empty);
        }

        public bool UnlockUser()
        {
            return fProvider.UnlockUser(LogOnName);
        }

        public string GetIMId(string type)
        {
            return string.Empty;
        }

        #endregion

        #region IEntity 成员

        public string Id
        {
            get
            {
                return fUserId;
            }
        }

        public string Name
        {
            get
            {
                return fUserName;
            }
        }

        #endregion
    }
}
