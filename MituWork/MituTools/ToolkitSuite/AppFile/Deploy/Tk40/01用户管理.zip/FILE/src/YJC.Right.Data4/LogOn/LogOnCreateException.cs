﻿using System;

namespace YJC.Toolkit.Right.Data
{
    [Serializable]
    public class LogOnCreateException : LogOnException
    {
        internal LogOnCreateException(string fieldName, string message)
            : base(fieldName, message)
        {
        }
    }
}
