﻿using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right.Data
{
    internal abstract class HandleBaseSource : BaseCustomSource
    {

        private DataRow fHandleRow;
        //错误信息
        protected DataRow HandleRow
        {
            get
            {
                if (fHandleRow == null)
                {
                    fHandleRow = HandleCreateTable.Rows[0];
                }
                return fHandleRow;
            }
        }

        protected DataTable HandleCreateTable
        {
            get;
            set;
        }

        protected abstract void CheckInParm(IPageData pageData);

        protected abstract void HandleWork(IPageData pageData);

        protected override void FillCustomTables(IPageData pageData)
        {
            base.FillCustomTables(pageData);
            HostDataSet.Tables.Add(DataSetUtil.CreateDataTable("HANDLE_CREATE", "ISSUCESS", "ERROR", "PROCESS"));
            HandleCreateTable = HostDataSet.Tables["HANDLE_CREATE"];
            DataRow row = HandleCreateTable.NewRow();
            HandleCreateTable.Rows.Add(row);
            try
            {
                row["PROCESS"] = 0;
                CheckInParm(pageData);
                row["PROCESS"] = 1;
                HandleWork(pageData);
                row["ISSUCESS"] = true;
                row.EndEdit();
            }
            catch (Exception ex)
            {
                row.BeginEdit();
                row["ERROR"] = ex.Message;
                row["ISSUCESS"] = false;
                row.EndEdit();
            }
        }
    }
}
