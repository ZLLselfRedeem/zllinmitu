﻿using System;
using System.Globalization;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(REG_NAME, Author = "yax", CreateDate = "2010-09-16", Description = "表OrganizationResolver(OrganizationResolver)的数据访问层类")]
    internal class OrganizationResolver : Tk4TableResolver, IDbTree
    {
        internal const string REG_NAME = "Organization";
        private TreeFieldGroup fTreeFields;

        public OrganizationResolver(DbContext context, IDataSource source)
            : base("Users/Organization.xml", context, source)
        {
            fTreeFields = new TreeFieldGroup(XmlDataType.String, "ORG_ID", "ORG_NAME", "ORG_PARENT_ID", "ORG_LAYER", "ORG_IS_LEAF");
        }

        protected override void OnUpdatingRow(UpdatingEventArgs e)
        {
            base.OnUpdatingRow(e);

            switch (e.Status)
            {
                case UpdateKind.Insert:
                    e.Row["ORG_ID"] = Context.GetUniId(TableName);
                    e.Row["ORG_CREATE_ID"] = GlobalVariable.UserId;
                    e.Row["ORG_CREATE_DATE"] = DateTime.Now;
                    e.Row["ORG_UPDATE_ID"] = GlobalVariable.UserId;
                    e.Row["ORG_UPDATE_DATE"] = DateTime.Now;
                    break;
                case UpdateKind.Update:
                    e.Row["ORG_UPDATE_ID"] = GlobalVariable.UserId;
                    e.Row["ORG_UPDATE_DATE"] = DateTime.Now;
                    break;
                case UpdateKind.Delete:
                    string sql = "SELECT COUNT(*) FROM UR_USERS WHERE USER_ORG_ID = " + e.Row["ORG_ID"].ToString();
                    int count = int.Parse(DataSetUtil.ExecuteScalar(sql, Context).ToString(), CultureInfo.CurrentCulture);
                    if (count > 0)
                    {
                        GlobalVariable.Response.Write("不能删除该组织!该组织上还有用户，请修改这些用户的组织。");
                        GlobalVariable.Response.End();
                        throw new ErrorPageException("不能删除组织", "该组织上还有用户，请修改这些用户的组织。");
                    }
                    break;
            }

        }

        protected override void SetConstraints(PageStyle style)
        {
            base.SetConstraints(style);
            this.Constraints.Add(new PostCodeConstraint("ORG_POST_CODE", this.GetDisplayName("ORG_POST_CODE")));
        }

        #region ITree 成员

        public new TreeFieldGroup TreeFields
        {
            get
            {
                return fTreeFields;
            }
        }

        public new  string RootId
        {
            get
            {
                return "-1";
            }
        }

        public new TreeSearchType SearchType
        {
            get
            {
                return TreeSearchType.ParentId;
            }
        }

        #endregion
    }
}
