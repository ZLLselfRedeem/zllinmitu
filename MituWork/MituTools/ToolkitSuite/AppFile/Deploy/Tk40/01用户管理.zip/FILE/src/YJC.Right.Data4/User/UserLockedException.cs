
using System;
namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// UserLockedException ��ժҪ˵����
    /// </summary>
    [Serializable]
    internal class UserLockedException : LogOnException
    {
        public UserLockedException()
            : base("LOGIN_NAME", LoginResUtil.GetResourceString("UserLocked"))
        {
        }

    }
}
