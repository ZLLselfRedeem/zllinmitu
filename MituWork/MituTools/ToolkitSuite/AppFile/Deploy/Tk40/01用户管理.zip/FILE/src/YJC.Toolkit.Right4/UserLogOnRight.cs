﻿using System;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right
{
    [Serializable]
    internal class UserLogOnRight : EmptyLogOnRight
    {
        private static string fPage;
        private object fSync = new object();
        public string LogOnPage
        {
            get
            {
                if (fPage == null)
                {
                    lock (fSync)
                    {
                        Assembly assembly = Assembly.GetAssembly(typeof(UserLogOnRight));
                        ResourceManager frm = ResourceUtil.GetResourceManager(assembly, "Right");
                        fPage = frm.GetString("DefaultPage", ObjectUtil.SysCulture);
                    }
                }
                return fPage;
            }
        }
        public override void Initialize(UserInfo user)
        {
            user.IsLogOn = true;
        }
        public override void CheckLogOn(object userId, Uri url)
        {
            string logOnPage = this.LogOnPage;
            if (!string.IsNullOrEmpty(logOnPage) && !GlobalVariable.SessionGbl.Info.IsLogOn)
            {
                if (!SetSessionFromCookie())
                {
                    string str2 = (logOnPage.IndexOf("?", StringComparison.Ordinal) == -1) ? "?" : "&";
                    string str3 = url.ToString();
                    if (!string.IsNullOrEmpty(str3))
                    {
                        logOnPage = logOnPage + str2 + "RetURL=" + HttpUtility.UrlEncode(str3);
                    }
                    throw new RedirectException(logOnPage);
                }
            }

        }

        public bool SetSessionFromCookie()
        {
            bool result = false;
            var cookies = GlobalVariable.Request.Cookies;
            string userInfoStr = cookies["UserInfo"].Value;
            string loginName = cookies["LoginName"].Value;
            //string username = GlobalVariable.Response.Cookies[""]
            if (StringUtil.IsNotEmpty(userInfoStr, LogOnPage))
            {
                try
                {
                    userInfoStr = PasswdUtil.Decrypt(userInfoStr, loginName);
                    XmlReader reader = XmlReader.Create(new StringReader(userInfoStr),
                        new XmlReaderSettings { CloseInput = true });
                    XName ROOT = "UserInfo";
                    UserInfo userInfo = new UserInfo();
                    XmlUtil.ReadCompleteXml(reader, ROOT, userInfo);
                    //GlobalVariable.Info = userInfo;
                    UserInfo info = GlobalVariable.Info;
                    info.IsLogOn = true;
                    info.UserId = userInfo.UserId;
                    info.RoleId = userInfo.RoleId;
                    info.UserName = userInfo.UserName;
                    info.LogOnName = userInfo.LogOnName;
                    info.Encoding = "gb2312";
                    result = true;
                }
                catch
                {
                    result = false;
                }

            }
            return result;
        }
    }
}
