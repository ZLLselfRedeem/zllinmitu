﻿using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Xml.Linq;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data.MainPage
{
    [XmlInputReader, XsltPageMaker(XSLT_PATH, FilePathPosition.Xml)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2011-08-03", Description = "左部菜单")]
    internal class LeftMenuSource : HeadMenuSource
    {
        internal new  const string REG_NAME = "LeftMenu";
        internal new const string XSLT_PATH = "Project/Users/LeftMenu.xslt";
        //internal  const string LEFT_MENU_SESSION = "LEFT_MENU_SESSION";
        //#region ISource 成员

        //WebOutputData ISource.DoAction(WebInputData input)
        //{
        //    //throw new System.NotImplementedException();
        //    object leftMenu = GlobalVariable.Session[LEFT_MENU_SESSION];
        //    if (leftMenu == null)
        //    {
        //        string dsXml = GlobalVariable.SessionGbl.AppRight.GetMenuScript(GlobalVariable.Info.UserId);
        //        StringReader stringReader = new StringReader(dsXml);
        //        DataSet ds = new DataSet()
        //        {
        //            Locale = ObjectUtil.SysCulture
        //        };
        //        ds.ReadXml(stringReader);
        //        leftMenu = SetFuncTable(ds);
        //    }
        //    return new WebOutputData(SourceOutputType.String, leftMenu);
        //    //return null;
        //}

        //private string SetFuncTable(DataSet dataset)
        //{
        //    XElement root = new XElement("div", "");
        //    Dictionary<string, XElement> dictionList = new Dictionary<string, XElement>();

        //    DataTable table = dataset.Tables["SYS_FUNCTION"];

        //    if (table != null)
        //    {
        //        foreach (DataRow row in table.Rows)
        //        {
        //            int layer = row["FN_LAYER"].Value<int>();
        //            string key = row["FN_ID"].ToString();
        //            bool isLeaf = (row["FN_IS_LEAF"].ToString() == "1") ? true : false;
        //            if (layer == 0)
        //            {
        //                XElement div = new XElement("div", new XAttribute("class", "acc-header"));
        //                XElement h3 = new XElement("h3");
        //                div.Add(h3);
        //                XElement a = new XElement("a", new XAttribute("href", row["FN_URL"].ToString()), row["FN_NAME"]);
        //                a.Add(new XAttribute("target", "tkFrameMain"));
        //                h3.Add(a);
        //                root.Add(div);
        //                if (isLeaf)
        //                {
        //                    dictionList.Add(key, h3);
        //                }
        //                else
        //                {
        //                    XElement contentDiv = new XElement("div", new XAttribute("class", "acc-body"));
        //                    root.Add(contentDiv);
        //                    dictionList.Add(key, contentDiv);
        //                }
        //            }
        //            else
        //            {
        //                XElement li = new XElement("li", new XAttribute("class", "closed"));
        //                string aClass = "";
        //                if (isLeaf)
        //                {
        //                    aClass = "file";
        //                }
        //                else
        //                    aClass = "folder";
        //                XElement a = new XElement("a", new XAttribute("class", aClass),
        //                    new XAttribute("href", row["FN_URL"].ToString()), row["FN_NAME"]);
        //                a.Add(new XAttribute("target", "tkFrameMain"));
        //                li.Add(a);
        //                dictionList.Add(key, li);

        //                XElement parentLi = dictionList[row["FN_PARENT_ID"].ToString()];
        //                XElement nUl = parentLi.Element("ul");
        //                if (nUl == null)
        //                {
        //                    nUl = new XElement("ul", new XAttribute("class", "filetree ui-treeview"));
        //                    parentLi.Add(nUl);
        //                }

        //                nUl.Add(li);

        //            }
        //        }
        //    }
        //    return root.ToString();
        //}

        //#endregion
    }
}
