﻿
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// SYS_SUB_FUNC 表的数据访问对象
    /// </summary>
    [Resolver(REG_NAME, Author = "fongsl", CreateDate = "2010-09-15", Description = "SYS_SUB_FUNC 表的数据访问对象")]
    internal class SubFunctionResolver : Tk4TableResolver
    {
        internal const string REG_NAME = "SubFunc";
        public const string DATAXML = "Users/SubFunc.xml";

        public SubFunctionResolver(DbContext context, IDataSource dataSource)
            : base(DATAXML, context, dataSource)
        {
        }

        protected override void OnUpdatingRow(UpdatingEventArgs e)
        {
            base.OnUpdatingRow(e);

            switch (e.Status)
            {
                case UpdateKind.Delete:
                    break;
                case UpdateKind.Insert:
                    e.Row["SF_ID"] = this.Context.GetUniId(this.TableName);
                    break;
                case UpdateKind.Update:
                    break;
                default:
                    break;
            }
        }

        protected override void SetConstraints(PageStyle style)
        {
            base.SetConstraints(style);

            this.Constraints.Add(new UniqueRowConstraint("SF_NAME_ID", this.GetDisplayName("SF_NAME_ID")));
        }
    }
}
