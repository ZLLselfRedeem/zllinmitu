﻿

function UserLoginForm(loginName) {
    // alert();
    loginName = "";
    Toolkit.util.dialog.open({ title: "正在生产，请稍后..." });

    Toolkit.page.dialog({ title: '绑定帐号',
        content: ' <div class="mod-frame"><div class="mod-content"><div class="tk-datatable column1 clearfix p30" id="LOGIN"><dl class="required"><dt class="tac">帐号：</dt><dd><span class="tk-control ctrl-text" dataControl="Text"><input type="text" name="LOGIN_NAME" id="LOGIN_NAME_FORM1" value="' + loginName + '"  dataTitle="帐号" dataRequired="true" dataValidType="valid-string"></span></dd></dl><dl class="required mt10"><dt class="tac">密码：</dt><dd><span class="tk-control ctrl-text" dataControl="Text"><input type="password" name="LOGIN_PASS" id="LOGIN_PASS_FORM1" value="" dataTitle="密码" dataValidType=""></span></dd></dl><dl><dt></dt></dl></div></div></div>',
        bottom: { noteHtml: '',
            callback: LoginPostFun
        }, height: 165
    });
    // $("#LOGIN_NAME_FORM1").val(loginName);
}


function LoginPostFun() {
    var login_name = $("#LOGIN_NAME_FORM1").val();
    var login_pass = $("#LOGIN_PASS_FORM1").val();
    var tempUrl = "../Library/WebContentPage.tkx?Source=GatherSource&USERNAME=" +
    login_name + "&USERPASSWORD=" +
    login_pass + "&CMD=NEW";

    $.ajax({
        type: 'get',
        dataType: 'text',
        url: tempUrl,
        cache: false,
        data: {},
        success: function (ahtml) {
            // alert(ahtml);
            var data = Toolkit.json.parse(ahtml);
            //  alert(data);
            // alert(data.HANDLE_CREATE[0].ISSUCESS);
            if (data.HANDLE_CREATE && data.HANDLE_CREATE[0].ISSUCESS == "True") {
                window.location.reload();
            }
            else {
                alert(data.HANDLE_CREATE[0].ERROR);
            }
        }
    }
      );

}


function GatherBind(username,password)
{
    var url = "&USERNAME=" + username + "&USERPASSWORD" + password + "&CMD=" + "NEW";
  GetAjax(url);

}
function GatherUnBind(userIds) {

    var url = "&USERIDS=" + userIds + "&CMD=DEL";
  GetAjax(url);
}

function GetAjax(tempUrl)
{
    tempUrl = "../Library/WebContentPage.tkx?Source=GatherSource" + tempUrl;
$.ajax({
    type: 'get',
    dataType: 'text',
    url: tempUrl,
    cache: false,
    data: {},
    success: function (ahtml) {
        // alert(ahtml);
        var data = Toolkit.json.parse(ahtml);
        //  alert(data);
        // alert(data.HANDLE_CREATE[0].ISSUCESS);
        if (data.HANDLE_CREATE && data.HANDLE_CREATE[0].ISSUCESS == "True") {
            //操作成功
            window.location.reload();
        }
        else {
            alert(data.HANDLE_CREATE[0].ERROR);
        }
    }
}
    );
}
