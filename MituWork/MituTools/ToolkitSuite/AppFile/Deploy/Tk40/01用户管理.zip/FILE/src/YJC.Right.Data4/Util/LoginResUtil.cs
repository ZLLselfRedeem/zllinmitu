using System.Globalization;
using System.Reflection;
using System.Resources;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// LoginResUtil ��ժҪ˵����
    /// </summary>
    internal sealed class LoginResUtil
    {
        private static Assembly fAssembly;
        private static ResourceManager fRm;
        private static CultureInfo fCulture;

        private LoginResUtil()
        {
        }

        private static void GetResourceManager()
        {
            LoginResUtil.fRm = ResourceUtil.GetResourceManager(LoginAssembly, "Login");
        }

        /// <summary>
        /// Toolkit�Լ���Assembly����
        /// </summary>
        public static Assembly LoginAssembly
        {
            get
            {
                if (fAssembly == null)
                {
                    LoginResUtil.fAssembly = Assembly.GetAssembly(typeof(LoginResUtil));
                }

                return LoginResUtil.fAssembly;
            }
        }

        /// <summary>
        /// �����Դ�ļ�������
        /// </summary>
        /// <param name="resName">��Դ�ļ�����</param>
        /// <returns>��Դ�ļ�������</returns>
        public static string GetResourceString(string resName)
        {
            if (LoginResUtil.fRm == null)
            {
                LoginResUtil.GetResourceManager();
            }

            if (LoginResUtil.fCulture == null)
            {
                LoginResUtil.fCulture = ObjectUtil.SysCulture;
            }

            return LoginResUtil.fRm.GetString(resName, LoginResUtil.fCulture);
        }
    }
}
