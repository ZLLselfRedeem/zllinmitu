﻿using System;
using System.Collections.Generic;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right
{
    internal class UserProvider : IUserProvider
    {
        private DbContextConfig fDbConfig;
        private IPasswordProvider fPasswordProvider;

        internal UserProvider(DbContextConfig dbConfig)
        {
            fDbConfig = dbConfig;
        }

        #region IUserProvider 成员

        public bool ChangePassword(string logOnName, string oldPassword, string newPassword)
        {
            oldPassword = PasswordProvider.Format(oldPassword);
            newPassword = PasswordProvider.Format(newPassword);

            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver fResolver = GetUserTableResolver(context, ds))
            {
                DataRow row = null;
                row = fResolver.TrySelectRowWithParam("USER_LOGIN_NAME", logOnName);
                if (row == null)
                    return false;

                if (!row["USER_LOGIN_PASSWD"].ToString().Equals(oldPassword))
                    return false;
                else
                {
                    row.BeginEdit();
                    row["USER_LOGIN_PASSWD"] = newPassword;
                    row["USER_PASSWD_CHANGE_DATE"] = DateTime.Now;
                    row.EndEdit();
                    fResolver.SetCommands(AdapterCommand.Update);
                    fResolver.UpdateDatabase();
                    return true;
                }
            }
        }

        public bool ChangePasswordQuestionAndAnswer(string logOnName, string password,
            string newPasswordQuestion, string newPasswordAnswer)
        {
            return ChangePassword(logOnName, password, newPasswordAnswer);
        }

        public void CreateUser(IUser user)
        {
            DbContext context = fDbConfig.CreateDbContext();
            using (context)
            {
                using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
                using (TableResolver fResolver = GetUserTableResolver(context, ds))
                {
                    DataRow fRow = fResolver.NewRow();
                    fRow.BeginEdit();
                    fRow["USER_ID"] = user.Id;
                    fRow["USER_NAME"] = user.Name;
                    fRow["USER_LOGIN_NAME"] = user.LogOnName;
                    fRow["USER_LOGIN_PASSWD"] = user.GetPassword();
                    fRow["USER_LOGIN_DATE"] = user.LastLogOnDate;
                    fRow["USER_PHONE"] = user.Phone;
                    fRow["USER_EMAIL"] = user.Email;
                    fRow["USER_WORK_NO"] = user.Number;
                    fRow["USER_CREATE_DATE"] = user.CreationDate;
                    fRow["USER_PASSWD_CHANGE_DATE"] = user.LastPasswordChangedDate;
                    fRow["USER_CREATE_ID"] = -1;

                    fRow["USER_ACTIVE"] = user.IsApproved;
                    fRow.EndEdit();
                    fResolver.SetCommands(AdapterCommand.Insert);
                    fResolver.UpdateDatabase();
                }
            }
        }

        public bool DeleteUser(string logOnName, bool deleteAllRelatedData)
        {
            DbContext context = fDbConfig.CreateDbContext();
            using (context)
            {
                using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
                using (TableResolver fResolver = GetUserTableResolver(context, ds))
                {
                    DataRow row = null;
                    row = fResolver.TrySelectRowWithParam("USER_LOGIN_NAME", logOnName);
                    if (row == null)
                    {
                        return false;
                    }
                    else
                    {
                        fResolver.Delete();
                    }
                    fResolver.UpdateDatabase();
                    return true;
                }
            }

        }

        public IEnumerable<IUser> FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize,
            out int totalRecords)
        {
            return GetUsersMatchField("USER_EMAIL", emailToMatch, pageIndex, pageSize, out totalRecords);
        }

        public IEnumerable<IUser> FindUsersByPhone(string phoneToMatch, int pageIndex, int pageSize,
            out int totalRecords)
        {
            return GetUsersMatchField("USER_PHONE", phoneToMatch, pageIndex, pageSize, out totalRecords);
        }

        public IEnumerable<IUser> FindUsersByNumber(string numberToMatch, int pageIndex, int pageSize,
            out int totalRecords)
        {
            return GetUsersMatchField("USER_WORK_NO", numberToMatch, pageIndex, pageSize, out totalRecords);
        }

        public IEnumerable<IUser> FindUsersByName(string fullnameToMatch, int pageIndex, int pageSize,
            out int totalRecords)
        {
            return GetUsersMatchField("USER_NAME", fullnameToMatch, pageIndex, pageSize, out totalRecords);
        }

        public IEnumerable<IUser> GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            return GetUsersMatchField(null, null, pageIndex, pageSize, out totalRecords);
        }

        public int NumberOfUsersOnline
        {
            get
            {
                return 1;
            }
        }

        public string GetPassword(string logOnName, string answer)
        {
            DbContext context = fDbConfig.CreateDbContext();
            using (context)
            {
                answer = "";
                IParamBuilder builder = SqlParamBuilder.CreateEqualSql(context, "USER_LOGIN_NAME", XmlDataType.String, logOnName);
                return DataSetUtil.ExecuteScalar("SELECT USER_LOGIN_PASSWD  FROM UR_USERS", context, builder).ToString();
            }
        }

        public IUser GetUser(string logOnName, bool userIsOnline)
        {
            DbContext context = fDbConfig.CreateDbContext();
            using (context)
            {
                using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
                using (TableResolver fResolver = GetUserTableResolver(context, ds))
                {
                    userIsOnline = true;
                    DataRow row = null;
                    row = fResolver.TrySelectRowWithParam("USER_LOGIN_NAME", logOnName);
                    if (row == null)
                        return null;
                    else
                    {
                        return new User(row, this);
                    }
                }
            }

        }

        public string GetUserNameByEmail(string email)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            {
                DataRow row = GetRowWithParam(ds, "USER_EMAIL", email);
                return row["USER_EMAIL"].ToString();
            }
        }

        public string ResetPassword(string logOnName, string answer)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver fResolver = GetUserTableResolver(context, ds))
            {
                DataRow row = fResolver.TrySelectRowWithParam("USER_LOGIN_NAME", logOnName);
                if (row == null)
                {
                    TkDebug.ThrowToolkitException(string.Format(ObjectUtil.SysCulture, "需要设置密码的登录名为{0}的用户不存在", logOnName), this);
                    return "";
                }
                else
                {
                    string newPasswd = System.Guid.NewGuid().ToString().Substring(0, 10);
                    row.BeginEdit();
                    row["USER_LOGIN_PASSWD"] = PasswordProvider.Format(newPasswd);
                    row["USER_PASSWD_CHANGE_DATE"] = DateTime.Now;

                    row["USER_UPDATE_ID"] = -1;
                    row["USER_UPDATE_DATE"] = DateTime.Now;
                    row.EndEdit();
                    fResolver.SetCommands(AdapterCommand.Update);
                    fResolver.UpdateDatabase();
                    return newPasswd;
                }
            }
        }

        public bool UnlockUser(string logOnName)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver fResolver = GetUserTableResolver(context, ds))
            {
                DataRow row = fResolver.TrySelectRowWithParam("USER_LOGIN_NAME", logOnName);
                if (row == null)
                {
                    TkDebug.ThrowToolkitException(string.Format(ObjectUtil.SysCulture, "需要解锁的登录名为{0}的用户不存在", logOnName), this);
                    return false;
                }
                else
                {
                    row.BeginEdit();
                    if (row["USER_ACTIVE"].Value<int>() == 0)
                    {
                        row["USER_ACTIVE"] = 1;
                    }

                    DateTime now = DateTime.Now;
                    row["USER_UNLOCK_DATE"] = now;
                    row["USER_UPDATE_ID"] = -1;
                    row["USER_UPDATE_DATE"] = now;
                    row.EndEdit();
                    fResolver.SetCommands(AdapterCommand.Update);
                    fResolver.UpdateDatabase();
                    return true;
                }
            }
        }

        public void UpdateUser(IUser user)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver fResolver = GetUserTableResolver(context, ds))
            {
                DateTime now = DateTime.Now;
                DataRow row = fResolver.SelectRowWithKeys(user.Id);
                row.BeginEdit();
                row["USER_ID"] = user.Id;
                row["USER_NAME"] = user.Name;
                row["USER_LOGIN_NAME"] = user.LogOnName;
                row["USER_LOGIN_PASSWD"] = user.GetPassword();
                row["USER_LOGIN_DATE"] = user.LastLogOnDate;
                row["USER_PHONE"] = user.Phone;
                row["USER_EMAIL"] = user.Email;
                row["USER_WORK_NO"] = user.Number;
                row["USER_CREATE_DATE"] = user.CreationDate;
                row["USER_PASSWD_CHANGE_DATE"] = user.LastPasswordChangedDate;
                row["USER_UPDATE_ID"] = -1;
                row["USER_UPDATE_DATE"] = now;
                row.EndEdit();
                fResolver.SetCommands(AdapterCommand.Update);
                fResolver.UpdateDatabase();
            }
        }

        public bool ValidateUser(string logOnName, string password)
        {
            password = PasswordProvider.Format(password);
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver fResolver = GetUserTableResolver(context, ds))
            {
                DataRow row = fResolver.TrySelectRowWithParams(new string[] { "USER_LOGIN_NAME", "USER_LOGIN_PASSWD" },
                    logOnName, password);
                return row != null;
            }
        }

        public string ApplicationName
        {
            get
            {
                return string.Empty;
            }
        }

        public bool EnablePasswordReset
        {
            get
            {
                return true;
            }
        }

        public bool EnablePasswordRetrieval
        {
            get
            {
                return true;
            }
        }

        public int MaxInvalidPasswordAttempts
        {
            get
            {
                return 3;
            }
        }

        public int PasswordAttemptWindow
        {
            get
            {
                return 10;
            }
        }

        public bool RequiresQuestionAndAnswer
        {
            get
            {
                return false;
            }
        }

        public bool RequiresUniqueEmail
        {
            get
            {
                return true;
            }
        }

        public IPasswordProvider PasswordProvider
        {
            get
            {
                if (fPasswordProvider == null)
                {
                    fPasswordProvider = new PasswordProvider();
                }
                return fPasswordProvider;
            }
        }

        public IUser GetUser(string userId)
        {
            DbContext context = fDbConfig.CreateDbContext();
            using (context)
            {
                using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
                using (TableResolver fResolver = GetUserTableResolver(context, ds))
                {
                    DataRow row = fResolver.TrySelectRowWithKeys(userId);
                    if (row == null)
                        return null;
                    else
                    {
                        return new User(row, this);
                    }
                }
            }
        }

        #endregion

        #region 私有方法

        internal static TableResolver GetUserTableResolver(DbContext context, DataSet ds)
        {
            return new TableResolver(DataSetUtil.CreateTableScheme("Users.xml"), context, ds);
        }

        private DataRow GetRowWithParam(DataSet ds, string field, object value)
        {
            DataRow row = null;
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver fResolver = GetUserTableResolver(context, ds))
            {
                row = fResolver.TrySelectRowWithParam(field, value);
            }
            return row;
        }

        private IEnumerable<IUser> GetUsersMatchField(string mathField, string matchValue, int pageIndex, int pageSize,
            out int totalRecords)
        {
            DbContext context = fDbConfig.CreateDbContext();
            using (context)
            {
                using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
                using (TableResolver fResolver = GetUserTableResolver(context, ds))
                {
                    IParamBuilder builder = null;
                    if (!string.IsNullOrEmpty(mathField) && !string.IsNullOrEmpty(matchValue))
                    {
                        builder = SqlParamBuilder.CreateSingleSql(context, mathField, XmlDataType.String,
                           "LIKE", string.Format(ObjectUtil.SysCulture, "%{0}%", matchValue));
                    }
                    else
                        builder = SqlParamBuilder.CreateSql(" 1 = 1");

                    totalRecords = DataSetUtil.ExecuteScalar("SELECT COUNT(*) FROM UR_USERS ", context, builder).Value<int>();
                    int number = (pageIndex + 1) * pageSize;
                    string whereSql = "where " + builder.Sql;
                    using (SqlSelector sqlSelect = new SqlSelector(context, ds))
                    {
                        ISimpleAdapter adapter = sqlSelect;
                        IListSqlContext sqlContext = fDbConfig.GetListSql(fResolver.Fields, "UR_USERS", fResolver.GetKeyFieldArray(),
                            whereSql, "ORDER BY USER_ID", number - pageSize, number);

                        adapter.SetSql(sqlContext.ListSql, builder);
                        fDbConfig.SetListData(sqlContext, adapter, ds, number - pageSize, pageSize, "UR_USERS");
                        return GetArrayFromTable(ds.Tables[fResolver.TableName]);
                    }
                }
            }
        }
        #endregion

        private IEnumerable<IUser> GetArrayFromTable(DataTable dt)
        {
            foreach (DataRow row in dt.Rows)
            {
                yield return new User(row, this);
            }
        }
    }
}
