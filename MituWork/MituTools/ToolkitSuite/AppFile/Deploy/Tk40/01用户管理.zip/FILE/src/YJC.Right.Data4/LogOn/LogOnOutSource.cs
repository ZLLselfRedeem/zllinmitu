﻿using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;
namespace YJC.Toolkit.Right.Data
{
    [OutputRedirector, XmlInputReader]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-16",
        Description = "退出登录")]
    internal class LogOnOutSource : ISource
    {
        internal const string REG_NAME = "LoginOut";
        #region ISource 成员

        WebOutputData ISource.DoAction(WebInputData input)
        {
            GlobalVariable.Session.Abandon();
            GlobalVariable.Request.Cookies.Remove("UserInfo");
            string page = LoginResUtil.GetResourceString("DefaultPage");
            return new WebOutputData(SourceOutputType.String, page);
        }

        #endregion
    }
}
