﻿using System.Data;
using System.Globalization;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right.Data
{
    [XmlInputReader, XmlPageMaker, SourceWebPage(SupportLogOn = false)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-15",
        Description = "获取密码的页面")]
    internal class GetPasswordSource : BaseCustomSource
    {
        internal const string REG_NAME = "GetPassword";

        protected override WebOutputData DoAction(WebInputData input)
        {
            string error = "";

            if (input.IsPost)
            {
                error = this.SendPassword(input);
            }
            return new WebOutputData(SourceOutputType.String, error);
        }

        private string SendPassword(IPageData pageData)
        {
            string loginName = string.Empty;
            DataTable dt = pageData.PostDataSet.Tables["LOGIN"];
            if (dt != null && dt.Rows[0]["LOGIN_NAME"] != null)
            {
                loginName = pageData.PostDataSet.Tables["LOGIN"].Rows[0]["LOGIN_NAME"].ToString().Trim();
            }

            if (!string.IsNullOrEmpty(loginName))
            {
                DbContext context = GlobalVariable.DefaultDbContextConfig.CreateDbContext();

                try
                {
                    DbParameterList dbParameterList = new DbParameterList();
                    dbParameterList.Add("USER_LOGIN_NAME", XmlDataType.String, loginName);
                    SqlSelector selector = new SqlSelector(context, DataSet);
                    string sql = "SELECT * FROM UR_USERS WHERE USER_LOGIN_NAME = {0}";
                    sql = string.Format(sql, Context.GetSqlParamName("USER_LOGIN_NAME"));
                    selector.Select("UR_USERS", sql, dbParameterList);
                    DataRow row = null;
                    if (DataSet.Tables["UR_USERS"] != null && DataSet.Tables["UR_USERS"].Rows.Count > 0)
                    {
                        row = DataSet.Tables["UR_USERS"].Rows[0];
                    }
                    // DataRow row = selector.SelectRow("UR_USERS", "SELECT * FROM UR_USERS WHERE USER_LOGIN_NAME = @USER_LOGIN_NAME", dbParameterList);
                    if (row == null)
                    {
                        return "用户名不存在.";
                    }
                    else
                    {
                        string passwd = PasswdUtil.Decrypt(row["USER_LOGIN_PASSWD"].ToString(), loginName);
                        if (string.IsNullOrEmpty(passwd))
                        {
                            passwd = "空";
                        }
                        string body = LoginResUtil.GetResourceString("GetPasswdBody")
                                    .Replace("{Name}", loginName)
                                    .Replace("{Password}", passwd);
                        string userName = row["USER_NAME"].ToString();
                        string smsPlugin = LoginResUtil.GetResourceString("PasswdBody");
                        if (!string.IsNullOrEmpty(row["USER_MOBILE"].ToString()) && !string.IsNullOrEmpty(smsPlugin))//发短信
                        {
                            //SmsSend sms = (SmsSendRegCategory.GetRegCategory(SmsSendRegCategory.REG_NAME)).NewSmsSend(smsPlugin);
                            //sms.Send(body, row["USER_MOBILE"].ToString());
                            return string.Format(CultureInfo.CurrentCulture, "您的密码已经发送至手机号码{0}，请注意查收.", row["USER_MOBILE"].ToString());
                        }
                        else
                            if (!string.IsNullOrEmpty(row["USER_EMAIL"].ToString()))//发邮件
                            {
                                body = string.Format(CultureInfo.CurrentCulture, LoginResUtil.GetResourceString("MailBody"), userName, body);
                                //MailUtil.GaoDuSend(row["USER_EMAIL"].ToString(), userName + "的登陆密码", body);
                                return string.Format(CultureInfo.CurrentCulture, "您的密码已经发送至邮箱{0}，请注意查收！", row["USER_EMAIL"]);
                            }
                            else
                            {
                                return "由于您的资料中没有填写手机号码和E-mail地址，系统无法通知您密码，请联系系统管理员，并及时维护您的资料，谢谢.";
                            }
                    }
                }
                catch
                {
                    return "取回密码时出错，请联系系统管理员，谢谢.";
                }
            }
            else
            {
                return "用户名不能为空.";
            }
        }

    }
}
