﻿using System.Text;
using System.Web;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right.Data
{
    internal class UrlPageMaker : IPageMaker, IContent
    {

        private string fContent;
        internal const string CONTENT_TYPE = "text/xml";
       // private Encoding fEncoding;

        #region IPageMaker 成员

        public object Prepare(ISource source, IPageData pageData)
        {
            return null;
        }

        public IContent WritePage(ISource source, IPageData pageData, WebOutputData outputData)
        {
            if (string.IsNullOrEmpty(pageData.QueryString["RetURL"]))
            {
                UserLogOnSource userLoginSource = source as UserLogOnSource;

                if (userLoginSource != null && userLoginSource.IsNewUser)
                {
                    fContent = string.Format(ObjectUtil.SysCulture,
                        "../Library/WebContentPage.{0}?Source=MainPage&Main=WebUpdateXmlPage.{0}?Source=Users/UserChgPasswd&ID=-1",
                        pageData.PageExtension);
                }
                else
                {
                    fContent = string.Format(ObjectUtil.SysCulture,
                        "../Library/WebContentPage.{0}?Source=MainPage&Main=WebContentPage.{0}?Source=HomePage",
                        pageData.PageExtension);
                }
            }
            else
            {
                fContent = !pageData.IsPost ? pageData.PostDataSet.Tables["OtherInfo"].Rows[0]["Save"].ToString()
                   : pageData.QueryString["RetURL"];
            }
            fContent = "OK" + fContent;
            return this;
        }

        #endregion

        #region IContent 成员

        public string Content
        {
            get
            {
                return fContent;
            }
        }

        public Encoding ContentEncoding
        {
            get
            {
                return Encoding.UTF8;
            }
        }

        public string ContentType
        {
            get
            {
                return CONTENT_TYPE;
            }
        }

        public void WritePage(HttpResponse response)
        {
        }

        #endregion
    }
}
