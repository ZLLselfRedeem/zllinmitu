﻿using System.Collections;

namespace YJC.Toolkit.Right
{
    internal class FunctionRightItem
    {
        private object fKey;
        private Hashtable fSubFunc;
        private bool fIsLeaf;
        private int fMenuNum;

        public FunctionRightItem(object key)
        {
            fKey = key;
            fSubFunc = new Hashtable();
        }

        public object Key
        {
            get
            {
                return fKey;
            }
        }

        public Hashtable SubFunc
        {
            get
            {
                return fSubFunc;
            }
        }

        public bool IsLeaf
        {
            get
            {
                return fIsLeaf;
            }
            set
            {
                fIsLeaf = value;
            }
        }

        public int MenuNum
        {
            get
            {
                return fMenuNum;
            }
            set
            {
                fMenuNum = value;
            }
        }
    }
}
