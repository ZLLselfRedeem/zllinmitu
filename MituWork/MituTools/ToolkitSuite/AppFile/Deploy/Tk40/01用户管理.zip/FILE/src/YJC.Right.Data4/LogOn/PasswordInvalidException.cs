﻿
using System;
namespace YJC.Toolkit.Right.Data
{
    [Serializable]
    public class PasswordInvalidException : LogOnException
    {
        public PasswordInvalidException()
            : base("LoginPassword", LoginResUtil.GetResourceString("PasswordInvalid"))
        {
        }

    }
}
