using System;
using System.Security.Permissions;
using YJC.Toolkit.Constraint;

namespace YJC.Toolkit.Right.Data
{
    [Serializable]
    public abstract class LogOnException : Exception
    {
        protected LogOnException(ErrorObject errorObject)
            : base()
        {
            ErrorObject = errorObject;
        }

        protected LogOnException(string fieldName, string message)
            : this(new ErrorObject("LOGIN", fieldName, message, 0))
        {
        }

        public ErrorObject ErrorObject
        {
            get;
            private set;
        }
        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
        {
            base.GetObjectData(info, context);
        }
    }
}
