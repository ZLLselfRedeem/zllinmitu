﻿using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data.Gather
{
    [XmlInputReader, XsltPageMaker(XSLT_PATH, FilePathPosition.Xml)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2011-08-03", Description = "头部菜单")]
    internal class GatherMenuSource : BaseCustomSource
    {
        internal const string REG_NAME = "GatherMenuSource";
        internal const string XSLT_PATH = "Project/Users/GatherMenu.xslt";

        protected override void FillCustomTables(IPageData pageData)
        {
            TableResolver userRes = new TableResolver("UR_USERS", Context, this.DataSet);
            using (userRes)
            {
                DbParameterList dblist = new DbParameterList();
                dblist.Add("USER_ID", XmlDataType.String, GlobalVariable.UserId);
                string sql = " WHERE USER_GATHER IN (SELECT USER_GATHER FROM UR_USERS WHERE USER_ID = @USER_ID) AND USER_ID <> @USER_ID ";
                userRes.Select(sql, dblist);
            }
            base.FillCustomTables(pageData);
        }
    }
}
