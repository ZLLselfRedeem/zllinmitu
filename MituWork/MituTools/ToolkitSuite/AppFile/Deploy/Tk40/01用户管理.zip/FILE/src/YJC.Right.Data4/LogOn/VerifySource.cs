﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    [XmlInputReader, WebFilePageMaker, SourceWebPage(SupportLogOn = false)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-16",
        Description = "验证码页面")]
    internal class VerifySource : ISource
    {
        internal const string REG_NAME = "Verify";
        private string Rgb;
        private string FontColor;
        private string key;

        #region ISource 成员

        WebOutputData ISource.DoAction(WebInputData input)
        {
            Rgb = input.QueryString["Rgb"];
            FontColor = input.QueryString["FontColor"];
            string verifyKey = "";
            if (key != null && !string.IsNullOrEmpty(key))
            {
                string config = LoginResUtil.GetResourceString("VerifyKeys");
                if (config.IndexOf(string.Format(CultureInfo.CurrentCulture, ",{0},", key), StringComparison.Ordinal) < 0)
                    key = "VerifyKey";
            }
            else
                key = "VerifyKey";

            byte[] image = GenerateVerifyImage(5, Rgb, FontColor, ref verifyKey);

            GlobalVariable.Session[key] = verifyKey;
            GlobalVariable.Response.ClearContent();

            FileContent content = new FileContent("image/jpeg", "verify", image);
            return new WebOutputData(SourceOutputType.Object, content);
        }
        /// <summary>
        /// 生成卡通图片验证码
        /// </summary>
        /// <param name="nLen">验证码的长度</param>
        /// <param name="strKey">输出参数，验证码的内容</param>
        /// <returns>图片字节流</returns>
        public static byte[] GenerateVerifyImage(int nLen, string rgb, string fontColor, ref string strKey)
        {
            Random rd = new Random((int)DateTime.Now.Ticks);
            int nBmpWidth = 13 * nLen + 5;
            int nBmpHeight = 20;
            Bitmap bmp = new Bitmap(nBmpWidth, nBmpHeight);

            // 1. 生成随机背景颜色
            int nRed, nGreen, nBlue;  // 背景的三元色
            nRed = rd.Next(0xFF) % 0x80 + 0x80;
            nGreen = rd.Next(0xFF) % 0x80 + 0x80;
            nBlue = rd.Next(0xFF) % 0x80 + 0x80;
            GetRGB(rgb, ref nRed, ref nGreen, ref nBlue);

            Graphics graph = Graphics.FromImage(bmp);
            // 2. 填充位图背景
            graph.FillRectangle(new SolidBrush(Color.FromArgb(nRed, nGreen, nBlue)), 0, 0, nBmpWidth, nBmpHeight);

            // 3. 绘制干扰线条，采用比背景略深一些的颜色
            int nLines = 3;
            Pen pen = new Pen(Color.FromArgb(nRed - 17, nGreen - 17, nBlue - 17), 2);
            for (int i = 0; i < nLines; i++)
            {
                int x1 = rd.Next() % nBmpWidth;
                int y1 = rd.Next() % nBmpHeight;
                int x2 = rd.Next() % nBmpWidth;
                int y2 = rd.Next() % nBmpHeight;
                graph.DrawLine(pen, x1, y1, x2, y2);
            }

            // 采用的字符集，可以随即拓展，并可以控制字符出现的几率
            string strCode = "0123456789";//"ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            // 4. 循环取得字符，并绘制
            int fontRed, fontGreen, fontBlue;//字符的三元色
            string strResult = "";
            for (int i = 0; i < nLen; i++)
            {
                int x = (i * 13 + rd.Next(3));
                int y = rd.Next(4) + 1;

                // 确定字体
                Font font = new Font("Courier New", 11 + rd.Next() % 4, FontStyle.Bold);
                char c = strCode[rd.Next(strCode.Length)];  // 随机获取字符
                strResult += c.ToString();

                // 绘制字符
                fontRed = nRed - 60 + y * 3;
                fontGreen = nGreen - 60 + y * 3;
                fontBlue = nBlue - 40 + y * 3;
                GetRGB(fontColor, ref fontRed, ref fontGreen, ref fontBlue);
                graph.DrawString(c.ToString(), font, new SolidBrush(Color.FromArgb(fontRed, fontGreen, fontBlue)), x, y);
            }

            // 5. 输出字节流

            MemoryStream bstream = new MemoryStream();
            using (bstream)
            {
                bmp.Save(bstream, ImageFormat.Jpeg);
                bmp.Dispose();
                graph.Dispose();

                strKey = strResult;
                byte[] byteReturn = bstream.ToArray();
                bstream.Close();
                return byteReturn;
            }



        }
        private static void GetRGB(string color, ref int nRed, ref int nGreen, ref int nBlue)
        {
            if (color == null || string.IsNullOrEmpty(color) || color == "-1")
                return;
            if (color.IndexOf(",", StringComparison.Ordinal) < 0)
            {
                try
                {
                    long lgColor = Convert.ToInt64(color.Substring(1), 16);
                    // long lgBlue = lgColor / 65536;
                    long lgBlue = lgColor >> 16;
                    // long lgGreen = (lgColor - nBlue * 65536) / 256;
                    long lgGreen = (lgColor - nBlue << 16) >> 8;
                    long lgRed = lgColor - nGreen << 8 - nBlue << 16;

                    nBlue = (int)lgBlue;
                    nGreen = (int)lgGreen;
                    nRed = (int)lgRed;
                }
                catch
                {
                }
            }
            else
            {
                string[] rgbArray = color.Split(',');

                nRed = XmlUtil.GetDefaultValue(rgbArray[0], 0);
                nGreen = XmlUtil.GetDefaultValue(rgbArray[1], 0);
                nBlue = XmlUtil.GetDefaultValue(rgbArray[2], 0);
            }
        }
        #endregion
    }
}
