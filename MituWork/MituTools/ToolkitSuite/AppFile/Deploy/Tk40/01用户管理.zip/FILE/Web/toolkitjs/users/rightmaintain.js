﻿function ToolkitData() {
    this.SYS_PART_FUNC = [];
    this.SYS_PART_SUB_FUNC = [];
}
function sysPartFunc() {
    this.PF_FN_ID = null;
}
function sysPartSubFunc() {
    this.PSF_SF_ID = null;
}
var first = false;
function TreeNode() {
    this.key = null;
    this.parentKey = null;
    this.isLeaf = true;
    this.text = null;
    this.checkbox = null;
    this.checkboxValue = null;
    this.children = [];

    this.isExpand = true ;
    if (TreeNode.prototype.create === undefined) {
        TreeNode.prototype.create = function (funObj) {
            this.checkboxValue = this.key = funObj.FN_ID;
            this.parentKey = null;
            this.isLeaf = funObj.FN_IS_LEAF == "1";
            this.text = funObj.FN_NAME;
            this.checkbox = false;

            if (this.parentKey = "-1") {
                if (first == true) {
                    this.isExpand = false;
                }
                first = true;
            }

        }
    }
    if (TreeNode.prototype.createHtml === undefined) {
        TreeNode.prototype.createHtml = function (data) {
            var liItem = $("<li></li>");
            if (!this.isExpand) {
                liItem.addClass("closed");
            }
            var r = $('<input type="checkbox" class="ckTreeNode ckFun" value="' + this.checkboxValue + '"' + (IsCheckFun(this.checkboxValue, data) ? ' checked' : '') + ' /><span>' + this.text + '</span>');
            liItem.append(r);
            var _childList = GetSubChildrenByPid(this.checkboxValue, data);
            if (_childList.length > 0) {
                var childItem = $('<span class="db bge p5 mt5 clearfix ml20"></span>');
                for (var i = 0; i < _childList.length; i++) {
                    var sp = $('<label><input type="checkbox" class="ckTreeNode ckSubFun" style="margin:0" value="' + _childList[i].SF_ID + '"' + (IsCheckSubFun(_childList[i].SF_ID, data) ? ' checked' : '') + '><span class="db fl mr10">' + _childList[i].SF_NAME + '</span></label>');
                    childItem.append(sp);
                }
                liItem.append(childItem);
            }
            if (this.children.length > 0) {
                var ulItem = $("<ul></ul>");
                for (var i = 0; i < this.children.length; i++) {
                    ulItem.append(this.children[i].createHtml(data));
                }
                liItem.append(ulItem);
            }
            return liItem;
        }
    }
}

function CreateTreeFromUrl(url) {

    var opion = {
        type: "GET",
        url: "WebContentPage.tkx?Source=RightMaintain&ID=" + partId + "&DATA=1&ff=",
        dataType: "json",
        error: _funError,
        success: _funSuccess,
        beforeSend: _funBefore,
        cache: false
    };
    $.ajax(opion);
    //alert($.ajax);

}
function _funError(data) {
    // alert("错误" + data);
    alert("错误" + "  " + data.status + "  " + data.statusText);
}
function _funBefore(data) {
    //alert("开始请求");
}
var hsFunction = new Object();
var root = new TreeNode();
function _funSuccess(data) {
    // alert("成功");
	$('#DvUl .loading').remove();
    //
    root.text = "选择所有";
    root.key = -1;
    CreateTree(root, data);
    $("#DvUl").append(root.createHtml(data));
    Toolkit.load('treeview', function () {
        $("#DvUl").treeview({});
    });
    $(".ckFun").click(function () {
        $(this).siblings().find(".ckTreeNode").attr('checked', $(this).attr('checked'));
    });
}

function GetChildrenByPid(pid, data) {
    var _listChildren = [];
    if (data.SYS_FUNCTION) {
        for (var i = 0; i < data.SYS_FUNCTION.length; i++) {
            var _function = data.SYS_FUNCTION[i];
            _listChildren.push(_function);
        }
    }
    return _listChildren;
}
function GetSubChildrenByPid(pid, data) {
    var _listChildren = [];
    if (data.SYS_SUB_FUNC) {
        for (var i = 0; i < data.SYS_SUB_FUNC.length; i++) {
            var _function = data.SYS_SUB_FUNC[i];
            {
                if (_function.SF_FN_ID == pid)
                    _listChildren.push(_function);
            }
        }
    }
    return _listChildren;
}
function CreateTree(treeNode, data) {
    var _pid = treeNode.key;
    var _childList = GetChildrenByPid(_pid, data);
    for (var i = 0; i < _childList.length; i++) {

        var _child = _childList[i];
        if (_child.FN_PARENT_ID == _pid) {
            var _node = new TreeNode();
            _node.create(_child);
            treeNode.children.push(_node);
            CreateTree(_node, data);
        }
    }
}

function IsCheckFun(key, data) {
    var funPart = data.SYS_PART_FUNC;
    if (funPart != null) {
        for (var i = 0; i < funPart.length; i++) {
            var _item = funPart[i];
            if (_item.PF_FN_ID == key) {
                return true;
            }
        }
    }
    return false;
}
function IsCheckSubFun(key, data) {
    var funPart = data.SYS_PART_SUB_FUNC;
    if (funPart != null) {
        for (var i = 0; i < funPart.length; i++) {
            var _item = funPart[i];
            if (_item.PSF_SF_ID == key) {
                return true;
            }
        }
    }
    return false;
}

function Save() {
    //alert(44);
    var postData = new ToolkitData();
    $(".ckFun").each(
            function () {
                if ($(this).attr("checked"))
                    postData.SYS_PART_FUNC.push({ "PF_FN_ID": $(this).val() });
            }
            );
    $(".ckSubFun").each(
            function () {
                if ($(this).attr("checked"))
                    postData.SYS_PART_SUB_FUNC.push({ "PSF_SF_ID": $(this).val() });
            }
            );
    //alert(Toolkit.json.stringify(postData));
    $.ajax({
        type: 'post',
        dataType: 'text',
        url: "WebContentPage.tkx?Source=RightMaintain&ID=" + partId,
        data: Toolkit.json.stringify(postData),
        success: postSuccess
    });
}
function postSuccess(reg) {
    if (reg == "OK") {
        alert("修改成功");
    }
    else {
        alert(reg);
    }
}
$(function () {
    CreateTreeFromUrl();
});