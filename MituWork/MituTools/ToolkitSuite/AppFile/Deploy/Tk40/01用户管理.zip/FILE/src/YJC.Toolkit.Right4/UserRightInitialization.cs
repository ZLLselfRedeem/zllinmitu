﻿using System.Web;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right
{
    internal class UserRightInitialization : IInitialization
    {
        #region IInitialization 成员

        public void ApplicationEnd(HttpApplication application)
        {
        }

        public void ApplicationStart(HttpApplication application)
        {
        }

        public void SessionEnd(HttpApplication application)
        {
        }

        public void SessionStart(HttpApplication application, SessionGlobal sessionGlobal)
        {
            if (sessionGlobal != null)
            {
                sessionGlobal.AppRight.LogOnRight = new UserLogOnRight();
                sessionGlobal.AppRight.ScriptBuilder = new DataMenuScriptBuilder();
                sessionGlobal.AppRight.FunctionRight = new SimpleFunctionRight();
            }
        }

        #endregion
    }
}
