﻿using System;
using System.IO;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right
{
    internal class AjaxPageMaker : CompositePageMaker
    {
        private readonly string shellPageXslt = Path.Combine(AppSetting.Current.XmlPath,
            "project/users/RightMaintainHtml.xslt");

        public AjaxPageMaker()
        {
            Add(ShellPage,new SimpleXsltPageMaker(shellPageXslt));
            Add(AskData,new JsonPageMaker());
            Add(ElseTrue, new SourceOutputPageMaker());
        }

        private bool ShellPage(ISource source, IPageData pageData, WebOutputData data)
        {
            return !pageData.IsPost && !string.IsNullOrEmpty(pageData.QueryString["SHELL"]);

        }
        private bool AskData(ISource source, IPageData pageData, WebOutputData data)
        {
            return !pageData.IsPost && !string.IsNullOrEmpty(pageData.QueryString["DATA"]);
        }
        private bool ElseTrue(ISource source, IPageData pageData, WebOutputData data)
        {
            //data = new WebOutputData(SourceOutputType.String, "NO ROUTE");
            //sourceoutputPagemaker
            return true;
        }

        private bool PostSubmit(ISource source, IPageData pageData, WebOutputData data)
        {
            return pageData.IsPost;
        }
    }
}
