﻿using System;
using System.Data;
using System.Globalization;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    [XmlInputReader, XsltPageMaker("Bin/HomePage.xslt", FilePathPosition.Xml), SourceWebPage(SupportLogOn = true)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-15", Description = "主页面")]
    internal class HomePageSource : BaseCustomSource
    {
        internal const string REG_NAME = "HomePage";
        private DateTime fCurrentDate;
        private readonly string[] WeekNames = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };

        public DateTime CurrentDate
        {
            get
            {
                return fCurrentDate;
            }
            set
            {
                fCurrentDate = value;
                SetUserInfo();
                SetDateDesc();
                SetMonthDesc();
            }
        }

        protected override void FillCustomTables(IPageData pageData)
        {
            string dateStr = pageData.QueryString["Date"];
            DateTime date;
            try
            {
                date = DateTime.Parse(dateStr, CultureInfo.CurrentCulture);
            }
            catch
            {
                date = DateTime.Now;
            }
            this.CurrentDate = date;
            base.FillCustomTables(pageData);
        }

        private void SetUserInfo()
        {
            DataTable table = DataSetUtil.CreateDataTable("UserInfo", "UserName", "Welcome", "IframeSrc");
            table.Rows.Add(new object[] { GlobalVariable.Info.UserName, LoginResUtil.GetResourceString("HomePageWelcome"), LoginResUtil.GetResourceString("HomePageIframeSrc") });
            this.DataSet.Tables.Add(table);
        }

        private void SetDateDesc()
        {
            DataTable table = DataSetUtil.CreateDataTable("DateDesc", "Now", "Prev", "Next", "FindDate", "Year", "Month");
            DataRow row = table.NewRow();
            row.BeginEdit();
            row["Now"] = row["FindDate"] = fCurrentDate.ToString("yyyy-MM-dd", CultureInfo.CurrentCulture);
            row["Prev"] = fCurrentDate.AddMonths(-1).ToString("yyyy-MM-dd", CultureInfo.CurrentCulture);
            row["Next"] = fCurrentDate.AddMonths(1).ToString("yyyy-MM-dd", CultureInfo.CurrentCulture);
            row["Year"] = fCurrentDate.Year;
            row["Month"] = fCurrentDate.Month;
            row.EndEdit();
            table.Rows.Add(row);
            this.DataSet.Tables.Add(table);
        }

        private void SetMonthDesc()
        {
            DataTable table = DataSetUtil.CreateDataTable("DayDesc", "Month", "Day", "Date", "ChName", "WeekName", "LongDate");
            int monthNow = fCurrentDate.Month;
            DateTime firstDateOfMonth = fCurrentDate.AddDays(-(fCurrentDate.Day - 1));
            DateTime firstDateOfWeekMonth = firstDateOfMonth.AddDays(-(int)firstDateOfMonth.DayOfWeek);
            DateTime calcDateOfMonth = firstDateOfMonth;
            int addValue = 0;
            //LunarDate firstDayLunar = new LunarDate();
            do
            {
                for (int i = 0; i < 7; ++i)
                {
                    DataRow row = table.NewRow();
                    DateTime calDate = firstDateOfWeekMonth.AddDays(addValue);
                    row.BeginEdit();
                    row["Month"] = calDate.Month;
                    row["Day"] = calDate.Day;
                    row["Date"] = calDate.ToString("yyyy-MM-dd", CultureInfo.CurrentCulture);
                    // row["ChName"] = SolarLunarUtil.LunarDayInc(calDate, firstDayLunar); ;
                    row["ChName"] = ChineseDateUtil.GetChineseDateText(calDate);
                    row["WeekName"] = WeekNames[(int)calDate.DayOfWeek];
                    row["LongDate"] = calDate.ToLongDateString();
                    row.EndEdit();
                    table.Rows.Add(row);
                    ++addValue;
                }
                calcDateOfMonth = firstDateOfWeekMonth.AddDays(addValue);
            } while (calcDateOfMonth.Month == monthNow);
            this.DataSet.Tables.Add(table);
        }
    }
}
