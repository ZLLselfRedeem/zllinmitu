﻿using System.Collections;
using System.Collections.Generic;
using System.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right
{
    internal class Organization : IOrganization
    {
        private string fOrgId;
        private string fOrgName;
        private string fOrgCode;
        private string fOrgParentId;
        private int fOrgIsLeaf;
        private OrganizationProvider fProvider;
        private bool fHasChildren;

        private IEnumerable<IOrganization> fAllDescendants;
        private bool fIsGetAllDescendants;

        private IEnumerable fChildren;
        private bool fIsGetChildren;

        private ITreeNode fParent;
        private bool fIsGetParent;

        private string fLayer;

        public Organization(DataRow row, OrganizationProvider provider)
        {
            fProvider = provider;

            fOrgId = row["ORG_ID"].ToString();
            fOrgName = row["ORG_NAME"].ToString();
            fOrgCode = row["ORG_CODE"].ToString();
            fOrgParentId = row["ORG_PARENT_ID"].ToString();
            fOrgIsLeaf = row["ORG_IS_LEAF"].Value<int>();
            fLayer = row["ORG_LAYER"].ToString();
            fHasChildren = fOrgIsLeaf == 1;
        }

        public string Layer
        {
            get
            {
                return fLayer;
            }
        }

        #region IOrganization 成员

        public bool HasDepartment
        {
            get
            {
                return false;
            }
        }

        public bool IsDepartment
        {
            get
            {
                return false;
            }
        }

        public string OrgCode
        {
            get
            {
                return fOrgCode;
            }
        }

        #endregion

        #region ITreeNode 成员

        public IEnumerable AllDescendants
        {
            get
            {
                if (!fIsGetAllDescendants)
                {
                    fAllDescendants = fProvider.GetDescendant(Id);
                    fIsGetAllDescendants = true;
                }
                return fAllDescendants;
            }
        }

        public IEnumerable Children
        {
            get
            {
                if (!fIsGetChildren)
                {
                    fChildren = fProvider.GetChildren(fOrgId);
                    fIsGetChildren = true;
                }
                return fChildren;
            }
        }

        public bool HasChildren
        {
            get
            {
                return fHasChildren;
            }
        }

        public ITreeNode Parent
        {
            get
            {
                if (!fIsGetParent)
                {
                    fParent = fProvider.GetOrgById(fOrgParentId);
                    fIsGetParent = true;
                }
                return fParent;
            }
        }

        public string ParentId
        {
            get
            {
                return fOrgParentId;
            }
        }

        #endregion

        #region IEntity 成员

        public string Id
        {
            get
            {
                return fOrgId;
            }
        }

        public string Name
        {
            get
            {
                return fOrgName;
            }
        }

        #endregion
    }
}
