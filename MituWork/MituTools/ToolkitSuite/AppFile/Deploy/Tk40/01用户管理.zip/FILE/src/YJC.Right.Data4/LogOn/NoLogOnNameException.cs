
using System;
namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// NoLoginNameException ��ժҪ˵����
    /// </summary>
    [Serializable]
    public class NoLogOnNameException : LogOnException
    {
        public NoLogOnNameException()
            : base("LOGIN_NAME", LoginResUtil.GetResourceString("NoLoginName"))
        {
        }
    }
}
