﻿using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Xml.Linq;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;
namespace YJC.Toolkit.Right.Data
{
    [XmlInputReader, XsltPageMaker(XSLT_PATH, FilePathPosition.Xml)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2011-08-03", Description = "头部菜单")]
    internal class HeadMenuSource : BaseCustomSource
    {
        internal const string REG_NAME = "HeadMenu";
        internal const string XSLT_PATH = "Project/Users/HeadMenu.xslt";
        internal const string HEAD_MENU_SESSION = "HEAD_MENU_SESSION";

        protected override void FillCustomTables(IPageData pageData)
        {
            object leftMenu = GlobalVariable.Session[HEAD_MENU_SESSION];
            if (leftMenu == null)
            {
                leftMenu = GlobalVariable.SessionGbl.AppRight.GetMenuScript(GlobalVariable.Info.UserId);

                // leftMenu = SetFuncTable(ds);
            }
            StringReader stringReader = new StringReader(leftMenu.ToString());
            DataSet.ReadXml(stringReader);
            base.FillCustomTables(pageData);
        }

        //private string SetFuncTable(DataSet dataset)
        //{
        //    XElement root = new XElement("ul", new XAttribute("class", "tk-dropmenu"));
        //    Dictionary<string, XElement> dictionList = new Dictionary<string, XElement>();

        //    DataTable table = dataset.Tables["SYS_FUNCTION"];

        //    if (table != null)
        //    {
        //        foreach (DataRow row in table.Rows)
        //        {
        //            //int layer = int.Parse(row["FN_LAYER"].ToString(), CultureInfo.CurrentCulture);
        //            int layer = row["FN_LAYER"].Value<int>();
        //            string key = row["FN_ID"].ToString();
        //            bool isLeaf = (row["FN_IS_LEAF"].ToString() == "1") ? true : false;

        //            XElement nA = new XElement("a", new XAttribute("href", row["FN_URL"].ToString()), row["FN_NAME"]);
        //            nA.Add(new XAttribute("target", "tkFrameMain"));
        //            XElement nLi = new XElement("li", nA);
        //            dictionList.Add(key, nLi);

        //            if (layer == 0)
        //            {
        //                // item.MenuNum = ++nMenu;
        //                //fScript.AppendFormat(MenuScript, nMenu, row["FN_NAME"]);
        //                root.Add(nLi);
        //            }
        //            else
        //            {
        //                XElement parentLi = dictionList[row["FN_PARENT_ID"].ToString()];
        //                XElement nUl = parentLi.Element("ul");
        //                if (nUl == null)
        //                {
        //                    nUl = new XElement("ul", "");
        //                    parentLi.Add(nUl);
        //                }

        //                nUl.Add(nLi);

        //            }
        //        }
        //    }
        //    return root.ToString();
        //}
    }
}
