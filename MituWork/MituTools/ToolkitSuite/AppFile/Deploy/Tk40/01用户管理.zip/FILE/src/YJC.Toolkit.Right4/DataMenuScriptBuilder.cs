﻿using System.Data;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right
{
    internal class DataMenuScriptBuilder : IMenuScriptBuilder
    {
        //private StringBuilder fScript;
        //private string fScriptString;

        //public Hashtable fFunction;
        //public Hashtable fShortName;

        //private const string MenuScript = "  mpmenu{0} = new mMenu('{1}','','mFrame');\n";
        //private const string SubMenuScript = "  mpmenu{0}.addItem(new mMenuItem('{1}','{2}','mFrame',false,null));\n";
        //private const string NSubMenuScript = "  msub{0}.addsubItem(new mMenuItem('{1}','{2}','mFrame',false,null));\n";
        //private const string NewSubMenuScript = "  msub{0} = new mMenuItem('{1}','{2}','mFrame',false,'{3}');\n";
        //private const string AddSubMenuScript = "  mpmenu{1}.addItem(msub{0});\n";
        //private const string NAddSubMenuScript = "  msub{1}.addsubItem(msub{0});\n";
        //private const int BLOCK = 16 * 1024;

        public DataMenuScriptBuilder()
        {
            //fFunction = new Hashtable();
            //fShortName = new Hashtable();
            //fScript = new StringBuilder(BLOCK);
        }

        #region IMenuScriptBuilder 成员

        string IMenuScriptBuilder.GetMenuScript(DataSet menuDataSet)
        {
            //fFunction.Clear();
            //fShortName.Clear();
            //fScript = new StringBuilder(BLOCK);

            //SetFuncTable(menuDataSet);

            //fScriptString = string.Format(CultureInfo.CurrentCulture, "<script language='javascript'>\n $( function() {{\n	"
            //   + "//***** 添加菜单 *****\n{0}}})\n</script>\n", fScript.ToString());
            if (menuDataSet != null)
            {
                return menuDataSet.GetXml();
                // menuDataSet = new DataSet() { Locale = ObjectUtil.SysCulture}; 
            }
            else
                return "";         
        }

        #endregion


        //private void SetFuncTable(DataSet dataset)
        //{
        //    int nMenu = 0;
        //    int nSub = 0;

        //    DataTable table = dataset.Tables["SYS_FUNCTION"];

        //    if (table != null)
        //    {
        //        foreach (DataRow row in table.Rows)
        //        {
        //            //int layer = int.Parse(row["FN_LAYER"].ToString(), CultureInfo.CurrentCulture);
        //            int layer = row["FN_LAYER"].Value<int>();
        //            string key = row["FN_ID"].ToString();
        //            bool isLeaf = (row["FN_IS_LEAF"].ToString() == "1") ? true : false;
        //            FunctionRightItem item = new FunctionRightItem(key);

        //            item.IsLeaf = isLeaf;
        //            fFunction.Add(key, item);
        //            if (row["FN_SHORT_NAME"].ToString().Length > 0 && !(fShortName.Contains(row["FN_SHORT_NAME"])))
        //            {
        //                fShortName.Add(row["FN_SHORT_NAME"], key);
        //            }
        //            if (layer == 0)
        //            {
        //                item.MenuNum = ++nMenu;
        //                fScript.AppendFormat(MenuScript, nMenu, row["FN_NAME"]);
        //            }
        //            else
        //            {
        //                FunctionRightItem parentItem = (FunctionRightItem)fFunction[row["FN_PARENT_ID"].ToString()];

        //                if (isLeaf)
        //                {
        //                    if (layer == 1)
        //                    {
        //                        fScript.AppendFormat(SubMenuScript, parentItem.MenuNum, row["FN_NAME"], row["FN_URL"]);
        //                    }
        //                    else
        //                    {
        //                        fScript.AppendFormat(NSubMenuScript, parentItem.MenuNum, row["FN_NAME"], row["FN_URL"]);
        //                    }
        //                }
        //                else
        //                {
        //                    item.MenuNum = ++nSub;
        //                    fScript.AppendFormat(CultureInfo.CurrentCulture, NewSubMenuScript, nSub, row["FN_NAME"], row["FN_URL"], layer);
        //                    if (layer == 1)
        //                    {
        //                        fScript.AppendFormat(AddSubMenuScript, nSub, parentItem.MenuNum);
        //                    }
        //                    else
        //                    {
        //                        fScript.AppendFormat(NAddSubMenuScript, nSub, parentItem.MenuNum);
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}
    }
}
