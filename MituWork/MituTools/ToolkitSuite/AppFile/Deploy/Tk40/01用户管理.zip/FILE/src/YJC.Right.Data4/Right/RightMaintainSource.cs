﻿using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;
namespace YJC.Toolkit.Right.Data
{
    [Source(REG_NAME, Author = "fongsl", CreateDate = "2010-09-15", Description = "RightMaintain 表的数据访问对象")]
    //[XmlInputReader, XsltPageMaker("Project/Users/RightMaintainUpdate.xslt", FilePathPosition.Xml)]
    [SourcePageMaker(typeof(AjaxPageMaker)), SourceWebPage(SupportLogOn = true)]
    [JsonInputReader]
    internal class RightMaintainSource : BaseCustomSource
    {
        internal const string REG_NAME = "RightMaintain";
        private readonly PartFunctionResolver fPartFunc;
        private readonly PartSubFunctionResolver fPartSubFunc;

        public RightMaintainSource()
            : base()
        {
            this.fPartFunc = new PartFunctionResolver(this.Context, this.DataSet);
            this.fPartSubFunc = new PartSubFunctionResolver(this.Context, this.DataSet);
        }

        protected override void FillCustomTables(IPageData pageData)
        {
            if (pageData.IsPost)
            {
                string key = pageData.QueryString["ID"];

                DataSet ds = pageData.PostDataSet;

                CopyDelInsTable(this.fPartFunc, ds.Tables["SYS_PART_FUNC"], key, "PF_FN_ID", "PF_FN_ID", "PF_PART_ID");
                CopyDelInsTable(this.fPartSubFunc, ds.Tables["SYS_PART_SUB_FUNC"], key, "PSF_SF_ID", "PSF_SF_ID", "PSF_PART_ID");

                this.fPartFunc.UpdateDatabase();
                this.fPartSubFunc.UpdateDatabase();
            }
            else
            {
                this.fPartFunc.SelectWithParam("PF_PART_ID", pageData.QueryString["ID"]);
                this.fPartSubFunc.SelectWithParam("PSF_PART_ID", pageData.QueryString["ID"]);

                FunctionResolver function = new FunctionResolver(this.Context, this);
                function.Select("ORDER BY FN_TREE_LAYER");

                SubFunctionResolver subFunc = new SubFunctionResolver(this.Context, this);
                subFunc.Select(string.Empty);
            }
        }

        protected override WebOutputData DoAction(WebInputData input)
        {
            try
            {
                if (!input.IsPost)
                {
                    input.UrlInfo.AddToDataSet(this, this.DataSet);
                }

                return base.DoAction(input);
            }
            catch (Exception ex)
            {
                return new WebOutputData(SourceOutputType.String, ex.Message);
            }
        }

        protected override WebOutputData CreateOutputData(WebInputData input)
        {
            if (input.IsPost)
            {
                return new WebOutputData(SourceOutputType.String, "OK");
            }
            return base.CreateOutputData(input);
        }

        private static void CopyDelInsTable(TableResolver resolver, DataTable postTable, string key, string postKeyField, string keyField, string partField)
        {
            resolver.SelectWithParam(partField, key);
            resolver.SetCommands(AdapterCommand.Delete | AdapterCommand.Insert);
            DataTable dt = resolver.HostTable;
            foreach (DataRow row in dt.Rows)
            {
                row.Delete();
            }
            if (postTable != null)
            {
                foreach (DataRow row in postTable.Rows)
                {
                    if (row[postKeyField] != null && !string.IsNullOrEmpty(row[postKeyField].ToString()))
                    {
                        if (row[postKeyField].ToString() != "0")
                        {
                            DataRow newRow = dt.NewRow();

                            newRow.BeginEdit();
                            newRow[partField] = key;
                            newRow[keyField] = row[postKeyField].Value<int>();
                            newRow.EndEdit();
                            dt.Rows.Add(newRow);
                        }
                    }
                }
            }
        }
    }
}
