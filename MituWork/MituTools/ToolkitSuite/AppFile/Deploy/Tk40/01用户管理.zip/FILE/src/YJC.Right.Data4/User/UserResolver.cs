﻿using System;
using System.Data;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(REG_NAME)]
    internal class UserResolver : Tk4TableResolver
    {
        public const string REG_NAME = "Users";

        public UserResolver(DbContext context, IDataSource source)
            : base("Users/Users.xml", context, source)
        {
        }

        protected override void OnUpdatingRow(UpdatingEventArgs e)
        {
            base.OnUpdatingRow(e);

            switch (e.Status)
            {
                case UpdateKind.Insert:
                    e.Row["USER_ID"] = Context.GetUniId(TableName);
                    e.Row["USER_CREATE_ID"] = e.Row["USER_UPDATE_ID"] = GlobalVariable.UserId;
                    e.Row["USER_CREATE_DATE"] = e.Row["USER_UPDATE_DATE"] = DateTime.Now;
                    break;
                case UpdateKind.Update:
                    e.Row["USER_UPDATE_ID"] = GlobalVariable.UserId;
                    e.Row["USER_UPDATE_DATE"] = DateTime.Now;
                    break;
            }

        }

        private void ChangeUserState(DataRow rowUser, bool isValid, UserInfo info)
        {
            string strSQL = string.Empty;

            DbParameterList parameters = new DbParameterList();

            if (!isValid)
            {
                strSQL = "UPDATE UR_USERS SET USER_ACTIVE = 0, USER_UNLOCK_DATE = {0} WHERE USER_ID ={1} ";
                strSQL = string.Format(strSQL, Context.GetSqlParamName("USER_UNLOCK_DATE"), Context.GetSqlParamName("USER_ID"));
                parameters.Add("USER_UNLOCK_DATE", XmlDataType.DateTime, DateTime.Now.AddDays(1));
                parameters.Add("USER_ID", XmlDataType.String, rowUser["USER_ID"]);
            }
            else
            {
                strSQL = "UPDATE UR_USERS SET USER_ACTIVE = 1, USER_LOGIN_DATE = {0}, USER_UNLOCK_DATE = NULL WHERE USER_ID = {1} ";
                strSQL = string.Format(strSQL, Context.GetSqlParamName("USER_LOGIN_DATE"), Context.GetSqlParamName("USER_ID"));
                parameters.Add("USER_LOGIN_DATE", XmlDataType.DateTime, DateTime.Now);
                parameters.Add("USER_ID", XmlDataType.String, rowUser["USER_ID"]);

                info.IsLogOn = true;
                info.UserId = rowUser["USER_ID"];
                info.RoleId = rowUser["USER_ORG_ID"];
                info.UserName = rowUser["USER_NAME"].ToString();
                info.LogOnName = rowUser["USER_LOGIN_NAME"].ToString();
                info.Encoding = "gb2312";
            }
            DataSetUtil.ExecuteScalar(strSQL, Context, parameters);
        }

        private DataRow CheckUserLogOn(string pwd, int logonAttempts, UserInfo info)
        {
            if (HostTable.Rows.Count == 0)
            {
                throw new NoLogOnNameException();
            }

            DataRow user = HostTable.Rows[0];

            //用户已离职
            if (user["USER_OUT"].ToString() == "1")
            {
                throw new LogOnCreateException("USER_OUT", LoginResUtil.GetResourceString("UserFired"));
            }

            //登录次数超过3次，锁定该帐号
            if (logonAttempts >= LogOnParams.Current.MaxAttemptTimes)
            {
                this.ChangeUserState(user, false, info);
                throw new UserLockedException();
            }

            if (user["USER_ACTIVE"] != null)
            {
                string active = user["USER_ACTIVE"].ToString();
                if (string.IsNullOrEmpty(active) || active == "0")
                {
                    if (user["USER_UNLOCK_DATE"] == null || string.IsNullOrEmpty(user["USER_UNLOCK_DATE"].ToString()))
                    {
                        throw new UserLockedException();
                    }

                    DateTime now = DateTime.Now;
                    DateTime unlockDate = now;
                    if (DateTime.TryParse(user["USER_UNLOCK_DATE"].ToString(), out unlockDate))
                    {
                        if (unlockDate >= now)
                        {
                            throw new UserLockedException();
                        }
                        else
                        {
                            if (PasswdUtil.Decrypt(user["USER_LOGIN_PASSWD"].ToString(), user["USER_LOGIN_NAME"].ToString()) == pwd)
                            {
                                this.ChangeUserState(user, true, info);
                            }
                            else
                            {
                                throw new PasswordInvalidException();
                            }
                        }
                    }
                    else
                    {
                        throw new UserLockedException();
                    }
                }
                else if (active == "1")
                {
                    if (PasswdUtil.Decrypt(user["USER_LOGIN_PASSWD"].ToString(), user["USER_LOGIN_NAME"].ToString()) == pwd)
                    {
                        this.ChangeUserState(user, true, info);
                    }
                    else
                    {
                        throw new PasswordInvalidException();
                    }
                }
            }

            if (info.IsLogOn)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        public DataRow CheckUserLogOn(string logOnName, string pwd, int logOnAttempts, UserInfo info)
        {
            this.SelectWithParam("USER_LOGIN_NAME", logOnName);
            return this.CheckUserLogOn(pwd, logOnAttempts, info);
        }
        public DataRow CheckUserLogOn(string orgId, string logOnName, string pwd, int logOnAttempts, UserInfo info)
        {
            this.SelectWithParams(new string[] { "USER_ORG_ID", "USER_LOGIN_NAME" }, new object[] { orgId, logOnName });
            return this.CheckUserLogOn(pwd, logOnAttempts, info);
        }

        protected void SetBaseConstraints(PageStyle style)
        {
            base.SetConstraints(style);
        }
        protected override void SetConstraints(PageStyle style)
        {
            base.SetConstraints(style);
            this.Constraints.Add(new SingleValueConstraint("USER_LOGIN_NAME", this.GetDisplayName("USER_LOGIN_NAME"), XmlDataType.String));
            this.Constraints.Add(new MobileConstraint("USER_MOBILE", this.GetDisplayName("USER_MOBILE")));
            this.Constraints.Add(new EmailConstraint("USER_EMAIL", this.GetDisplayName("USER_EMAIL")));
            this.Constraints.Add(new SFZConstraint("USER_IDENT_NO", this.GetDisplayName("USER_IDENT_NO")));
            this.Constraints.Add(new PostCodeConstraint("USER_POSTAL", this.GetDisplayName("USER_POSTAL")));
        }

    }
}
