﻿using YJC.Toolkit.Data;
using System.Data;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(REG_NAME,Author = "fongsl", CreateDate = "2010-09-15", Description = "SYS_FUNCTION 表的数据访问对象")]
    internal class PartFuncResolver : TableResolver
    {
        internal const string REG_NAME = "PartFunc";
        private const string TABLENAME = "SYS_PART_FUNC";
        private const string KEYFIELDS = "PF_PART_ID, PF_FN_ID";
        private const string FIELDS = "PF_PART_ID, PF_FN_ID, PF_IS_FUNC";

        public PartFuncResolver(DbContext context, DataSet hostDataSet)
            : base(TABLENAME, KEYFIELDS, FIELDS, context, hostDataSet)
        {
        }
    }
}
