﻿using YJC.Toolkit.Data;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(REG_NAME, Author = "fangsl", CreateDate = "2010-09-15", Description = "UR_USERS_PART 表的数据访问对象")]
    internal class UsersPartResolver : Tk4TableResolver
    {
        public const string REG_NAME = "UsersPart";
        public const string DATAXML = "Users/UsersPart.xml";

        public UsersPartResolver(DbContext context, IDataSource source)
            : base(DATAXML, context, source)
        {
        }
    }
}
