﻿using System.Collections.Generic;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right
{
    internal class RoleProvider : IRoleProvider
    {
        private DbContextConfig fDbConfig;
        private List<IRole> fAllRoles;

        public RoleProvider(DbContextConfig dbConfig)
        {
            fDbConfig = dbConfig;
        }

        #region IRoleProvider 成员

        public void AddUserToRole(IRole role, params IUser[] users)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetUserPartTableResolver(context, ds))
            {
                foreach (IUser user in users)
                {
                    DataRow row = resolver.NewRow();
                    row.BeginEdit();
                    row["UP_USER_ID"] = user.Id;
                    row["UP_PART_ID"] = role.Id;
                    row.EndEdit();
                }
                resolver.SetCommands(AdapterCommand.Insert);
                resolver.UpdateDatabase();
            }
        }

        public void AddUsersToRoles(IDictionary<IRole, IEnumerable<IUser>> list)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetUserPartTableResolver(context, ds))
            {
                foreach (KeyValuePair<IRole, IEnumerable<IUser>> userList in list)
                {
                    foreach (IUser user in userList.Value)
                    {
                        DataRow row = resolver.NewRow();
                        row["UP_USER_ID"] = user.Id;
                        row["UP_PART_ID"] = userList.Key.Id;
                    }

                }
                if (list.Count > 0)
                {
                    resolver.SetCommands(AdapterCommand.Insert);
                    resolver.UpdateDatabase();
                }

            }
        }

        public IEnumerable<IRole> AllRoles
        {
            get
            {
                if (fAllRoles == null)
                {
                    fAllRoles = new List<IRole>();
                    setAllRoles();
                }
                return fAllRoles;
            }
        }

        public string ApplicationName
        {
            get
            {
                return string.Empty;
            }
        }

        public void CreateRole(IRole role)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetPartTableResolver(context, ds))
            {
                DataRow row = resolver.NewRow();
                row.BeginEdit();
                row["PART_ID"] = role.Id;
                row["PART_NAME"] = role.Name;
                row.EndEdit();
                resolver.SetCommands(AdapterCommand.Insert);
                resolver.UpdateDatabase();
            }
        }

        public bool DeleteRole(string roleCode, bool throwOnPopulatedRole)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetPartTableResolver(context, ds))
            {
                if (throwOnPopulatedRole)
                {
                    string sql = "SELECT COUNT(*) FROM UR_USERS WHERE USER_ID IN "
                        + "(SELECT UP_USER_ID FROM UR_USERS_PART WHERE UP_PART_ID = @UP_PART_ID )";
                    DbParameterList list = new DbParameterList();
                    list.Add("UP_PART_ID", XmlDataType.String, roleCode);
                    int count = DataSetUtil.ExecuteScalar(sql, context, list).Value<int>();
                    if (count > 0)
                    {
                        TkDebug.ThrowToolkitException(string.Format(ObjectUtil.SysCulture, "编号为{0}的权限被{1}个用户使用，无法删除",
                            roleCode, count), this);
                    }
                }
                DataRow row = resolver.TrySelectRowWithKeys(roleCode);
                if (row != null)
                {
                    resolver.Delete();
                    return true;
                }
                else
                    return false;
            }
        }

        public IRole GetRole(string roleCode)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetPartTableResolver(context, ds))
            {
                DataRow row = resolver.TrySelectRowWithKeys(roleCode);
                if (row != null)
                {
                    return new Role(row);
                }
                else
                    return null;
            }
        }

        public IEnumerable<IRole> GetRolesForUser(string logOnName)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetPartTableResolver(context, ds))
            {
                string tableName = resolver.TableName;
                DbParameterList list = new DbParameterList();
                list.Add("USER_LOGIN_NAME", XmlDataType.String, logOnName);
                string sql = string.Format(ObjectUtil.SysCulture, "WHERE PART_ID IN (SELECT DISTINCT "
                   + " UP_PART_ID FROM UR_USERS_PART WHERE UP_USER_ID IN (SELECT USER_ID FROM "
                   + " UR_USERS WHERE USER_LOGIN_NAME = {0} ) )", context.GetSqlParamName("USER_LOGIN_NAME"));
                resolver.Select(sql, list);
                foreach (DataRow row in ds.Tables[tableName].Rows)
                {
                    yield return new Role(row);
                }
            }
        }

        public IEnumerable<IUser> GetUsersInRole(string roleCode)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = UserProvider.GetUserTableResolver(context, ds))
            {
                UserProvider userProvider = new UserProvider(fDbConfig);
                string tableName = resolver.TableName;
                DbParameterList list = new DbParameterList();
                list.Add("UP_PART_ID", XmlDataType.String, roleCode);
                string sql = string.Format(ObjectUtil.SysCulture, @" USER_ID IN "
                    + " (SELECT UP_USER_ID FROM UR_USERS_PART WHERE  UP_PART_ID =  {0} )",
                    context.GetSqlParamName("UP_PART_ID"));
                resolver.Select(sql, list);
                foreach (DataRow row in ds.Tables[resolver.TableName].Rows)
                {
                    yield return new User(row, userProvider);
                }
            }
        }

        public bool IsUserInRole(string logOnName, string roleCode)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            {
                string sql = string.Format(ObjectUtil.SysCulture, @"SELECT COUNT(USERR_ID) FROM "
                    + " UR_USERS WHERE USER_LOGIN_NAME = {0} AND USERR_ID IN (SELECT UP_USER_ID FROM "
                    + " UR_USERS_PART WHERE UP_PART_ID = {1} )", context.GetSqlParamName("USER_LOGIN_NAME"),
                    context.GetSqlParamName("UP_PART_ID"));
                DbParameterList list = new DbParameterList();
                list.Add("USER_LOGIN_NAME", XmlDataType.String, logOnName);
                list.Add("UP_PART_ID", XmlDataType.String, roleCode);

                return DataSetUtil.ExecuteScalar(sql, context, list).Value<int>() > 0;
            }
        }

        public void RemoveUserToRole(IRole role, params IUser[] users)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetUserPartTableResolver(context, ds))
            {
                int count = users.Length;
                if (count > 0)
                {
                    string[] ids = new string[count];
                    for (int i = 0; i < count; i++)
                    {
                        ids[i] = users[i].Id;
                    }
                    resolver.SelectWithKeys(ids);
                    if (resolver.HostTable.Rows.Count > 0)
                    {
                        resolver.Delete();
                        resolver.UpdateDatabase();
                    }
                }

            }
        }

        public void RemoveUsersToRoles(IDictionary<IRole, IEnumerable<IUser>> list)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetUserPartTableResolver(context, ds))
            {
                foreach (KeyValuePair<IRole, IEnumerable<IUser>> userList in list)
                {
                    foreach (IUser user in userList.Value)
                    {
                        resolver.SelectWithKeys(userList.Key, user.Id);
                    }
                }
                if (resolver.HostTable.Rows.Count > 0)
                {
                    resolver.Delete();
                }
                resolver.UpdateDatabase();
            }
        }

        public bool RoleExists(string roleCode)
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver resolver = GetPartTableResolver(context, ds))
            {
                return resolver.TrySelectRowWithKeys(roleCode) != null;
            }
        }

        #endregion

        internal static TableResolver GetPartTableResolver(DbContext context, DataSet ds)
        {
            return new TableResolver(DataSetUtil.CreateTableScheme("Part.xml"), context, ds);
        }
        internal static TableResolver GetUserPartTableResolver(DbContext context, DataSet ds)
        {
            return new TableResolver(DataSetUtil.CreateTableScheme("UsersPart.xml"), context, ds);
        }

        private void setAllRoles()
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (DbContext context = fDbConfig.CreateDbContext())
            using (TableResolver fResolver = GetPartTableResolver(context, ds))
            {
                fResolver.Select();
                foreach (DataRow row in fResolver.HostTable.Rows)
                {
                    IRole role = new Role(row);
                    fAllRoles.Add(role);
                }
            }
        }
    }
}
