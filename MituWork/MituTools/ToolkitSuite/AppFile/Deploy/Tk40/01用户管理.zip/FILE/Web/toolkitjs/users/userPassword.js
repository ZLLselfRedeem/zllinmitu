﻿(function ($) {
    // 设定表单内容提交后的返回错误信息处理
    $('form').bind('AfterServerValidError', function () {
        $('input[name=USER_LOGIN_PASSWD]').val('').showInputValidStatus();
        $('input[name=USER_CONFIRM_PASSWD]').val('');
        //预留，不用可以删掉
    });
})(jQuery);
