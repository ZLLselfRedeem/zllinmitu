﻿using System;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(REG_NAME, Description = "表UR_USERS(UR_USERS)的数据访问层类，只能对登录者个人维护和查看",
        Author = "yax", CreateDate = "2010-09-15")]
    internal class UserInfoResolver : UserResolver
    {
        internal new const string REG_NAME = "UserInfo";

        public UserInfoResolver(DbContext context, IDataSource source)
            : base(context, source)
        {
            this.DetailSource.FillingUpdateTables += new EventHandler<FillingUpdateEventArgs>(DetailSource_FillingUpdateTables);
        }

        void DetailSource_FillingUpdateTables(object sender, FillingUpdateEventArgs e)
        {
            this.SelectWithKeys(GlobalVariable.UserId);
            if (!e.PageData.IsPost)
            {
                this.AddVirtualFields();
                //if (e.PageData.Style == PageStyle.Update)
                // ResolverUtil.GetConstraints(UpdateKind.Update, this);
            }
            e.Handled.SetHandled(this, true);
        }

    }
}
