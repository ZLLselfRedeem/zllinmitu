﻿using System.Data;
using YJC.Toolkit.Data;

namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// SYS_PART_FUNC 表的数据访问对象
    /// </summary>
    [Resolver(REG_NAME, Author = "fongsl", CreateDate = "2010-09-15", Description = "SYS_PART_FUNC 表的数据访问对象")]
    internal class PartFunctionResolver : TableResolver
    {
        internal const string REG_NAME = "PartFunc";
        private const string TABLENAME = "SYS_PART_FUNC";
        private const string KEYFIELDS = "PF_FN_ID,PF_PART_ID";
        private const string FIELDS = "PF_PART_ID, PF_FN_ID, PF_IS_FUNC";

        public PartFunctionResolver(DbContext context, DataSet hostDataSet)
            : base(TABLENAME, KEYFIELDS, FIELDS, context, hostDataSet)
        {
        }
    }
}
