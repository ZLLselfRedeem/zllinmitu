﻿using System.Globalization;
using System.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    [OutputRedirector, XmlInputReader, SourceWebPage(SupportLogOn = false)]
    [Source(REG_NAME, Author = "YJC", CreateDate = "2010-09-13",
        Description = "登录导向界面")]
    internal sealed class LogOnPageSource : ISource
    {
        internal const string REG_NAME = "LoginPage";

        #region ISource 成员

        WebOutputData ISource.DoAction(WebInputData input)
        {
            string source = string.Empty;
            switch (LogOnParams.Current.LoginMode)
            {
                case LogOnMode.User:
                    source = UserLogOnSource.REG_NAME;
                    break;
                case LogOnMode.UserOrg:
                    source = UserOrgSource.REG_NAME;
                    break;
                case LogOnMode.UserWithVerify:
                    source = UserVerifySource.REG_NAME;
                    break;
                case LogOnMode.UserOrgWithVerify:
                    source = UserOrgVerifySource.REG_NAME;
                    break;
                default:
                    TkDebug.ThrowToolkitException("不支持该LoginMode", this);
                    break;
            }
            string retUrl = input.QueryString["RetURL"];

            if (!string.IsNullOrEmpty(retUrl))
            {
                source = string.Format(CultureInfo.CurrentCulture, "{0}&RetURL={1}", source, HttpUtility.UrlEncode(retUrl));
            }
            string url = string.Format(ObjectUtil.SysCulture, "../Library/WebContentPage.tkx?Source={0}", source);

            return new WebOutputData(SourceOutputType.String, url);
        }

        #endregion
    }
}
