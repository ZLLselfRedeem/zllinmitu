﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace YJC.Toolkit.Right.Data
{
    public sealed class ChineseDateUtil
    {
        private static  string[] Sexagenary = 
        {
            "甲子","乙丑","丙寅","丁卯","戊辰","已巳","庚午","辛未","壬申","癸酉",                      
            
            "甲戌","乙亥","丙子","丁丑","戊寅","已卯","庚辰","辛巳","壬午","癸未",
            
            "甲申","乙酉","丙戌","丁亥","戊子","已丑","庚寅","辛卯","壬辰","癸巳",
            
            "甲午","乙未","丙申","丁酉","戊戌","已亥","庚子","辛丑","壬寅","癸卯",
           
            "甲辰","乙巳","丙午","丁未","戊申","已酉","庚戌","辛亥","壬子","癸丑",
            
            "甲寅","乙卯","丙辰","丁巳","戊午","已未","庚申","辛酉","壬戌","癸亥"
        };

        //农历日期的名称
        private static string[] CnDay =
        {
            "初一","初二","初三","初四","初五","初六","初七",
            "初八","初九","初十","十一","十二","十三","十四",
            "十五","十六","十七","十八","十九","二十","廿一",
            "廿二","廿三","廿四","廿五","廿六","廿七","廿八",
            "廿九","三十"
        };
        private ChineseDateUtil()
        { 
        }

        //农历的月的名称
        private static string[] MonthName = 
        {
            "正月","二月","三月","四月","五月","六月","七月","八月","九月","十月","冬月","腊月"
        };

        private static ChineseLunisolarCalendar cCalendar = new ChineseLunisolarCalendar();

        public  static string  GetChineseDateText(DateTime datatime)
        {
             int year = cCalendar.GetYear(datatime);
             int leapMonth = cCalendar.GetLeapMonth(year);
             int month = cCalendar.GetMonth(datatime);
             int day = cCalendar.GetDayOfMonth(datatime);

             bool isLeap = false;
             if( leapMonth > 0   && leapMonth <= month )
             {
                 if (leapMonth ==  month)
                     isLeap = true;
                 month -- ;
              }
             int sexage = cCalendar.GetSexagenaryYear(datatime);

             string result = string.Format(CultureInfo.CurrentCulture, "{0}年{3}{1}{2}", Sexagenary[sexage - 1], MonthName[month - 1], CnDay[day - 1], isLeap? "闰" : "");
             return result;
        }

       
    }
}
