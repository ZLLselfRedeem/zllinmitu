﻿using System.IO;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    internal sealed class LogOnPageMaker : BaseXsltPageMaker
    {
        public LogOnPageMaker()
            : base()
        {
            //HtmlFrame = "";

        }

        protected override bool ShowSource
        {
            get
            {
                bool showSource = PageData.QueryString[ToolkitConst.VIEW_TAG] == ToolkitConst.VIEW_VALUE;

                return showSource;
            }
        }

        protected override void SetXsltFile(IPageData pageData)
        {
            this.XsltFile = Path.Combine(AppSetting.Current.XmlPath, "bin/Login.xslt");
        }

        protected override string GetRedirectPage(ISource source, IPageData pageData, string key)
        {
            string retUrl = "";
            if (string.IsNullOrEmpty(pageData.QueryString["RetURL"]))
            {
                UserLogOnSource userLoginSource = source as UserLogOnSource;

                if (userLoginSource != null && userLoginSource.IsNewUser)
                {
                    retUrl = string.Format(ObjectUtil.SysCulture, "../Library/WebContentPage.{0}?Source=MainPage&Main=WebUpdateXmlPage.{0}?Source=Users/UserChgPasswd&ID=-1", pageData.PageExtension);
                }
                else
                {
                    retUrl = string.Format(ObjectUtil.SysCulture, "../Library/WebContentPage.{0}?Source=MainPage&Main=WebContentPage.{0}?Source=HomePage", pageData.PageExtension);
                }
            }
            else
            {
                retUrl = pageData.IsPost ? pageData.PostDataSet.Tables["OtherInfo"].Rows[0]["Save"].ToString()
                   : pageData.QueryString["RetURL"];
            }
            return retUrl;
        }
    }
}
