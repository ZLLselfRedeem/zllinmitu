﻿using System.Data;

namespace YJC.Toolkit.Right
{
    internal class Role : IRole
    {
        private string fRoleCode;
        private string fId;
        private string fName;

        public Role(DataRow row)
        {
            fId = row["PART_ID"].ToString();
            fName = row["PART_NAME"].ToString();
            fRoleCode = fId;
        }

        #region IRole 成员

        public string RoleCode
        {
            get
            {
                return fRoleCode;
            }
        }

        #endregion

        #region IEntity 成员

        public string Id
        {
            get
            {
                return fId;
            }
        }

        public string Name
        {
            get
            {
                return fName;
            }
        }

        #endregion
    }
}
