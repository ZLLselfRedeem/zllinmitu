﻿using System;
using System.Data;
using System.Globalization;
using System.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    [Source(REG_NAME, Author = "YJC", CreateDate = "2010-09-13",
        Description = "默认用户和密码的登录页面"),
    JsonInputReader, SourcePageMaker(typeof(LogOnPageMaker)),
    SourceWebPage(SupportLogOn = false)]
    internal class UserLogOnSource : BaseLogOnSource
    {
        internal const string REG_NAME = "UserLogin";

        public UserLogOnSource()
            : base()
        {
            Resolver = new UserResolver(Context, this);
        }

        protected UserResolver Resolver { get; private set; }

        public bool IsNewUser { get; set; }
        protected UserResolver UserResolverInst
        {
            get
            {
                return Resolver;
            }
        }

        protected override void CheckLogin(IPageData pageData, DataRow row, UserInfo info)
        {
            if (row["LAST_LOGIN_NAME"].ToString() != row["LOGIN_NAME"].ToString())
                LoginAttempts = 0;
            DataRow returnValue = Resolver.CheckUserLogOn(row["LOGIN_NAME"].ToString(),
                row["LOGIN_PASS"].ToString(), int.Parse(row["LOGIN_ATTEMPTS"].ToString(), CultureInfo.CurrentCulture), info);

            if (returnValue != null)
            {
                this.IsNewUser = returnValue["USER_LOGIN_DATE"] == null || string.IsNullOrEmpty(returnValue["USER_LOGIN_DATE"].ToString()) ? true : false;
            }

            HttpResponse response = GlobalVariable.Response;
            DateTime expires = DateTime.Now + new TimeSpan(30, 0, 0, 0);
            HttpCookie cookie = new HttpCookie("LoginName", row["LOGIN_NAME"].ToString());
            cookie.Expires = expires;
            response.Cookies.Set(cookie);
        }

        protected override void SetDefaultValue(IPageData pageData)
        {
            HttpCookie cookie = GlobalVariable.Request.Cookies["LoginName"];
            if (cookie != null)
                LoginRow["LOGIN_NAME"] = cookie.Value;
        }

    }
}
