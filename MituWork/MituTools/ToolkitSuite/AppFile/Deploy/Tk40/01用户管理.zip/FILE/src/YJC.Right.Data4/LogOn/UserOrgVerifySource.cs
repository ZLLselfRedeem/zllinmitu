﻿using System;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    [JsonInputReader, SourcePageMaker(typeof(LogOnPageMaker)), SourceWebPage(SupportLogOn = false)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-16",
        Description = "机构验证码登录")]
    internal class UserOrgVerifySource : UserOrgSource
    {
        internal new const string REG_NAME = "UserOrgVerify";
        private string[] newFileds;

        protected override string[] LoginTableFields
        {
            get
            {
                if (newFileds == null)
                {
                    int length = base.LoginTableFields.Length;

                    newFileds = new string[length + 1];
                    Array.Copy(base.LoginTableFields, 0, newFileds, 0, length);
                    newFileds[length] = "LOGIN_VERIFY";
                }
                return newFileds;
            }

        }

        protected override void CheckLogin(IPageData pageData, DataRow row, UserInfo info)
        {
            if (row["LOGIN_VERIFY"].ToString() != GlobalVariable.Session["VerifyKey"].ToString())
                throw new LogOnCreateException("LOGIN_VERIFY", LoginResUtil.GetResourceString("Verify"));
            base.CheckLogin(pageData, row, info);
        }

    }
}
