﻿using YJC.Toolkit.Data;
namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// SYS_FUNCTION 表的数据访问对象
    /// </summary>
    [Resolver(REG_NAME, Author = "fongsl", CreateDate = "2010-09-15", Description = "SYS_FUNCTION 表的数据访问对象")]
    internal class FunctionResolver : Tk4TableResolver, IDbTree
    {
        internal const string REG_NAME = "Function";
        public const string DATAXML = "Users/Function.xml";

        public FunctionResolver(DbContext context, IDataSource source)
            : base(DATAXML, context, source)
        {
            this.fTreeFields = new TreeFieldGroup(XmlDataType.String, "FN_ID", "FN_NAME", "FN_PARENT_ID", "FN_TREE_LAYER", "FN_IS_LEAF");
        }

        protected override void OnUpdatingRow(UpdatingEventArgs e)
        {
            base.OnUpdatingRow(e);
            switch (e.Status)
            {
                case UpdateKind.Delete:
                    break;
                case UpdateKind.Insert:
                    e.Row["FN_ID"] = this.Context.GetUniId(this.TableName);
                    break;
                case UpdateKind.Update:
                    break;
                default:
                    break;
            }
        }

        #region IDbTree 成员
        private TreeFieldGroup fTreeFields;

        public new string RootId
        {
            get
            {
                return "-1";
            }
        }

        public new TreeSearchType SearchType
        {
            get
            {
                return TreeSearchType.ParentId;
            }
        }

        public new TreeFieldGroup TreeFields
        {
            get
            {
                return this.fTreeFields;
            }
        }

        #endregion
    }
}
