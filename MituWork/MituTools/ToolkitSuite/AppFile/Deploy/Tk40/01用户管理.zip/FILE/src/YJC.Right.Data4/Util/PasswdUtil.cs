﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace YJC.Toolkit.Right.Data
{
    internal static class PasswdUtil
    {
        public static string Encrypt(string toEncrypt, string key)
        {
            if (string.IsNullOrEmpty(toEncrypt))
            {
                return string.Empty;
            }

            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

            TripleDESCryptoServiceProvider tdes = PasswdUtil.GetTripleDES(key);

            byte[] resultArray = PasswdUtil.CryptoTransform(tdes.CreateEncryptor(), toEncryptArray);

            tdes.Clear();

            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        public static string Decrypt(string cryptString, string key)
        {
            if (string.IsNullOrEmpty(cryptString))
            {
                return string.Empty;
            }

            byte[] toEncryptArray = Convert.FromBase64String(cryptString);

            TripleDESCryptoServiceProvider tdes = PasswdUtil.GetTripleDES(key);

            byte[] resultArray = PasswdUtil.CryptoTransform(tdes.CreateDecryptor(), toEncryptArray);
            tdes.Clear();

            return UTF8Encoding.UTF8.GetString(resultArray);
        }

        private static TripleDESCryptoServiceProvider GetTripleDES(string key)
        {
            MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();

            byte[] keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
            hashmd5.Clear();

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            return tdes;
        }

        private static byte[] CryptoTransform(ICryptoTransform cTransform, byte[] toEncryptArray)
        {
            return cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
        }
    }
}
