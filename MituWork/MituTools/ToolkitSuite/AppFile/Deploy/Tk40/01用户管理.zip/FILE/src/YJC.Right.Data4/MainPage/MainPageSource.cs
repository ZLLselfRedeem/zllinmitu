﻿using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    [XmlInputReader, XsltPageMaker("Bin/MainPage.xslt", FilePathPosition.Xml), SourceWebPage(SupportLogOn = true)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-15", Description = "登录后进去的系统主页面")]
    internal class MainPageSource : BaseCustomSource
    {
        internal const string REG_NAME = "MainPage";

        protected override void FillCustomTables(IPageData pageData)
        {
            base.FillCustomTables(pageData);
        }
        //private static string GetMainUrl(WebInputData input)
        //{
        //    string strURL = input.PageUrl.ToString();
        //    int queryPos = strURL.IndexOf("Main=", StringComparison.CurrentCulture);
        //    string strsource = string.Empty;

        //    if (queryPos != -1)
        //    {
        //        strsource = strURL.Substring(queryPos + 5);
        //    }

        //    return strsource;
        //}

        //#region ISource 成员

        //WebOutputData ISource.DoAction(WebInputData input)
        //{
        //    string strsource = GetMainUrl(input);
        //    string fmtStr = LoginResUtil.GetResourceString("DefaultHtml");

        //    string script = GlobalVariable.SessionGbl.AppRight.GetMenuScript(GlobalVariable.Info.UserId);
        //    string fcontent = string.Format(CultureInfo.CurrentCulture, fmtStr, script, strsource);
        //    return new WebOutputData(SourceOutputType.String, fcontent);
        //}
        //#endregion
    }
}
