﻿using System;
using System.Data;
using System.Text;
using System.Web;
using System.Xml;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Xml;

namespace YJC.Toolkit.Right.Data
{
    internal abstract class BaseLogOnSource : BaseCustomSource
    {
        private readonly string[] FIELDS = new string[] { "LOGIN_MODE", "LOGIN_NAME", "LOGIN_PASS", "LOGIN_ATTEMPTS" };
        private DataTable fLoginTable;
        private DataSet fErrorDataSet;

        protected override void FillCustomTables(IPageData pageData)
        {
            CreateLoginTable();
            if (pageData.IsPost)
            {
                ErrorObjectCollection errors = new ErrorObjectCollection();
                DataRow row = pageData.PostDataSet.Tables["LOGIN"].Rows[0];

                try
                {
                    CheckLogin(pageData, row, GlobalVariable.Info);
                    GlobalVariable.SessionGbl.AppRight.Initialize(GlobalVariable.Info);
                    //设置cookie
                    SetUserInfoCookie();
                }
                catch (LogOnException ex)
                {
                    DataSetUtil.CopyRow(row, LoginRow, LoginTableFields, LoginTableFields);
                    ++LoginAttempts;
                    if (ex is UserLockedException && LoginAttempts >= LogOnParams.Current.MaxAttemptTimes)
                        LoginAttempts = 0;
                    errors.Add(ex.ErrorObject);
                }
                fErrorDataSet = errors.CheckError();
                if (fErrorDataSet != null)
                {
                    DataTable attemptTable = DataSetUtil.CreateDataTable("LOGIN_ATTEMPT", "TIMES");

                    attemptTable.Rows.Add(LoginAttempts);
                    fErrorDataSet.Tables.Add(attemptTable);
                }
            }



            else
                SetDefaultValue(pageData);
        }

        private static void SetUserInfoCookie()
        {
            StringBuilder builder = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(builder);
            using (writer)
            {
                XmlUtil.WriteXml(writer, GlobalVariable.Info, "UserInfo");
            }

            DateTime now = DateTime.Now;
            DateTime endTime = now.Date.AddDays(1.0);
            DateTime exTime = now.AddHours(10.0);
            if (exTime > endTime)
            {
                exTime = endTime;
            }
            HttpResponse response = GlobalVariable.Response;
            //DateTime expires = DateTime.Now + new TimeSpan(30, 0, 0, 0);
            string userInfoStr = PasswdUtil.Encrypt(builder.ToString(), GlobalVariable.Info.LogOnName);
            HttpCookie cookie = new HttpCookie("UserInfo", userInfoStr);
            cookie.Expires = exTime;
            response.Cookies.Set(cookie);

        }

        protected override WebOutputData DoAction(WebInputData input)
        {
            if (!input.IsPost)
            {
                input.UrlInfo.AddToDataSet(this, DataSet);
            }

            return base.DoAction(input);
        }

        protected DataRow LoginRow { get; private set; }

        public int LoginAttempts
        {
            get
            {
                return int.Parse(LoginRow["LOGIN_ATTEMPTS"].ToString(), ObjectUtil.SysCulture);
            }
            set
            {
                LoginRow["LOGIN_ATTEMPTS"] = value;
            }
        }

        protected virtual string[] LoginTableFields
        {
            get
            {
                return FIELDS;
            }
        }

        private void CreateLoginTable()
        {
            fLoginTable = DataSetUtil.CreateDataTable("LOGIN", LoginTableFields);
            DataSet.Tables.Add(fLoginTable);
            LoginRow = fLoginTable.NewRow();
            LoginRow.BeginEdit();
            LoginRow["LOGIN_MODE"] = LogOnParams.Current.LoginMode;
            LoginRow["LOGIN_ATTEMPTS"] = 0;
            LoginRow.EndEdit();
            fLoginTable.Rows.Add(LoginRow);
        }

        protected virtual void SetDefaultValue(IPageData pageData)
        {
        }

        protected abstract void CheckLogin(IPageData pageData, DataRow row, UserInfo info);

        protected override WebOutputData CreateOutputData(WebInputData input)
        {
            if (input.IsPost)
            {
                if (fErrorDataSet == null)
                {
                    return new WebOutputData(SourceOutputType.String, "0");
                }
                else
                {
                    return new WebOutputData(SourceOutputType.XmlReader, new XmlDataSetReader(fErrorDataSet));
                    // return new WebOutputData(SourceOutputType.String, fErrorDataSet.GetXml());
                }
            }
            else
            {
                return base.CreateOutputData(input);
            }
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            if (disposing)
            {
                if (fErrorDataSet != null)
                {
                    fErrorDataSet.Dispose();
                }
            }
        }
    }
}
