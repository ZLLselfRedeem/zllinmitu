﻿namespace YJC.Toolkit.Right.Data
{
    /// <summary>
    /// 登陆模式
    /// </summary>
    public enum LogOnMode
    {
        /// <summary>
        /// 
        /// </summary>
        User,

        /// <summary>
        /// 
        /// </summary>
        UserWithVerify,

        /// <summary>
        /// 
        /// </summary>
        UserOrg,

        /// <summary>
        /// 
        /// </summary>
        UserOrgWithVerify
    }
}
