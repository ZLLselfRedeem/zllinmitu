﻿using System;
using System.Collections.Generic;
using System.Data;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    [JsonPageMaker, XmlInputReader]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-13",
        Description = "账户集合操作")]
    internal class GatherSource : HandleBaseSource
    {
        internal const string REG_NAME = "GatherSource";
        internal const string CMD = "CMD";
        internal const string USERNAME = "USERNAME";
        internal const string USERPASSWORD = "USERPASSWORD";
        internal const string USERIDS = "USERIDS";
        internal const string DEL = "DEL";
        internal const string NEW = "NEW";
        internal const string LOGIN = "LOGIN";
        private string fCmd;
        private string fUserName;
        private string fPassword = "";

        private string fUserIds;//支持批量删除

        private int fCurrentGatherId;//获取当前账号集合Id

        protected override void CheckInParm(IPageData pageData)
        {
            fCmd = pageData.QueryString[CMD];
            TkDebug.AssertArgumentNullOrEmpty(fCmd, "未指定操作", this);
            SetLoginUserGather();
            switch (fCmd)
            {
                case DEL:
                    fUserIds = pageData.QueryString[USERIDS];
                    TkDebug.AssertNotNullOrEmpty(fUserIds, "未选中任何账户", this);
                    break;
                case NEW:
                    CommonCheck(pageData);
                    break;
                case LOGIN:
                    CommonCheck(pageData);
                    break;
                default:
                    break;
            }
            // throw new System.NotImplementedException();
        }

        protected override void HandleWork(IPageData pageData)
        {
            fCmd = pageData.QueryString[CMD];
            switch (fCmd)
            {
                case DEL:
                    WorkDelUpdateUser();
                    //批量删除
                    break;
                case NEW:
                    WorkNewUpdateUser();
                    //新增
                    break;
                case LOGIN:
                    //登录
                    WorkLoginUpdateUser();
                    break;
                default:
                    break;
            }
        }

        private void SetLoginUserGather()
        {
            //用参数查询
            object userId = GlobalVariable.Info.UserId;
            //IParamBuilder userPar = SqlParamBuilder.CreateEqualSql(Context, "USER_ID", XmlDataType.String, userId);
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (TableResolver userResolver = new TableResolver("UR_USERS", Context, ds))
            {
                DataRow userRow = userResolver.TrySelectRowWithKeys(userId);
                if (userRow != null)
                {
                    fCurrentGatherId = userRow["USER_GATHER"].Value<int>();
                }
                //fCurrentGatherId = DataSetUtil.ExecuteScalar(" SELECT USER_GATHER FROM UR_USERS ", Context, userPar).Value<int>();
                if (fCurrentGatherId == 0)
                {
                    //不可能是解绑操作
                    TkDebug.Assert(fCmd != "DEL", string.Format("当前登录用户{0}没有绑定任何帐号", GlobalVariable.Info.UserName), this);
                    //通过账户集合表新增加集合信息

                    using (TableResolver gatherTableResolver = new TableResolver("UR_GATHER", Context, ds))
                    {
                        DataRow dr = gatherTableResolver.NewRow();
                        dr.BeginEdit();
                        dr["UG_ID"] = fCurrentGatherId = Context.GetUniId("UR_GATHER").Value<int>();
                        dr["UG_CREATE_DATE"] = dr["UG_UPDATE_DATE"] = DateTime.Now;
                        dr["UG_CREATE_ID"] = dr["UG_UPDATE_ID"] = userId;
                        dr.EndEdit();
                        gatherTableResolver.SetCommands(AdapterCommand.Insert);
                        userRow["USER_GATHER"] = fCurrentGatherId;
                        userResolver.SetCommands(AdapterCommand.Update);
                        UpdateUtil.UpdateTableResolvers(null, userResolver, gatherTableResolver);
                    }
                }
            }
        }

        private void CommonCheck(IPageData pageData)
        {
            //判断用户名和密码是否都在
            //判断用户是否在
            //判断用户是否在绑定内
            fUserName = pageData.QueryString[USERNAME];
            TkDebug.Assert(fUserName != null, "账户不能为空", this);
            string loginName = GlobalVariable.Info.LogOnName;
            TkDebug.Assert(fUserName != loginName, string.Format("账户{0}不能和当前登录账户{1}相同", fUserName, loginName), this);
            fPassword = pageData.QueryString[USERPASSWORD];
            fPassword = fPassword ?? "";
            fPassword = fPassword.Trim();
        }

        private void WorkDelUpdateUser()
        {
            List<IParamBuilder> builders = new List<IParamBuilder>();
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (TableResolver userTableResolver = new TableResolver("UR_USERS", Context, ds))
            {
                string loginId = GlobalVariable.Info.UserId.ToString();
                string[] ids = fUserIds.Split(',');
                foreach (string id in ids)
                {
                    TkDebug.Assert(id != loginId, "删除用户不能为当前用户", this);
                    DataRow dr = userTableResolver.TrySelectRowWithKeys(id);
                    TkDebug.AssertNotNull(dr, string.Format("没有找到当前{0}删除账户", id), this);
                    TkDebug.Assert(dr["USER_GATHER"].Value<int>() == fCurrentGatherId, "账户集合未绑定", this);
                    dr.BeginEdit();
                    dr["USER_GATHER"] = DBNull.Value;
                    dr.EndEdit();
                    IParamBuilder builder = SqlParamBuilder.CreateSingleSql(Context, "USER_ID", XmlDataType.String, "<>", id);
                    builders.Add(builder);
                }
                string sql = "SELECT COUNT(*) FROM UR_USERS";
                IParamBuilder currentBuilder = SqlParamBuilder.CreateEqualSql(Context, "USER_GATHER", XmlDataType.String, fCurrentGatherId);
                builders.Add(currentBuilder);
                IParamBuilder buildersList = SqlParamBuilder.CreateParamBuilder(builders.ToArray());
                // currentBuilder =
                int count = DataSetUtil.ExecuteScalar(sql, Context, buildersList).Value<int>();
                if (count == 1)
                {
                    DataRow currentRow = userTableResolver.TrySelectRowWithKeys(GlobalVariable.Info.UserId.ToString());
                    currentRow["USER_GATHER"] = DBNull.Value;
                }
                userTableResolver.SetCommands(AdapterCommand.Update);
                userTableResolver.UpdateDatabase();
            }
        }

        private void WorkNewUpdateUser()
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (TableResolver userTableResolver = new TableResolver("UR_USERS", Context, ds))
            {
                IParamBuilder namePar = SqlParamBuilder.CreateEqualSql(Context, "USER_LOGIN_NAME", XmlDataType.String, fUserName);
                DataRow dr = userTableResolver.TrySelectRow(namePar);
                TkDebug.AssertNotNull(dr, string.Format("帐号{0}不存在", fUserName), this);
                TkDebug.Assert(PasswdUtil.Decrypt(dr["USER_LOGIN_PASSWD"].ToString(), dr["USER_LOGIN_NAME"].ToString()) == fPassword, "密码不正确", this);
                TkDebug.Assert(dr["USER_GATHER"].Value<int>() == 0, string.Format("账户{0} 已被绑定", fUserName), this);
                dr.BeginEdit();
                dr["USER_GATHER"] = fCurrentGatherId;
                dr.EndEdit();
                userTableResolver.SetCommands(AdapterCommand.Update);
                userTableResolver.UpdateDatabase();
            }
        }

        private void WorkLoginUpdateUser()
        {
            using (DataSet ds = new DataSet() { Locale = ObjectUtil.SysCulture })
            using (TableResolver userTableResolver = new TableResolver("UR_USERS", Context, ds))
            {
                IParamBuilder namePar = SqlParamBuilder.CreateEqualSql(Context, "USER_LOGIN_NAME", XmlDataType.String, fUserName);
                DataRow dr = userTableResolver.TrySelectRow(namePar);
                TkDebug.AssertNotNull(dr, string.Format("账户{0}不存在", fUserName), this);
                //TkDebug.Assert(PasswdUtil.Decrypt(dr["USER_LOGIN_PASSWD"].ToString(), dr["USER_LOGIN_NAME"].ToString()) == fPassword, "密码不正确", this);
                TkDebug.AssertNotNull(dr["USER_ACTIVE"], string.Format("账户{0}非有效账户", fUserName), this);
                TkDebug.Assert(dr["USER_OUT"].ToString() != "1", string.Format("账户{0}已离职", fUserName), this);
                TkDebug.Assert(dr["USER_GATHER"].Value<int>() > 0, string.Format("账户{0}未被绑定", fUserName), this);
                TkDebug.Assert(dr["USER_GATHER"].Value<int>() == fCurrentGatherId, string.Format("账户{0}未被当前集合绑定", fUserName), this);
                ChangeUserState(dr, true, GlobalVariable.Info);
            }
            GlobalVariable.SessionGbl.AppRight.Initialize(GlobalVariable.Info);
        }

        private void ChangeUserState(DataRow rowUser, bool isValid, UserInfo info)
        {
            string strSQL = string.Empty;

            DbParameterList parameters = new DbParameterList();

            if (!isValid)
            {
                strSQL = "UPDATE UR_USERS SET USER_ACTIVE = 0, USER_UNLOCK_DATE = {0} WHERE USER_ID ={1} ";
                strSQL = string.Format(strSQL, Context.GetSqlParamName("USER_UNLOCK_DATE"), Context.GetSqlParamName("USER_ID"));
                parameters.Add("USER_UNLOCK_DATE", XmlDataType.DateTime, DateTime.Now.AddDays(1));
                parameters.Add("USER_ID", XmlDataType.String, rowUser["USER_ID"]);
            }
            else
            {
                strSQL = "UPDATE UR_USERS SET USER_ACTIVE = 1, USER_LOGIN_DATE = {0}, USER_UNLOCK_DATE = NULL WHERE USER_ID = {1} ";
                strSQL = string.Format(strSQL, Context.GetSqlParamName("USER_LOGIN_DATE"), Context.GetSqlParamName("USER_ID"));
                parameters.Add("USER_LOGIN_DATE", XmlDataType.DateTime, DateTime.Now);
                parameters.Add("USER_ID", XmlDataType.String, rowUser["USER_ID"]);

                info.IsLogOn = true;
                info.UserId = rowUser["USER_ID"];
                info.RoleId = rowUser["USER_ORG_ID"];
                info.UserName = rowUser["USER_NAME"].ToString();
                info.LogOnName = rowUser["USER_LOGIN_NAME"].ToString();
                info.Encoding = "gb2312";
            }
            DataSetUtil.ExecuteScalar(strSQL, Context, parameters);
        }

    }
}
