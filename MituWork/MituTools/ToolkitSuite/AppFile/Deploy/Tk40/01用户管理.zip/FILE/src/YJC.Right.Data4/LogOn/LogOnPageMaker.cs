﻿using System.IO;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;

namespace YJC.Toolkit.Right.Data
{
    internal class LogOnPageMaker : TkBasePageMaker
    {
        private SimpleXsltPageMaker fPageMaker;
        private const string LOGIN_XSLT = "bin/Login.xslt";

        public LogOnPageMaker()
        {
            fPageMaker = new SimpleXsltPageMaker(Path.Combine(AppSetting.Current.XmlPath, LOGIN_XSLT));
            base.Add((source, pageData, outputData) => !pageData.IsPost, this.fPageMaker);
            base.Add((source, pageData, outputData) => pageData.IsPost &&
                (outputData.OutputType == SourceOutputType.XmlReader), JsonPageMaker.PAGE_MAKER);
            base.Add((source, pageData, outputData) => (pageData.IsPost &&
                outputData.OutputType == SourceOutputType.String),
                new UrlPageMaker());
        }


    }
}
