﻿using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(REG_NAME, Description = "表UR_USERS(UR_USERS)的数据访问层类，只能对登录者个人维护Password",
        Author = "yax", CreateDate = "2010-09-15")]
    internal class UserInfoPasswdResolver : UserInfoResolver
    {
        internal new const string REG_NAME = "UserInfoPasswd";

        public UserInfoPasswdResolver(DbContext context, IDataSource source)
            : base(context, source)
        {
        }

        protected override void SetConstraints(PageStyle style)
        {
            base.SetConstraints(style);
            string passwd = HostTable.Rows[0]["USER_LOGIN_PASSWD"].ToString();
            this.Constraints.Add(new PasswordConstraint("USER_LOGIN_PASSWD", passwd));
        }

    }
}
