﻿using System.Data;
using System.Globalization;
using YJC.Toolkit.Constraint;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    internal class PasswordConstraint : BaseConstraint
    {
        //用户真实密码
        private string fRealPwd;

        public PasswordConstraint(string fieldValue, string realPwd) :
            base(fieldValue, "密码校验")
        {
            this.IsFirstCheck = true;
            this.fRealPwd = realPwd;
        }

        protected override ErrorObject CheckError(SqlSelector selector, WebInputData inputData, string value, int position)
        {
            DataTable postTable = inputData.PostDataSet.Tables["UR_USERS"];
            DataRow row = postTable.Rows[0];

            string loginName = row["USER_LOGIN_NAME"].ToString();

            int len = 6;// PasswdUtil.GetPasswdLengthConfig();

            if (postTable.Columns.Contains("USER_OLD_PASSWD"))
            {
                if (row["USER_OLD_PASSWD"].ToString() != PasswdUtil.Decrypt(fRealPwd, loginName))
                {
                    return new ErrorObject("UR_USERS", "USER_LOGIN_PASSWD", "用户旧密码输入错误.", position);
                }
            }
            if (row["USER_LOGIN_PASSWD"].ToString().Length < len)
            {
                return new ErrorObject("UR_USERS", "USER_LOGIN_PASSWD"
                    , string.Format(CultureInfo.CurrentCulture, "用户密码必须是{0}位以上的数字、字母和特殊字符，字母区分大小写.", len)
                    , position);
            }
            if (row["USER_LOGIN_PASSWD"].ToString() != row["USER_CONFIRM_PASSWD"].ToString())
            {
                return new ErrorObject("UR_USERS", "USER_LOGIN_PASSWD", "密码输入不一致.", position);
            }

            row["USER_LOGIN_PASSWD"] = PasswdUtil.Encrypt(row["USER_LOGIN_PASSWD"].ToString(), loginName);

            return null;
        }

        public override string GetJavaScript(string version)
        {
            return string.Empty;
        }
    }
}
