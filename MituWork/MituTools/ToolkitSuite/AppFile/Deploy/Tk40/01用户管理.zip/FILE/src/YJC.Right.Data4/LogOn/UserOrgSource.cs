﻿using System;
using System.Data;
using System.Globalization;
using System.Web;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Web;
namespace YJC.Toolkit.Right.Data
{
    [JsonInputReader, SourcePageMaker(typeof(LogOnPageMaker)), SourceWebPage(SupportLogOn = false)]
    [Source(REG_NAME, Author = "ZYK", CreateDate = "2010-09-13",
        Description = "机构登录")]
    internal class UserOrgSource : UserLogOnSource
    {
        internal new const string REG_NAME = "UserOrg";
        private TableSelector fOrgInfo;

        public UserOrgSource()
            : base()
        {
            fOrgInfo = new TableSelector("SYS_ORGANIZATION", "ORG_ID", "ORG_ID, ORG_CODE, ORG_NAME, ORG_ACTIVE", Context, this.DataSet);
        }

        public string OrgCode
        {
            get
            {
                return LoginRow["ORG_CODE"].ToString();
            }
            set
            {
                LoginRow["ORG_CODE"] = value;
            }
        }

        protected override string[] LoginTableFields
        {
            get
            {
                return new string[] { "LOGIN_MODE", "LOGIN_NAME", "LOGIN_PASS", "LOGIN_ATTEMPTS", "ORG_CODE" };
            }
        }

        protected override void CheckLogin(IPageData pageData, DataRow row, UserInfo info)
        {
            try
            {
                fOrgInfo.SelectWithParam("ORG_CODE", row["ORG_CODE"]);
            }
            catch
            {
                //throw new ConnectionFailedException();
            }

            if (fOrgInfo.HostTable.Rows.Count == 0)
                throw new LogOnCreateException("ORG_CODE", LoginResUtil.GetResourceString("NoOrganization"));

            DataRow orgRow = DataSet.Tables["SYS_ORGANIZATION"].Rows[0];

            if (!string.IsNullOrEmpty(orgRow["ORG_ACTIVE"].ToString()) || orgRow["ORG_ACTIVE"].ToString() == "0")
                throw new LogOnCreateException("ORG_ACTIVE", LoginResUtil.GetResourceString("OrganizationInactive"));

            if (row["LAST_LOGIN_NAME"].ToString() != row["LOGIN_NAME"].ToString())
                row["LOGIN_ATTEMPTS"] = 0;

            DataRow returnValue = UserResolverInst.CheckUserLogOn(orgRow["ORG_ID"].ToString(), row["LOGIN_NAME"].ToString(),
                row["LOGIN_PASS"].ToString(), int.Parse(row["LOGIN_ATTEMPTS"].ToString(), CultureInfo.CurrentCulture), info);
            if (returnValue != null)
            {
                this.IsNewUser = returnValue["USER_LOGIN_DATE"] == null || string.IsNullOrEmpty(returnValue["USER_LOGIN_DATE"].ToString()) ? true : false;
            }

            HttpResponse response = GlobalVariable.Response;
            DateTime expires = DateTime.Now + new TimeSpan(30, 0, 0, 0);
            HttpCookie cookie = new HttpCookie("OrgCode", row["ORG_CODE"].ToString());
            cookie.Expires = expires;
            response.Cookies.Set(cookie);
            //base.CheckLogin(pageData, row, info);
        }

        protected override void SetDefaultValue(IPageData pageData)
        {
            base.SetDefaultValue(pageData);
            HttpCookie cookie = GlobalVariable.Request.Cookies["OrgCode"];
            if (cookie != null)
                OrgCode = cookie.Value;
        }

    }
}
