﻿using System;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace YJC.Toolkit.Right.Data
{
    [Resolver(REG_NAME, Description = "表UR_USERS(UR_USERS)的数据访问层类，增加对Password的校验",
        Author = "yax", CreateDate = "2010-09-15")]
    internal class UserPasswdResolver : UserResolver
    {
        internal new const string REG_NAME = "UserPasswd";

        public UserPasswdResolver(DbContext context, IDataSource source)
            : base(context, source)
        {
            this.UpdateSource.FillingUpdateTables += new EventHandler<FillingUpdateEventArgs>(UpdateSource_FillingUpdateTables);
        }

        void UpdateSource_FillingUpdateTables(object sender, FillingUpdateEventArgs e)
        {
            //throw new NotImplementedException();
        }

        protected override void SetConstraints(PageStyle style)
        {
            SetBaseConstraints(style);
            string passwd = HostTable.Rows[0]["USER_LOGIN_PASSWD"].ToString();
            this.Constraints.Add(new PasswordConstraint("USER_LOGIN_PASSWD", passwd));
        }

        protected override void OnUpdatingRow(UpdatingEventArgs e)
        {
            base.OnUpdatingRow(e);

            switch (e.Status)
            {
                case UpdateKind.Delete:
                    break;
                case UpdateKind.Insert:
                    break;
                case UpdateKind.Update:
                    break;
                default:
                    break;
            }
        }

    }
}
