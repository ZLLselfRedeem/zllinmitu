﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;
using YJC.Toolkit.Utility;

namespace YJC.Toolkit.Right
{
    internal class SimpleFunctionRight : EmptyFunctionRight, IDisposable
    {

        private Hashtable fFunction;
        private Hashtable fShortName;

        private DataSet dataSet;
        private bool fAdmin;
        private const string FuncSQL = "SELECT DISTINCT FN_ID, FN_SHORT_NAME, FN_NAME, FN_URL, FN_PARENT_ID, FN_TREE_LAYER, FN_IS_LEAF, " +
            "({3} / 3 - 1) AS FN_LAYER FROM {1}, {0} WHERE FN_ID = PF_FN_ID AND (PF_PART_ID IN (SELECT UP_PART_ID FROM UR_USERS_PART " +
            "WHERE UP_USER_ID = '{2}')) ORDER BY  FN_LAYER, FN_TREE_LAYER, FN_ID";

        private const string SubFuncSQL = "SELECT DISTINCT SF_ID, SF_FN_ID, SF_NAME, SF_NAME_ID,SYS_FUNCTION.FN_SHORT_NAME,SYS_PART_SUB_FUNC.PSF_PART_ID,UR_USERS_PART.UP_USER_ID ,UR_USERS_PART.UP_USER_ID FROM SYS_SUB_FUNC LEFT JOIN SYS_PART_SUB_FUNC ON SYS_SUB_FUNC.SF_ID = SYS_PART_SUB_FUNC.PSF_SF_ID LEFT JOIN SYS_FUNCTION ON SYS_FUNCTION.FN_ID = SYS_SUB_FUNC.SF_FN_ID LEFT JOIN UR_USERS_PART ON UR_USERS_PART.UP_PART_ID = SYS_PART_SUB_FUNC.PSF_PART_ID WHERE UR_USERS_PART.UP_USER_ID = '{0}' ORDER BY SF_FN_ID, SF_NAME_ID";

        private Dictionary<string, DataRow> subFunList;

        public SimpleFunctionRight()
        {
        }

        public override void Initialize(UserInfo data)
        {
            if (data != null)
            {
                fFunction = new Hashtable();
                fShortName = new Hashtable();
                setDataSet(data.UserId);
            }
        }

        public override bool IsAdmin()
        {

            return fAdmin;
        }

        public override bool IsFunction(object key)
        {
            SetFunction(dataSet);
            object id = fShortName[key];

            if (id == null)
            {
                return false;
            }
            object item = fFunction[id];

            if (item == null)
            {
                return false;
            }
            return ((FunctionRightItem)item).IsLeaf;
        }

        public override bool IsSubFunction(object subKey, object key)
        {

            return subFunList.ContainsKey(string.Format(ObjectUtil.SysCulture, "{0}_{1}", key, subKey));
            //SetFunction(dataSet);
            //object id = fShortName[key];

            //if (id == null)
            //{
            //    return false;
            //}
            //object item = fFunction[id];

            //if (item == null)
            //{
            //    return false;
            //}
            //FunctionRightItem fItem = (FunctionRightItem)item;

            //if (!fItem.IsLeaf)
            //{
            //    return false;
            //}
            //return fItem.SubFunc.Contains(subKey.ToString());
        }

        public override DataSet GetMenuObject(object userId)
        {
            return dataSet;
        }

        private void setDataSet(object userId)
        {
            dataSet = new DataSet();
            dataSet.Locale = CultureInfo.CurrentCulture;
            DbContext context = GlobalVariable.DefaultDbContextConfig.CreateDbContext();

            string funcSql = string.Format(CultureInfo.CurrentCulture, FuncSQL, "SYS_FUNCTION", "SYS_PART_FUNC", userId,
                context.ContextConfig.SqlProvider.GetFunction("LENGTH", "SYS_FUNCTION.FN_TREE_LAYER"));
            TableSelector selector = new TableSelector("UR_USERS", context, dataSet);
            using (selector)
            {
                DataRow userRow = selector.SelectRowWithParam("USER_ID", userId);
                fAdmin = userRow["USER_ADMIN"].ToString() == "1";
            }



            SqlSelector sqls = new SqlSelector(context, dataSet);
            using (sqls)
            {
                sqls.Select("SYS_FUNCTION", funcSql);

                string subFuncSql = string.Format(CultureInfo.CurrentCulture, SubFuncSQL, userId);
                sqls.Select("SYS_SUB_FUNC", subFuncSql);
            }
            SetSubFunction(dataSet);

        }

        private void SetSubFunction(DataSet dataset)
        {
            subFunList = new Dictionary<string, DataRow>();
            if (dataset.Tables["SYS_SUB_FUNC"] != null && dataset.Tables["SYS_SUB_FUNC"].Rows.Count > 0)
            {
                foreach (DataRow row in dataset.Tables["SYS_SUB_FUNC"].Rows)
                {
                    subFunList.Add(string.Format(ObjectUtil.SysCulture, "{0}_{1}", row["FN_SHORT_NAME"], row["SF_NAME_ID"]), row);
                }
            }
        }

        private void SetFunction(DataSet dataset)
        {
            fFunction.Clear();
            fShortName.Clear();

            DataTable table = dataset.Tables["SYS_FUNCTION"];

            if (table != null)
            {
                foreach (DataRow row in table.Rows)
                {
                    string key = row["FN_ID"].ToString();
                    bool isLeaf = (row["FN_IS_LEAF"].ToString() == "1") ? true : false;
                    FunctionRightItem item = new FunctionRightItem(key);

                    item.IsLeaf = isLeaf;
                    fFunction.Add(key, item);
                    if (row["FN_SHORT_NAME"].ToString().Length > 0 && !(fShortName.Contains(row["FN_SHORT_NAME"])))
                    {
                        fShortName.Add(row["FN_SHORT_NAME"], key);
                    }
                }
            }
        }

        #region IDisposable 成员

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                //ApplyData = null;
                if (dataSet != null)
                {
                    dataSet.Dispose();
                }
            }
        }

    }
}
