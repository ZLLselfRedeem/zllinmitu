$(function () {
    $(".btn-search").unbind('click').click(function () {
        if (!$('#WI_NAME').val())
            window.location.reload();
        else {
            var elm = $(".tk-datasearch form");
            elm.trigger('BeforeFormDataCheck');
            var guid = elm.attr('dataGuid') || '';
            var url = elm.attr('action');
            var dataSetId = elm.attr('dataSet');
            var data = Toolkit.dataset.getData(dataSetId);
            if (data) {
                data.OtherInfo = [{ DataSet: guid, Save: ""}];
                elm.trigger('BeforeFormSubmit');

                Toolkit.data.loadHTML($('.tk-datalist'), 'post', url, data);
                Toolkit.ui.DataTableExecute($('#dataListFrame'));
            }
        }
        return false;
    });

    $(".define_href").unbind().click(function () {
        var elem = $(this);
        var wdName = elem.attr("wdName");
        var stepName = elem.attr("stepName");
        var imgElem = $("#IMG_" + wdName + "_" + stepName);
        var container = $("#STEP_TD_" + wdName + "_" + stepName);
        if (!container.css("display") || container.css("display") == "none") {
            if (!container.html()) {
                var rand = Math.random();
                var url = "WebModuleContentXmlPage.tkx?Source=workflow/WFDefine&DefName=" + wdName + "&style=list&StepId=" + stepName + "&rand=" + rand;
                Toolkit.data.loadHTML(container, 'get', url);
            }
            container.css("display", "block");
            imgElem.attr("src", "../toolkitimages/v1/collapse_detail.gif");
        }
        else {
            container.css("display", "none");
            imgElem.attr("src", "../toolkitimages/v1/expand_detail.gif");
        }
    });
});           