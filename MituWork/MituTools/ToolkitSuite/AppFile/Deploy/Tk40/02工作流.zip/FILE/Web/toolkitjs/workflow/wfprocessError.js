function nonUIOperateError(plugName, flowId) {
    var nonUIOperation = "WebContentPage.tkx?Source=WFOperationProcess";
    var tempUrl = nonUIOperation + "&PlugIn=" + plugName + "&WFID=" + flowId;
    $.ajax({ type: 'get', dataType: 'text', url: tempUrl, cache: false, data: {}, success: function (ahtml) {
        var contentStr = ahtml;
        if (contentStr.substring(0, 2) == "OK") {
            var idxBegin = contentStr.indexOf(";Alert;");
            var idxEnd = contentStr.lastIndexOf(";Alert;");
            var url;
            if (idxBegin < idxEnd && idxBegin > 0) {
                alert(contentStr.substring(idxBegin + 7, idxEnd));
                url = contentStr.substring(idxEnd + 7, contentStr.length);
            }
            else {
                url = contentStr.substring(2, contentStr.length);
                document.clear();
                document.location.href = url;
            }
        }
        // if (!ValidateXml(contentStr))
        var elem = $(".tk-page");
        elem.html(contentStr);
    }, error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Test');
    }
    });
}