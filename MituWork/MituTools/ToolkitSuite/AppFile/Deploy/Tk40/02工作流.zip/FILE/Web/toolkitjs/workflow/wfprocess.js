function loadContentPage(title, contentXml, flowId,isEnd) {
    $(".tk-dataform").before('<div id="DV_title"><b>' + title + '</b></div>');
    var contentUrl = 'WebModuleContentXmlPage.tkx?Source=' + contentXml + '&path=workflow&WFID=' + flowId;
    if (isEnd) {
        contentUrl = contentUrl + "&HIS=s";
    }
    $.ajax({ type: 'get', url: contentUrl, cache: false, data: {}, success: function (html) {
        $(".tk-dataform").before(html);
        Toolkit.ui.DataListExecute($(".tk-datalist"));
        Toolkit.ui.DataDetailExecute($(".tk-datadetail"));
        $('.tk-datalist').bindToolkitUI('DataListLoad');
//        Toolkit.ui.DataTableExecute($('.tk-dataList'));
        $('.tk-datalist .list-table').css("maxHeight", '200px');
        $(".TitleSet").each(function () { if ($(this).text().trim() != "") $(this).attr("title", $(this).text()); });
    }
    });
    $(".btn-common").unbind();
}
function nonUIOperate(plugName, flowId) {
    var nonUIOperation = "WebContentPage.tkx?Source=WFOperationProcess";
    var tempUrl = nonUIOperation + "&PlugIn=" + plugName + "&WFID=" + flowId;
    $.ajax({ type: 'get', dataType: 'text', url: tempUrl, cache: false, data: {}, success: function (ahtml) {
        var contentStr = ahtml;
        if (contentStr.substring(0, 2) == "OK") {
            var idxBegin = contentStr.indexOf(";Alert;");
            var idxEnd = contentStr.lastIndexOf(";Alert;");
            var url;
            if (idxBegin < idxEnd && idxBegin > 0) {
                alert(contentStr.substring(idxBegin + 7, idxEnd));
                url = contentStr.substring(idxEnd + 7, contentStr.length);
            }
            else {
                url = contentStr.substring(2, contentStr.length);
                document.clear();
                document.location.href = url;
            }
        }
        // if (!ValidateXml(contentStr))
        var elem = $(".tk-page");
        elem.html(contentStr);
    }, error: function (XMLHttpRequest, textStatus, errorThrown) {
        alert('Test');
    }
    });
}