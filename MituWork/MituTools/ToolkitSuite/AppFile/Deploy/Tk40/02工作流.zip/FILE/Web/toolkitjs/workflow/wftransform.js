﻿$(
function () {
    SelectType();
    var _turn_typeObj = $("select");
    if (_turn_typeObj.length > 0) {
        //alert(_turn_typeObj.html());
        //var seletTT = _turn_typeObj[0];
        _turn_typeObj.change(function () { SelectType(); });
        //alert(_turn_typeObj.change);
        //alert(seletTT);
    }
}
)
function SelectType() {
  //  alert(ddl);
    var _f = $("select").val();
    var _wd = $("input[name='WT_WD_NAME']").parent().parent().parent().parent();
    var _wi = $("input[name='WT_WI_ID']").parent().parent().parent().parent(); ;
    switch (_f) {
     case "1":
         _wd.hide();
         _wi.hide();
         break;
     case "2":
         _wd.show();
         _wi.hide();
         break;
     case "3":
         _wi.show();
         _wd.hide();
         break;
     default:
         break;
 }
} 




