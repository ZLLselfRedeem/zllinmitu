function fHoliday(y,m,d) {
	var dayOfWeek=new Date(y,m-1,d).getDay();
	//if (dayOfWeek==0||dayOfWeek==6) return ["Weekend is not selectable!",null,null,"red"];

	var rE=fGetEvent(y,m,d), r=null;
	
	return rE?rE:r;	// favor events over holidays
}


