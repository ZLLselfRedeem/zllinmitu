// --------------------------------
// Toolkit.util.dialog
// --------------------------------
(function($) {
	if (!$ || !window.Toolkit) return;
	// ----------------------------
	Toolkit.namespace('Toolkit.util');
	// ----------------------------
	if (Toolkit.util.dialog) return;
	// ----------------------------
	var utilId = 'util-dialog';
	var utilText = Toolkit.lang.get(utilId) || {
		'close':		'关闭',
		'closeTips':	'关闭浮层',
		'loading':		'正在加载中……',
		'loadingError':	'加载失败',
		'confirm':		'确认',
		'cancel':		'取消',
		'alert':		'提醒'
	};
	// ----------------------------
	Toolkit.util.dialog = {};
	Toolkit.util.dialog.id = utilId;
	Toolkit.util.dialog.status = false;
	Toolkit.util.dialog.resizeStatus = false;
	// 弹窗类型
	Toolkit.util.dialog.mode = '';
	Toolkit.util.dialog.dialogType = 'common';
	// 关闭弹出窗时回调方法
	Toolkit.util.dialog.closeCallback = null;
	// 打开弹出窗
	Toolkit.util.dialog.init = function() {
		if ($('#'+this.id).size()==0) {
			var pdhtml = '<div id="'+this.id+'">';
			pdhtml += '<div class="pdb-bgt"><span></span></div>';
			pdhtml += '<div class="pdb-bgm"></div>';
			pdhtml += '<div class="pdb-main mod-frame">';
			pdhtml += 	'<div class="pdb-title mod-header"><h4></h4><span class="close" onclick="Toolkit.util.dialog.close();" title="{closeTips}">{close}</span></div>';
			pdhtml +=   '<div class="pdb-setting mod-setting"></div>';
			pdhtml += 	'<div class="pdb-content"><div class="pdb-contentframe"></div></div>';
			pdhtml += 	'<div class="pdb-bottom mod-footer"></div>';
			pdhtml += '</div>';
			pdhtml += '<div class="pdb-bgb"><span></span></div>';
			pdhtml += '</div>';
			$('body').append(pdhtml.substitute(utilText));
		}
	};
	Toolkit.util.dialog.open = function(options) {
		if (this.monopolize) return;
		if (this.dialogType=='mini') {
			options.op = 0.01;
			options.title = '';
		}
		if (!options.noOverlayer) {
			Toolkit.util.overlayer.showLayer(options.op, options.overbg);
		}
		this.init();
		if (options.noCloseBtn)	{
			$('#'+this.id+' .pdb-title span.close').remove();
		}
		if (options.title) {
			$('#'+this.id+' .pdb-title').show();
			this.setTitle(options.title);
		} else {
			$('#'+this.id+' .pdb-title').hide();
		}
		if (options.setting) {
			$('#'+this.id+' .pdb-setting').html(options.setting).show();
		} else {
			$('#'+this.id+' .pdb-setting').hide();
		}
		if (options.bottom) {
			$('#'+this.id+' .pdb-bottom').show();
			this.setBottom(options.bottom);
		} else {
			$('#'+this.id+' .pdb-bottom').hide();
		}
		this.mode = options.mode||'text';
		var width = parseInt(options.width || 400, 10);
		var height = parseInt(options.height || 300, 10);
		var _this = this;
		switch(this.mode) {
			case 'ajax':
				$('#'+this.id+' .pdb-contentframe').ajaxStart(function() {
					var loading_html = '<p class="txt-loading-32" style="margin-top:{height}px;">&nbsp;</p>'.substitute({height:(height-32)/2});
					$(this).html(options.content.loading||loading_html);
					_this.setAutoHeight();
				});
				$.ajax({
					type:options.content.type||'get',
					url:options.content.url,
					data:options.content.param||'',
					error:function() {
						_this.setContent(options.content.error||'<div class="p20"><p class="txt-error">{loadingError}</p></div>'.substitute(utilText));
						_this.setAutoHeight();
					},
					success:function(html) {
						_this.setContent(html);
					//	_this.setAutoHeight();
						if (options.ajaxComplete) {
							var elm = $('#'+_this.id+' .pdb-contentframe');
							options.ajaxComplete(elm);
						}
					}
				});
				break;
			case 'text':
				this.setContent(options.content);
				break;
			case 'id':
				this.setContent('');
				$('#'+options.id).appendTo('#'+this.id+' .pdb-contentframe');
				$('#'+options.id).show();
				this.lastContentId = options.id;
				break;
			case 'iframe':
				var iframeId = 'iframe_'+ (new Date()).getTime();
				this.setContent('<iframe id="'+ iframeId +'" src="about:blank" width="100%" height="'+height+'px" scrolling="auto" frameborder="0" marginheight="0" marginwidth="0"></iframe>');
				$('#'+iframeId).attr('src', options.url);
				break;
		}
		var height_2 = height + ((options.title)?26:0) + ((options.setting)?30:0) + ((options.bottom)?45:0);
		$('#'+this.id+' .pdb-bgm,#'+this.id+' .pdb-main').css('height',height_2+'px');
		$('#'+this.id+' .pdb-main').css('width', width+'px');
		$('#'+this.id+' .pdb-content').css('height',height+'px');
		$('#'+this.id+' .pdb-content').css('overflow', (options.mode=='iframe')?'hidden':'auto');
		$('#'+this.id).css('width',width+20+'px').show();
		if (options.callback) options.callback();
		if (options.closeFunction) this.closeCallback = options.closeFunction;
		this.options = options;
		this.status = true;
		this.resizeStatus = true;
		this.resize();
	};
	// 调整弹出窗大小
	Toolkit.util.dialog.resize = function() {
		if (this.status && this.resizeStatus) {
			var _left = ($(window).width() - $('#'+this.id).width())/2;
			var _top = (this.options.top) ? this.options.top : ($(window).height() - $('#'+this.id).height())/2;
			$('#'+this.id).css({
				left: $(document).scrollLeft() + Math.max(_left,20) +'px',
				top: $(document).scrollTop() + Math.max(_top,20) +'px'
			});
			if ($.browser.msie && parseFloat($.browser.version)<7) $('#'+this.id).bindToolkitUI('HideOverElements', 'select,object');
		}
	};
	// 关闭弹出窗
	Toolkit.util.dialog.close = function(effect) {
		if (this.monopolize) return;
		if (!this.status) return;
		switch(effect) {
			case 'fade':
				$('#'+this.id).fadeOut();
				break;
			case 'slide':
				$('#'+this.id).slideUp();
			default:
				$('#'+this.id).hide();
		}
		Toolkit.util.overlayer.hideLayer();		
		this.status = false;
		this.mode = '';
		if (this.lastContentId) {
			$('body').append($('#'+this.lastContentId));
			$('#'+this.lastContentId).hide();
			this.lastContentId = null;
		}
		if ($.browser.msie && parseFloat($.browser.version)<7) $('#'+this.id).bindToolkitUI('ShowOverElements', 'select,object');
		if ($.isFunction(this.closeCallback)) {
			this.closeCallback();
			this.closeCallback = null;
		}
	};
	// 更换弹出窗标题
	Toolkit.util.dialog.setTitle = function(html) {
		$('#'+this.id+' .pdb-title h4').html(html);
	};
	Toolkit.util.dialog.setStyle = function(options) {
		if (options.titlecolor) $('#'+this.id+' .pdb-title').css('color',options.titlecolor);
		if (options.bgcolor) $('#'+this.id+' .pdb-title').css('background-color',options.bgcolor);
		if (options.bordercolor) $('#'+this.id+' .pdb-main').css('border-color',options.bordercolor);
	};
	// 更换弹出窗内容
	Toolkit.util.dialog.setContent = function(html) {
		$('#'+this.id+' .pdb-contentframe').html(html);
	};
	// 更换弹出窗底部内容 { html, noteHtml, actionHtml, actionBtnText, cancelBtnText, callback }
	Toolkit.util.dialog.setBottom = function(options) {
		if (!options) return;
		if (options.html) {
			$('#'+this.id+' .pdb-bottom').html(options.html);
		} else {
			var bottomhtml = '<p class="pdb-bottom-action">';
			bottomhtml += 	'<a class="btn btn-action"><em>{confirm}</em></a>';
			bottomhtml += 	'<a class="btn btn-cancel" onclick="Toolkit.util.dialog.close();"><em>{cancel}</em></a>';
			bottomhtml += '</p>';
			bottomhtml += '<p class="pdb-bottom-text"></p>';
			$('#'+this.id+' .pdb-bottom').html(bottomhtml.substitute(utilText));
			if (options.noteHtml) $('#'+this.id+' .pdb-bottom .pdb-bottom-text').html(options.noteHtml);
			if (options.actionHTML) {
				$('#'+this.id+' .pdb-bottom .pdb-bottom-action').html(options.actionHTML);
			} else {
				if (options.actionBtnText) $('#'+this.id+' .pdb-bottom .btn-action em').html(options.actionBtnText);
				if (options.cancelBtnText) $('#'+this.id+' .pdb-bottom .btn-cancel em').html(options.cancelBtnText);
			}
		}
		if (options.callback) {
			$('#'+this.id+' .pdb-bottom .btn-action').click(function() { options.callback(); });
		} else {
			$('#'+this.id+' .pdb-bottom .btn-action').click(function() { Toolkit.util.dialog.close(); });
		}
		if (options.cancel) {
			$('#'+this.id+' .pdb-bottom .btn-cancel').click(function() { options.cancel(); });
		}
	};
	// 重设弹层高度
	Toolkit.util.dialog.setHeight = function(height) {
		var _height = $('#'+this.id+' .pdb-content').height();
		var _height2 = $('#'+this.id+' .pdb-main').height();
		$('#'+this.id+' .pdb-bgm,#'+this.id+' .pdb-main').css('height',(height-_height+_height2)+'px');
		$('#'+this.id+' .pdb-content').css('height',height+'px');
		$('#'+this.id+' .pdb-content iframe').attr('height', height);
		this.resize();
	};
	Toolkit.util.dialog.setAutoHeight = function() {
		this.setHeight($('.pdb-contentframe').height());
	};
	// 显示加载进度条
	Toolkit.util.dialog.showLoading = function(params) {
		params.mode = 'text';
		params.width = 350;
		params.height = 100;
		params.content = '<p class="txt-loading-32" style="margin-top:'+ (params.height-56)/2 +'px;">'+ (params.loadingText || utilText.loading) +'</p>';
		if (this.dialogType=='mini') {
			params.height = 36;
			params.content = '<p class="msg-info tac"><span class="dib ico-l-loading">'+ (params.loadingText || utilText.loading) +'</span></p>';
		}
		this.open(params);
		return false;
	};
	// 显示弹出窗内容
	Toolkit.util.dialog.show = function(params) {
		params.mode = 'id';
		this.open(params);
		this.setAutoHeight();
		return false;
	};
	// 打开弹出窗页面
	Toolkit.util.dialog.pop = function(params) {
		if (this.dialogType=='mini') {
			this.alert('不支持此方法');
			return false;
		}
		params.mode = 'iframe';
		this.open(params);
		return false;
	};
	// 打开Ajax页面
	Toolkit.util.dialog.ajax = function(params) {
		params.mode = 'ajax';
		params.content = {url:params.url};
		this.open(params);
		return false;
	};
	// 打开提醒框
	Toolkit.util.dialog.alert = function(params) {
		if (typeof(params)=='string') params = { message: params };
		params.close = utilText.close;
		if (!params.type) params.type = 'alert';
		var param = { mode:'text', title:params.title||utilText.alert, content:'<div class="msg-{type} f14">{message}</div><div class="tac pb20"><a class="btn btn-cancel" onclick="Toolkit.util.dialog.close();"><em>{close}</em></a></div>'.substitute(params), width:params.width||350, height:100, top:params.top, closeFunction:params.callback };
		if (this.dialogType=='mini') {
			param.content = '<div class="msg-info"><b class="i16 i16-close fr pointer" onclick="Toolkit.util.dialog.close();" title="{close}"></b><b class="i16 i16-{type} fl mr5"></b><span>{message}</span>'.substitute(params);
		}
		this.open(param);
		this.setAutoHeight();
		return false;
	};
	// 打开确认框
	Toolkit.util.dialog.confirm = function(params) {
		if (typeof(params)=='string') params = { message: params };
		var content = '<div class="msg-confirm f14">{message}</div>'.substitute(params);
		var callback = function() {
			Toolkit.util.dialog.close();
			if (params.callback && $.isFunction(params.callback)) params.callback();
		};
		this.open({ mode:'text', title:params.title||utilText.alert, content:content, bottom:{callback:callback,cancel:params.cancel}, width:params.width||350, height:60, top:params.top });
		this.setAutoHeight();
		return false;
	};
	// 自适应调整弹出窗位置
	$(window).resize(function() {
		Toolkit.util.dialog.resize();
	});
	// ----------------------------
	Toolkit.debug('dialog.js', '初始化成功');
})(jQuery);