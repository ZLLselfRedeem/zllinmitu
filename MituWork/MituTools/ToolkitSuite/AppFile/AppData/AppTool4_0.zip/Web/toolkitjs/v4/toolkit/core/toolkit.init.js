// --------------------------------
// Toolkit init
// --------------------------------
(function($) {
	if (!$ || !window.Toolkit) return;
	// ----------------------------
	Toolkit.load.add('suggest', { 
		js: 'toolkit/ui/suggest.js', 
		css: 'toolkit/ui/suggest.css'
	});
	Toolkit.load.add('util.dialog', {
		js: 'toolkit/util/dialog.js',
		css: 'toolkit/util/dialog.css'
	});
	Toolkit.load.add('lhgcalendar', {
		js: 'lhgcalendar/lhgcalendar.min.js'
	});
	Toolkit.load.add('xheditor', {
		js: 'xheditor/xheditor-1.1.7-zh-cn.min.js'
	});
	Toolkit.load.add('swfobject', { 
		js: 'uploadify/swfobject.js' 
	});
	Toolkit.load.add('uploadify', {
		js: 'uploadify/jquery.uploadify.v2.1.4.min.js',
		swf: 'uploadify/uploadify.swf',
		uploadBtn: 'uploadify/upload.png',
		cancelBtn: 'uploadify/cancel.png',
		requires: 'swfobject'
	});
	Toolkit.load.add('dropmenu', { 
		js: 'lib/jquery.dropmenu-1.1.4.js'
	});
	Toolkit.load.add('treeview', {
		js: 'treeview/jquery.treeview.js',
		css: 'treeview/jquery.treeview.css'
	});
	Toolkit.load.add('jqueryui', {
		js: 'lib/jquery-ui-1.8.16.custom.min.js'
	});
	Toolkit.load.add('firebug', {
		js: document.location.protocol +'//getfirebug.com/firebug-lite.js'
	});
	// ----------------------------
	Toolkit.load('util.dialog');
	// ----------------------------
	$(document).ready(function() {
		// ------------------------
		Toolkit.page.init();
		// ------------------------
	});
})(jQuery);