function showPreview(anchorControl, imgControl,imgUrl, isView)
{ 
   anchorControl.href = imgUrl;
    if (!isView)
        return;
    resize.img = new Image();
    resize.img.src = imgUrl;
    resize.imgControl = imgControl;
    if (resize.timeId)
        clearTimeout(resize.timeId);
    resize.timeId = setTimeout("resize()",300);   
}

function resize()
{
    var imgControl = resize.imgControl;
    var img = resize.img;
    var maxValue = 250;
    imgControl.src = img.src;
    var w = img.width;
    var h = img.height;
    if (w > h & w > maxValue)
        imgControl.style.width = maxValue + "px";
    else if (h > w & h > maxValue)
        imgControl.style.width = maxValue + "px";
   else
        imgControl.style.width = imgControl.style.height = "";
    imgControl.style.display = "block"; 
    resize.img = null;  
    resize.imgControl = null;
}

function hidePreview(imgControl, isView)
{
    if (!isView)
        return;
    try
    {
        imgControl.src = null;
        imgControl.style.display = 'none';
    }
    catch(e) {}
}

function clearSWFUpload(uploadField,pathField,sizeField,typeField,fieldDivValue)
{
    uploadField.value = "";
    sizeField.value = "";
    typeField.value = "";
    pathField.value = "";
    fieldDivValue.innerHTML = "";
}

function GetFileExt(obj)
{
	var str = obj;
	if(str.indexOf(".")<1 && str.indexOf(".") == 0)
	{
		str = str.replace(/[.]/g, ";*.");
		str = str.substr(1);
	}
	return str;
}
function createSWFUpload(uploadField, uploadFieldName, sessionId, fileExt, maxSize, pathField, sizeField, typeField,fieldDivValue, uploadDeleteField, previewImagePathField){
        var oldFileExt = fileExt;
        fileExt = GetFileExt(fileExt);
		 if(fileExt == "" || fileExt.lastIndexOf("]",0)>0)
		    fileExt = "*.*";

		 if(maxSize == "")
		    maxSize = "1000 MB";	
		    
		 try
		 {
		    if(maxSize != "1000 MB")
		        maxSize = Number(maxSize).toString()+" B";
		 }
		 catch(e)
		 {
		    maxSize = "1000 MB";	
		 }
     new SWFUpload({
		// Backend Settings
		upload_url: "../Library/WebInitPage.tkx?Source=UploadPage",
        post_params : {
            "ASPSESSID" : sessionId,
            "Ext" : oldFileExt
        },

		// File Upload Settings
		file_size_limit : maxSize,
		file_types : fileExt,
		file_types_description : oldFileExt,
		file_upload_limit : 0,    // Zero means unlimited

		// Event Handler Settings - these functions as defined in Handlers.js
		//  The handlers are not part of SWFUpload but are part of my website and control how
		//  my website reacts to the SWFUpload events.
		swfupload_preload_handler : preLoad,
		swfupload_load_failed_handler : loadFailed,
		file_queue_error_handler : fileQueueError,
		file_dialog_complete_handler : fileDialogComplete,
		upload_progress_handler : uploadProgress,
		upload_error_handler : uploadError,
		upload_success_handler : uploadSuccess,
		upload_complete_handler : uploadComplete,
		//OnUploadedEvent : OnUploaded1,
		// Button settings
		button_image_url: "../toolkitimages/upload/XPButtonUploadText_61x22.png",
		button_width: "61",
		button_height: "22",
		button_placeholder_id : uploadFieldName + "Button",
		button_width: 100,
		button_height: 22,
		// Flash Settings
		flash_url : "../toolkitjs/upload/swfupload.swf",	// Relative to this file
		flash9_url : "../toolkitjs/upload/swfupload_FP9.swf",	// Relative to this file

		custom_settings : {
			upload_target : uploadFieldName + "Progress",
			fileField : uploadField,
			pathField : pathField,
			sizeField : sizeField,
			typeField : typeField,
			fieldDivValue : fieldDivValue,
			/* update by zhoujj 2010-05-18*/
			uploadFieldName : uploadFieldName,
			deleteField : uploadDeleteField,
			previewImagePathField : previewImagePathField
			/*update by zhoujj 2010-05-18 end*/
		},

		// Debug Settings
		debug: false
	});
	
}

function preLoad() {
	if (!this.support.loading) {
		alert("����Ҫ��װFlash Player 9.028�汾�����ϵ�SWFUpload.");
		return false;
	}
}
function loadFailed() {
	alert("��Ҫ��װSWFUpload.");
}
function fileQueueError(file, error, message)
{
    if(error == "-120")
        alert("�ϴ����ļ�����Ϊ��");
    else if(error == "-130")
        alert("�ϴ����ļ����Ͳ���ȷ");
    else if(error == "-110")
        alert("�ϴ����ļ���С���������ƣ��ϴ��ļ������ֵΪ��"+this.settings.file_size_limit.toString());
    else if(error == "-100")
        alert("�ϴ����ļ������������ƣ��ϴ��ļ����Ϊ��"+this.settings.file_upload_limit.toString());
}
function fileDialogComplete(numFilesSelected, numFilesQueued, numFilesInQueue) {
	try {
		if (numFilesQueued > 0) {
			this.startUpload();
		}
	} catch (ex) {
		this.debug(ex);
	}
}
function uploadProgress(file, bytesLoaded) {

	try {
		var percent = Math.ceil((bytesLoaded / file.size) * 100);

		var progress = new FileProgress(file,  this.customSettings.upload_target);
		progress.setProgress(percent);
		if (percent === 100) {
			progress.toggleCancel(false, this);
		} else {
			progress.setStatus("�����ϴ��� "+percent.toString()+"%...");
			progress.toggleCancel(true, this);
		}
	} catch (ex) {
		this.debug(ex);
	}
}

function uploadSuccess(file, serverData) {
	try {
	    var xmlDom = getXmlDoc();
	    xmlDom.loadXML(serverData);
	    var shortpath = xmlDom.selectSingleNode("/Toolkit/ServerPath").text;
	    var lastindexpath = shortpath.lastIndexOf("Upload/");
	    if(lastindexpath>0)
	        shortpath = "../"+shortpath.substr(lastindexpath);
	    shortpath = shortpath.replace("\\","/");    
	    var errorNode = xmlDom.selectSingleNode("/Toolkit/Error");
	    if (errorNode == null)
        {
            serverData = serverData.toString().substr(3,serverData.toString().length);
            this.customSettings.fileField.value = xmlDom.selectSingleNode("/Toolkit/FileName").text;
            this.customSettings.sizeField.value = xmlDom.selectSingleNode("/Toolkit/FileSize").text;
            this.customSettings.typeField.value = xmlDom.selectSingleNode("/Toolkit/FileType").text;
            this.customSettings.pathField.value = shortpath;
            this.customSettings.deleteField.style.display = "inline";
            this.customSettings.previewImagePathField.value = shortpath;
            /*�������ID����ʾ�ϴ���·�������������ȥ��ʾ���ͼƬ update by zhoujj 2010-05-18
            var showDivID = "Show_"+this.customSettings.uploadFieldName;

	        showDiv = document.getElementById(showDivID);
                //var strData = "<img src=\""+shortpath+"\" alt=\"\" large-src=\""+shortpath+"\" pic-link=\"/\"  border=\"0\" width=\"100\"/>";
                 showDiv.innerHTML =" <a href=\"####\"  large-src=\""+shortpath+"\" pic-link=\"/\" onmouseover='showPreview(event);' onmouseout='hidePreview(event);'>"+ shortpath+"</a>";
           �������ID����ʾ�ϴ���·�������������ȥ��ʾ���ͼƬ update by zhoujj 2010-05-18 end*/
        }
        else
        {
            alert(errorNode.text);
        }
	} catch (ex) {
		this.debug(ex);
	}
}

function uploadComplete(file) {
	try {
		/*  I want the next upload to continue automatically so I'll call startUpload here */
		if (this.getStats().files_queued > 0) {
			this.startUpload();
		} else {
			var progress = new FileProgress(file,  this.customSettings.upload_target);
			progress.setComplete();
			progress.setStatus("�ϴ����.");
			progress.toggleCancel(false); 
			//alert(this.settings["OnUploadedEvent"]);
			if(this.settings["OnUploadedEvent"] != undefined)
				this.queueEvent("OnUploadedEvent", file);
			if(this.customSettings.fieldDivValue != undefined)
				this.customSettings.fieldDivValue.innerHTML = file.name;//+ts;
		}
		
	} catch (ex) {
		this.debug(ex);
	}
}

function OnUploaded1(file) {
	try {
		alert(file.name);
	} catch (ex) {
		this.debug(ex);
	}
}

function uploadError(file, errorCode, message) {
	var progress;
	try {	
		switch (errorCode) {
		case SWFUpload.UPLOAD_ERROR.HTTP_ERROR:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(false);
				alert("HTTP ���������ϴ�.");
			}
			catch (ex2) {
				this.debug(ex2);
			}		
			break;	
		case SWFUpload.UPLOAD_ERROR.MISSING_UPLOAD_URL:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(false);
				alert("�ϴ����ļ�·������ȷ�������ϴ�.");
			}
			catch (ex2) {
				this.debug(ex2);
			}		
			break;
		case SWFUpload.UPLOAD_ERROR.IO_ERROR:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(false);
				alert("������ (IO) ������ϴ��ļ���С����"+this.settings.file_size_limit.toString()+"�������ϴ�.");		
			}
			catch (ex2) {
				this.debug(ex2);
			}			
			break;
		case SWFUpload.UPLOAD_ERROR.SECURITY_ERROR:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(false);
				alert("��ȫ���������ϴ�.");
			}
			catch (ex2) {
				this.debug(ex2);
			}		
			break;			
		case SWFUpload.UPLOAD_ERROR.UPLOAD_LIMIT_EXCEEDED:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(false);
				alert("�ļ������������ƣ������ϴ�.");
			}
			catch (ex2) {
				this.debug(ex2);
			}		
			break;	
		case SWFUpload.UPLOAD_ERROR.UPLOAD_FAILED:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(false);
				alert("�ļ��ϴ�ʧ�ܣ������ϴ�.");
			}
			catch (ex2) {
				this.debug(ex2);
			}		
			break;	
		//case SWFUpload.UPLOAD_ERROR.SPECIFIED_FILE_ID_NOT_FOUND:7
		//	break;	
		case SWFUpload.UPLOAD_ERROR.FILE_VALIDATION_FAILED:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(false);
				alert("�����ļ�ʧ�ܣ������ϴ�.");
			}
			catch (ex2) {
				this.debug(ex2);
			}
			break;				
		case SWFUpload.UPLOAD_ERROR.FILE_CANCELLED:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("ȡ���ϴ�");
				progress.toggleCancel(false);
			}
			catch (ex1) {
				this.debug(ex1);
			}
			break;
		case SWFUpload.UPLOAD_ERROR.UPLOAD_STOPPED:
			try {
				progress = new FileProgress(file,  this.customSettings.upload_target);
				progress.setCancelled();
				progress.setStatus("�ϴ���ֹ");
				progress.toggleCancel(true);
			}
			catch (ex2) {
				this.debug(ex2);
			}
		default:
			alert(message);
			break;
		}

	} catch (ex3) {
		this.debug(ex3);
	}

}

function fadeIn(element, opacity) {
	var reduceOpacityBy = 10;
	var rate = 30;	// 15 fps


	if (opacity < 100) {
		opacity += reduceOpacityBy;
		if (opacity > 100) {opacity = 100;}
        if(element.id!="")
        {
		    if (element.filters) {
			    try {
				    element.filters.item("DXImageTransform.Microsoft.Alpha").opacity = opacity;
			    } catch (e) {
				    // If it is not set initially, the browser will throw an error.  This will set it if it is not set yet.
				    element.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=' + opacity + ')';
			    }
		    } else {
			    element.style.opacity = opacity / 100;
		    }
		}
	}

	if (opacity < 100) {
		setTimeout(function () {
			fadeIn(element, opacity);
		}, rate);
	}
}



/* ******************************************
 *	FileProgress Object
 *	Control object for displaying file info
 * ****************************************** */

function FileProgress(file, targetID) {
	this.fileProgressID = "divFileProgress";

	this.fileProgressWrapper = document.getElementById(this.fileProgressID);
	if (!this.fileProgressWrapper) {
		this.fileProgressWrapper = document.createElement("div");
		this.fileProgressWrapper.className = "progressWrapper";
		this.fileProgressWrapper.id = this.fileProgressID;

		this.fileProgressElement = document.createElement("div");
		this.fileProgressElement.className = "progressContainer";

		var progressCancel = document.createElement("a");
		progressCancel.className = "progressCancel";
		progressCancel.href = "#";
		progressCancel.style.visibility = "hidden";
		progressCancel.appendChild(document.createTextNode(" "));

		var progressText = document.createElement("div");
		progressText.className = "progressName";
		progressText.appendChild(document.createTextNode(file.name));

		var progressBar = document.createElement("div");
		progressBar.className = "progressBarInProgress";

		var progressStatus = document.createElement("div");
		progressStatus.className = "progressBarStatus";
		progressStatus.innerHTML = "&nbsp;";

		this.fileProgressElement.appendChild(progressCancel);
		this.fileProgressElement.appendChild(progressText);
		this.fileProgressElement.appendChild(progressStatus);
		this.fileProgressElement.appendChild(progressBar);

		this.fileProgressWrapper.appendChild(this.fileProgressElement);

		document.getElementById(targetID).appendChild(this.fileProgressWrapper);
		fadeIn(this.fileProgressWrapper, 0);

	} else {
		this.fileProgressElement = this.fileProgressWrapper.firstChild;
		this.fileProgressElement.childNodes[1].firstChild.nodeValue = file.name;
	}

	this.height = this.fileProgressWrapper.offsetHeight;

}
FileProgress.prototype.setProgress = function (percentage) {
	this.fileProgressElement.className = "progressContainer green";
	this.fileProgressElement.childNodes[3].className = "progressBarInProgress";
	this.fileProgressElement.childNodes[3].style.width = percentage + "%";
};
FileProgress.prototype.setComplete = function () {
	this.fileProgressElement.className = "progressContainer blue";
	this.fileProgressElement.childNodes[3].className = "progressBarComplete";
	this.fileProgressElement.childNodes[3].style.width = "";

};
FileProgress.prototype.setError = function () {
	this.fileProgressElement.className = "progressContainer red";
	this.fileProgressElement.childNodes[3].className = "progressBarError";
	this.fileProgressElement.childNodes[3].style.width = "";

};
FileProgress.prototype.setCancelled = function () {
	this.fileProgressElement.className = "progressContainer";
	this.fileProgressElement.childNodes[3].className = "progressBarError";
	this.fileProgressElement.childNodes[3].style.width = "";

};
FileProgress.prototype.setStatus = function (status) {
	this.fileProgressElement.childNodes[2].innerHTML = status;
};

FileProgress.prototype.toggleCancel = function (show, swfuploadInstance) {
	this.fileProgressElement.childNodes[0].style.visibility = show ? "visible" : "hidden";
	if (swfuploadInstance) {
		var fileID = this.fileProgressID;
		this.fileProgressElement.childNodes[0].onclick = function () {
			swfuploadInstance.cancelUpload(fileID);
			return false;
		};
	}
};


function addImage(objname,src) {
    
	var newImg = document.createElement("img");
	newImg.style.margin = "5px";
    newImg.style.width = "200px";
 /*  // newImg.style.height = "150px";
	document.getElementById(objname).appendChild(newImg);
	if (newImg.filters) {
		try {
			newImg.filters.item("DXImageTransform.Microsoft.Alpha").opacity = 100;
		} catch (e) {
			// If it is not set initially, the browser will throw an error.  This will set it if it is not set yet.
			newImg.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=' + 100 + ')';
		}
	} else {
		newImg.style.opacity = 100;
	}
    
	newImg.onload = function () {
		fadeIn(newImg, 10);
	};*/
	newImg.src = "GetURLPhoto.aspx?url="+src+"&amp;width=200";
}