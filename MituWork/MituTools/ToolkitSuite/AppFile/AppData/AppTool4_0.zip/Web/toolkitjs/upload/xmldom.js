function getXmlDoc() {
    var _xmlDom = null;
    if (!window.DOMParser  && window.ActiveXObject){
        var arrXmlDomTypes = ['MSXML2.DOMDocument.6.0','MSXML2.DOMDocument.3.0','Microsoft.XMLDOM'];
        for(var i = 0;i<arrXmlDomTypes.length;i++){
            try{
                _xmlDom = new ActiveXObject(arrXmlDomTypes[i]);
            }catch(ex){}//��֧��MSXML.XMLDOM�����IE
        }
    }
    else {// Mozilla browsers have a DOMParser
        try {
            if(_xmlDom == null && document.implementation && document.implementation.createDocument){
                _xmlDom = document.implementation.createDocument("","",null);

                Document.prototype.loadXML = function(sXml){
                    var oParser= new DOMParser();
                    var _xmlDom = oParser.parseFromString(sXml, "text/xml");
    
                    while(this.firstChild){
                        this.removeChild(this.firstChild);
                    }

                    for(var i=0;i<_xmlDom.childNodes.length;i++) {
                        var oNewNode = this.importNode(_xmlDom.childNodes[i],true);
                        this.appendChild(oNewNode);
                    }
                }

                Document.prototype.__defineGetter__("text",function(){ return this.textContent; });

                Document.prototype.selectSingleNode=function(sXPath){
                    var oEvaluator = new XPathEvaluator();
                    var oResult = oEvaluator.evaluate(sXPath,this,null, XPathResult.FIRST_ORDERED_NODE_TYPE,null);
                    if(null != oResult){
                        var result = oResult.singleNodeValue;
                        if (result != null)
                            result.text = result.textContent;
                        return result;
                    }
                    return null;
                }
                
                Document.prototype.selectNodes = function(sXPath){
                    var oEvaluator = new XPathEvaluator();
                    var oResult = oEvaluator.evaluate(sXPath,this,null, XPathResult.ORDERED_NODE_ITERATOR_TYPE,null);
                    var aNodes = new Array();
                    if(null != oResult){
                        var oElement = oResult.iterateNext();
                        while(oElement){
                            aNodes.push(oElement);
                            oElement.text = oElement.textContent;
                            oElement = oResult.iterateNext();
                        }
                    }
                    return aNodes;
                }
            }
        }catch (ex){}
    }
    return _xmlDom;
}