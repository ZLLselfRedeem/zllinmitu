var UploadJS = {
    require: function(libraryName) {
        document.write('<script type="text/javascript" src="../toolkitjs/upload/'+libraryName+'.js"><\/script>');
    },
    
    load: function() {
        UploadJS.require('handlers');
        UploadJS.require('swfupload');
        UploadJS.require('xmldom');
    }
}
UploadJS.load();