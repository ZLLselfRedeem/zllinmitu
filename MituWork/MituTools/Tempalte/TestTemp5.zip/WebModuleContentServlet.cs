﻿namespace $rootnamespace$
{
    public class $fileinputname$Servlet : ToolkitServlet
    {
        protected override WebBasePage CreatePage()
        {
            return new $fileinputname$Page();
        }
    }
}
