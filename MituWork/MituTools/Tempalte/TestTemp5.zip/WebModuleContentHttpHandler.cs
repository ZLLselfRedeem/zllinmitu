﻿using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
    [RegClass(Author = "$username$", CreateDate = "$time$",
        Description = "$fileinputname$HttpHandler注册")]
    internal sealed class $fileinputname$HttpHandler : ToolkitHttpHandler
    {
        protected override WebBasePage CreatePage()
        {
            return new $fileinputname$Page();
        }
    }
}
