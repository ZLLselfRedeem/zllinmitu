﻿using YJC.Toolkit.Data;

namespace $rootnamespace$
{
    internal class $fileinputname$Page : WebBaseModuleContentPage
    {
        private readonly IModule fModule;

        public $fileinputname$Page()
        {
            fModule = InternalWebUtil.CreateModuleXml(Request);
        }

        protected override IModule Module
        {
            get
            {
                return fModule;
            }
        }

        protected override bool SupportLogOn
        {
            get
            {
                return fModule.IsSupportLogOn(this);
            }
            set
            {
                base.SupportLogOn = value;
            }
        }
    }
}
