﻿using YJC.Toolkit.Sys;

namespace $rootnamespace$
{
    public class $fileinputname$ConfigFactory : BaseXmlConfigFactory
    {
        public const string REG_NAME = "_tk_Resolver_Creator";
        private const string DESCRIPTION = "TableResolver配置插件工厂";

        public $fileinputname$ConfigFactory()
            : base(REG_NAME, DESCRIPTION)
        {
        }
    }
}
