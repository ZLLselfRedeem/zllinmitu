﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YJC.Toolkit.Sys;

namespace ToolApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ToolApp.Initialize(false);

            // Input code.
            Console.ReadKey();
        }
    }
}
