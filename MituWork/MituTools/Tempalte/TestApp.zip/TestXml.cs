﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using YJC.Toolkit.Data;
using YJC.Toolkit.Sys;

namespace $safeprojectname$
{
    [TestClass]
    public class TestXml
    {
        [AssemblyInitialize]
        public static void Initialize(TestContext context)
        {
            TestApp.Initialize(@"");
        }

        [TestMethod]
        public void Test1()
        {
            var i = 1 + 1;
            Assert.AreEqual(i, 2);
        }
    }
}
